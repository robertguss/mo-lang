/* Written by mo build (toolchain/src/emit_c.zig); links toolchain/runtime/mo_rt.c. */
#include "mo_rt.h"

MO_U static MoValue f0(void);
MO_U static MoValue f1(void);
MO_U static MoValue f2(void);
MO_U static MoValue f3(void);
MO_U static MoValue f4(void);
MO_U static MoValue f5(void);
MO_U static MoValue f6(void);
MO_U static MoValue f7(void);
MO_U static MoValue f8(void);
MO_U static MoValue f9(void);
MO_U static MoValue f10(void);
MO_U static MoValue f11(void);
MO_U static MoValue f12(void);
MO_U static MoValue f13(void);
MO_U static MoValue f14(void);
MO_U static MoValue f15(void);
MO_U static MoValue f16(void);
MO_U static MoValue f17(void);
MO_U static MoValue f18(void);
MO_U static MoValue f19(void);
MO_U static MoValue f20(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f21(MoValue L0, MoValue L1);
MO_U static MoValue f22(MoValue L0, MoValue L1);
MO_U static MoValue f23(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f24(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4);
MO_U static MoValue f25(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f26(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f27(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f28(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue a0(const MoValue *cap, const MoValue *args);
MO_U static MoValue f29(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f30(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4);
MO_U static MoValue f31(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5);
MO_U static MoValue f32(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5);
MO_U static MoValue f33(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5);
MO_U static MoValue f34(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5);
MO_U static MoValue f35(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f36(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f37(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4);
MO_U static MoValue f38(MoValue L0, MoValue L1);
MO_U static MoValue f39(MoValue L0);
MO_U static MoValue f40(MoValue L0);
MO_U static MoValue f41(MoValue L0);
MO_U static MoValue f42(MoValue L0, MoValue L1);
MO_U static MoValue a1(const MoValue *cap, const MoValue *args);
MO_U static MoValue a2(const MoValue *cap, const MoValue *args);
MO_U static MoValue f43(MoValue L0, MoValue L1);
MO_U static MoValue f44(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f45(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f46(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5);
MO_U static MoValue f47(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5);
MO_U static MoValue a3(const MoValue *cap, const MoValue *args);
MO_U static MoValue f48(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4);
MO_U static MoValue f49(MoValue L0, MoValue L1);
MO_U static MoValue f50(MoValue L0);
MO_U static MoValue f51(MoValue L0);
MO_U static MoValue f52(MoValue L0);
MO_U static MoValue f53(MoValue L0);
MO_U static MoValue f54(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f55(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f56(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue a4(const MoValue *cap, const MoValue *args);
MO_U static MoValue f57(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue a5(const MoValue *cap, const MoValue *args);
MO_U static MoValue a6(const MoValue *cap, const MoValue *args);
MO_U static MoValue a7(const MoValue *cap, const MoValue *args);
MO_U static MoValue f58(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue a9(const MoValue *cap, const MoValue *args);
MO_U static MoValue a8(const MoValue *cap, const MoValue *args);
MO_U static MoValue f59(MoValue L0, MoValue L1);
MO_U static MoValue f60(MoValue L0);
MO_U static MoValue a10(const MoValue *cap, const MoValue *args);
MO_U static MoValue a11(const MoValue *cap, const MoValue *args);
MO_U static MoValue a13(const MoValue *cap, const MoValue *args);
MO_U static MoValue a12(const MoValue *cap, const MoValue *args);
MO_U static MoValue a14(const MoValue *cap, const MoValue *args);
MO_U static MoValue a15(const MoValue *cap, const MoValue *args);
MO_U static MoValue a16(const MoValue *cap, const MoValue *args);
MO_U static MoValue a17(const MoValue *cap, const MoValue *args);
MO_U static MoValue a18(const MoValue *cap, const MoValue *args);
MO_U static MoValue a19(const MoValue *cap, const MoValue *args);
MO_U static MoValue f61(MoValue L0, MoValue L1);
MO_U static MoValue f62(MoValue L0);
MO_U static MoValue f63(MoValue L0, MoValue L1);
MO_U static MoValue f64(MoValue L0);
MO_U static MoValue f65(MoValue L0, MoValue L1);
MO_U static MoValue a20(const MoValue *cap, const MoValue *args);
MO_U static MoValue f66(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue a21(const MoValue *cap, const MoValue *args);
MO_U static MoValue a22(const MoValue *cap, const MoValue *args);
MO_U static MoValue f67(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f68(MoValue L0, MoValue L1);
MO_U static MoValue f69(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f70(MoValue L0);
MO_U static MoValue a23(const MoValue *cap, const MoValue *args);
MO_U static MoValue f71(MoValue L0);
MO_U static MoValue a24(const MoValue *cap, const MoValue *args);
MO_U static MoValue a25(const MoValue *cap, const MoValue *args);
MO_U static MoValue a26(const MoValue *cap, const MoValue *args);
MO_U static MoValue f72(MoValue L0);
MO_U static MoValue a27(const MoValue *cap, const MoValue *args);
MO_U static MoValue f73(MoValue L0);
MO_U static MoValue f74(MoValue L0, MoValue L1);
MO_U static MoValue f75(MoValue L0);
MO_U static MoValue f76(MoValue L0, MoValue L1);
MO_U static MoValue f77(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f78(void);
MO_U static MoValue f79(MoValue L0);
MO_U static MoValue f80(MoValue L0);
MO_U static MoValue f81(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f82(MoValue L0);
MO_U static MoValue test0(void);
MO_U static MoValue test1(void);
MO_U static MoValue test2(void);
MO_U static MoValue test3(void);

static const MoField decl_fields_0[] = {{NULL, 0}};
static const MoRefineFn decl_refines_0[] = {NULL};
static const MoField decl_fields_1[] = {{NULL, 0}};
static const MoRefineFn decl_refines_1[] = {NULL};
static const MoField decl_fields_2[] = {{NULL, 0}};
static const MoRefineFn decl_refines_2[] = {NULL};
static const MoField decl_fields_3[] = {{NULL, 0}};
static const MoRefineFn decl_refines_3[] = {NULL};
static const MoField decl_fields_4[] = {{NULL, 0}};
static const MoRefineFn decl_refines_4[] = {NULL};
static const MoField decl_fields_5[] = {{NULL, 0}};
static const MoRefineFn decl_refines_5[] = {NULL};
static const MoField decl_fields_6[] = {{NULL, 0}};
static const MoRefineFn decl_refines_6[] = {NULL};
static const MoField decl_fields_7[] = {{NULL, 0}};
static const MoRefineFn decl_refines_7[] = {NULL};
static const MoField decl_fields_8[] = {{NULL, 0}};
static const MoRefineFn decl_refines_8[] = {NULL};
static const MoField decl_fields_9[] = {{NULL, 0}};
static const MoRefineFn decl_refines_9[] = {NULL};
static const MoField decl_fields_10[] = {{NULL, 0}};
static const MoRefineFn decl_refines_10[] = {NULL};
static const MoField decl_fields_11[] = {{NULL, 0}};
static const MoRefineFn decl_refines_11[] = {NULL};
static const MoField decl_fields_12[] = {{NULL, 0}};
static const MoRefineFn decl_refines_12[] = {NULL};
static const MoField decl_fields_13[] = {{NULL, 0}};
static const MoRefineFn decl_refines_13[] = {NULL};
static const MoField decl_fields_14[] = {{NULL, 0}};
static const MoRefineFn decl_refines_14[] = {NULL};
static const MoField decl_fields_15[] = {{NULL, 0}};
static const MoRefineFn decl_refines_15[] = {NULL};
static const MoField decl_fields_16[] = {{NULL, 0}};
static const MoRefineFn decl_refines_16[] = {NULL};
static const MoField decl_fields_17[] = {{"id", 3}, {"captured_at", 4}, {"captured_amount", 5}, {"refunded", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_17[] = {NULL};
static const MoField decl_fields_18[] = {{"id", 3}, {"amount", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_18[] = {NULL};
static const MoField decl_fields_19[] = {{"refund", 8}, {NULL, 0}};
static const MoRefineFn decl_refines_19[] = {NULL};
static const MoField decl_fields_20[] = {{"request", 9}, {"reason", 10}, {NULL, 0}};
static const MoRefineFn decl_refines_20[] = {NULL};
static const MoField decl_fields_21[] = {{"method", 1}, {"path", 1}, {"query", 11}, {"headers", 12}, {"body", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_21[] = {NULL};
static const MoField decl_fields_22[] = {{"status", 13}, {"headers", 14}, {"body", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_22[] = {NULL};
static const MoField decl_fields_23[] = {{"id", 6}, {"name", 1}, {"alive", 7}, {"mailbox", 6}, {"bound", 6}, {"waiting_in", 15}, {"restarts", 6}, {"region_bytes", 6}, {"paused", 7}, {"scheduler", 6}, {NULL, 0}};
static const MoRefineFn decl_refines_23[] = {NULL};
static const MoField decl_fields_24[] = {{"kind", 1}, {"target", 6}, {"name", 1}, {"in_flight", 6}, {"paused", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_24[] = {NULL};
static const MoField decl_fields_25[] = {{"name", 1}, {"kind", 16}, {"links", 6}, {"setuid", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_25[] = {NULL};
static const MoField decl_fields_26[] = {{"exit", 17}, {"stdout", 18}, {"stderr", 20}, {"truncated", 7}, {"took", 21}, {NULL, 0}};
static const MoRefineFn decl_refines_26[] = {NULL};
static const MoField decl_fields_27[] = {{"resident_bytes", 6}, {"region_bytes", 6}, {"region_resident_bytes", 6}, {"packed_bytes", 6}, {"event_bytes", 6}, {"largest", 22}, {NULL, 0}};
static const MoRefineFn decl_refines_27[] = {NULL};
static const MoField decl_fields_28[] = {{NULL, 0}};
static const MoRefineFn decl_refines_28[] = {NULL};
static const MoField decl_fields_29[] = {{"query", 1}, {"dir", 1}, {"mode", 24}, {"include_tools", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_29[] = {NULL};
static const MoField decl_fields_30[] = {{NULL, 0}};
static const MoRefineFn decl_refines_30[] = {NULL};
static const MoField decl_fields_31[] = {{"kind", 25}, {"label", 1}, {"text", 1}, {"path", 1}, {"line", 6}, {"local_index", 6}, {"api_index", 26}, {NULL, 0}};
static const MoRefineFn decl_refines_31[] = {NULL};
static const MoField decl_fields_32[] = {{"key", 1}, {"session_key", 1}, {"session_label", 1}, {"role", 1}, {"id", 1}, {"path", 1}, {"first_line", 6}, {"conversation_at", 27}, {"blocks", 28}, {NULL, 0}};
static const MoRefineFn decl_refines_32[] = {NULL};
static const MoField decl_fields_33[] = {{"payload", 2}, {"line", 6}, {NULL, 0}};
static const MoRefineFn decl_refines_33[] = {NULL};
static const MoField decl_fields_34[] = {{"path", 1}, {"line", 6}, {"detail", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_34[] = {NULL};
static const MoField decl_fields_35[] = {{"messages", 30}, {"issues", 32}, {"unknown_kinds", 34}, {"skipped_links", 6}, {"files_read", 6}, {"admitted_bytes", 6}, {"records", 6}, {"retained_blocks", 6}, {"incomplete", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_35[] = {NULL};
static const MoField decl_fields_36[] = {{"files", 35}, {"issues", 36}, {"entries", 6}, {"skipped_links", 6}, {"incomplete", 7}, {"stopped", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_36[] = {NULL};
static const MoField decl_fields_37[] = {{"entry", 31}, {"blocks", 37}, {NULL, 0}};
static const MoRefineFn decl_refines_37[] = {NULL};
static const MoField decl_fields_38[] = {{"key", 1}, {"label", 1}, {"latest", 38}, {"hits", 39}, {NULL, 0}};
static const MoRefineFn decl_refines_38[] = {NULL};
static const MoField decl_fields_39[] = {{"text", 1}, {"diagnostics", 1}, {"matches", 6}, {"incomplete", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_39[] = {NULL};
static const MoField decl_fields_40[] = {{"scan", 41}, {"seen", 42}, {"path", 1}, {"lines", 6}, {"file_records", 6}, {"bytes", 6}, {"admitted", 6}, {"replacement_seen", 7}, {"stopped", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_40[] = {NULL};
static const MoField decl_fields_41[] = {{"scan", 41}, {"blocks", 44}, {NULL, 0}};
static const MoRefineFn decl_refines_41[] = {NULL};
static const MoField decl_fields_42[] = {{"path", 1}, {"line", 6}, {"kind", 1}, {"session", 1}, {"at", 45}, {NULL, 0}};
static const MoRefineFn decl_refines_42[] = {NULL};
static const MoField decl_fields_43[] = {{"kind", 1}, {"value", 1}, {"label", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_43[] = {NULL};
static const MoField decl_fields_44[] = {{"path", 1}, {"line", 6}, {"local", 6}, {"api", 46}, {"id", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_44[] = {NULL};
static const MoField decl_fields_45[] = {{"entry_path", 1}, {"next_level", 6}, {NULL, 0}};
static const MoRefineFn decl_refines_45[] = {NULL};
static const MoField decl_fields_46[] = {{"scan", 41}, {"hits", 47}, {NULL, 0}};
static const MoRefineFn decl_refines_46[] = {NULL};
static const MoField decl_fields_47[] = {{"text", 1}, {"truncated", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_47[] = {NULL};
static const MoField decl_fields_48[] = {{NULL, 0}};
static const MoRefineFn decl_refines_48[] = {NULL};
static const MoField variant_fields_0[] = {{"path", 1}, {NULL, 0}};
static const MoField variant_fields_1[] = {{NULL, 0}};
static const MoField variant_fields_2[] = {{NULL, 0}};
static const MoField variant_fields_3[] = {{NULL, 0}};
static const MoField variant_fields_4[] = {{NULL, 0}};
static const MoField variant_fields_5[] = {{NULL, 0}};
static const MoField variant_fields_6[] = {{"fields", 48}, {NULL, 0}};
static const MoField variant_fields_7[] = {{"items", 49}, {NULL, 0}};
static const MoField variant_fields_8[] = {{"text", 1}, {NULL, 0}};
static const MoField variant_fields_9[] = {{"value", 50}, {NULL, 0}};
static const MoField variant_fields_10[] = {{"value", 7}, {NULL, 0}};
static const MoField variant_fields_11[] = {{NULL, 0}};
static const MoField variant_fields_12[] = {{"at", 6}, {NULL, 0}};
static const MoField variant_fields_13[] = {{NULL, 0}};
static const MoField variant_fields_14[] = {{NULL, 0}};
static const MoField variant_fields_15[] = {{NULL, 0}};
static const MoField variant_fields_16[] = {{NULL, 0}};
static const MoField variant_fields_17[] = {{NULL, 0}};
static const MoField variant_fields_18[] = {{NULL, 0}};
static const MoField variant_fields_19[] = {{NULL, 0}};
static const MoField variant_fields_20[] = {{NULL, 0}};
static const MoField variant_fields_21[] = {{NULL, 0}};
static const MoField variant_fields_22[] = {{NULL, 0}};
static const MoField variant_fields_23[] = {{NULL, 0}};
static const MoField variant_fields_24[] = {{NULL, 0}};
static const MoField variant_fields_25[] = {{NULL, 0}};
static const MoField variant_fields_26[] = {{"why", 1}, {NULL, 0}};
static const MoField variant_fields_27[] = {{NULL, 0}};
static const MoField variant_fields_28[] = {{NULL, 0}};
static const MoField variant_fields_29[] = {{NULL, 0}};
static const MoField variant_fields_30[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {"taking", 1}, {"took_us", 6}, {"waited_us", 6}, {"longest", 1}, {NULL, 0}};
static const MoField variant_fields_31[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {"scheduler", 6}, {NULL, 0}};
static const MoField variant_fields_32[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_33[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {"restarts", 6}, {NULL, 0}};
static const MoField variant_fields_34[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {"seed", 6}, {"clause", 1}, {"taking", 1}, {"snapshot", 1}, {NULL, 0}};
static const MoField variant_fields_35[] = {{"at", 4}, {"sender", 51}, {"sender_name", 1}, {"target", 6}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_36[] = {{"at", 4}, {"pid", 52}, {"name", 1}, {"call", 1}, {NULL, 0}};
static const MoField variant_fields_37[] = {{"at", 4}, {"source", 1}, {"target", 6}, {"name", 1}, {"in_flight", 6}, {NULL, 0}};
static const MoField variant_fields_38[] = {{"at", 4}, {"source", 1}, {"target", 6}, {"name", 1}, {"in_flight", 6}, {NULL, 0}};
static const MoField variant_fields_39[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {"taking", 1}, {NULL, 0}};
static const MoField variant_fields_40[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_41[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_42[] = {{"at", 4}, {"sender", 53}, {"sender_name", 1}, {"target", 6}, {"name", 1}, {"taking", 1}, {"why", 1}, {NULL, 0}};
static const MoField variant_fields_43[] = {{NULL, 0}};
static const MoField variant_fields_44[] = {{NULL, 0}};
static const MoField variant_fields_45[] = {{NULL, 0}};
static const MoField variant_fields_46[] = {{NULL, 0}};
static const MoField variant_fields_47[] = {{NULL, 0}};
static const MoField variant_fields_48[] = {{NULL, 0}};
static const MoField variant_fields_49[] = {{NULL, 0}};
static const MoField variant_fields_50[] = {{NULL, 0}};
static const MoField variant_fields_51[] = {{"text", 1}, {NULL, 0}};
static const MoField variant_fields_52[] = {{NULL, 0}};
static const MoField variant_fields_53[] = {{"code", 19}, {NULL, 0}};
static const MoField variant_fields_54[] = {{"signal", 19}, {NULL, 0}};
static const MoField variant_fields_55[] = {{NULL, 0}};
static const MoField variant_fields_56[] = {{NULL, 0}};
static const MoField variant_fields_57[] = {{NULL, 0}};
static const MoField variant_fields_58[] = {{"why", 1}, {NULL, 0}};
static const MoField variant_fields_59[] = {{NULL, 0}};
static const MoField variant_fields_60[] = {{NULL, 0}};
static const MoField variant_fields_61[] = {{NULL, 0}};
static const MoField variant_fields_62[] = {{NULL, 0}};
static const MoField variant_fields_63[] = {{"detail", 1}, {NULL, 0}};
const MoDecl mo_decls[] = {
    {"ChargeId", 2, 0, decl_fields_0, 0, 0, 0, decl_refines_0, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Money", 2, 0, decl_fields_1, 0, 0, 0, decl_refines_1, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"CardNumber", 2, 0, decl_fields_2, 0, 0, 0, decl_refines_2, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"FsError", 8, 0, decl_fields_3, 0, 3, 0, decl_refines_3, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"AskError", 8, 0, decl_fields_4, 3, 2, 0, decl_refines_4, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"LedgerError", 8, 0, decl_fields_5, 5, 1, 0, decl_refines_5, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Json", 8, 0, decl_fields_6, 6, 6, 0, decl_refines_6, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"JsonError", 8, 0, decl_fields_7, 12, 1, 0, decl_refines_7, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"NetError", 8, 0, decl_fields_8, 13, 5, 0, decl_refines_8, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"HttpError", 8, 0, decl_fields_9, 18, 7, 0, decl_refines_9, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RuntimeError", 8, 0, decl_fields_10, 25, 5, 0, decl_refines_10, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Event", 8, 0, decl_fields_11, 30, 13, 0, decl_refines_11, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"EntryKind", 8, 0, decl_fields_12, 43, 3, 0, decl_refines_12, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"TlsError", 8, 0, decl_fields_13, 46, 5, 0, decl_refines_13, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Arg", 8, 0, decl_fields_14, 51, 2, 0, decl_refines_14, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Exit", 8, 0, decl_fields_15, 53, 2, 0, decl_refines_15, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ExecError", 8, 0, decl_fields_16, 55, 4, 0, decl_refines_16, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Charge", 0, 4, decl_fields_17, 0, 0, 0, decl_refines_17, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundRequest", 0, 2, decl_fields_18, 0, 0, 0, decl_refines_18, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundCompleted", 0, 1, decl_fields_19, 0, 0, 0, decl_refines_19, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundFailed", 0, 2, decl_fields_20, 0, 0, 0, decl_refines_20, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Request", 0, 5, decl_fields_21, 0, 0, 0, decl_refines_21, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Response", 0, 3, decl_fields_22, 0, 0, 0, decl_refines_22, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ProcessInfo", 0, 10, decl_fields_23, 0, 0, 0, decl_refines_23, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"SourceInfo", 0, 5, decl_fields_24, 0, 0, 0, decl_refines_24, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Entry", 0, 4, decl_fields_25, 0, 0, 0, decl_refines_25, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Done", 0, 5, decl_fields_26, 0, 0, 0, decl_refines_26, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"MemoryInfo", 0, 6, decl_fields_27, 0, 0, 0, decl_refines_27, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Mode", 1, 0, decl_fields_28, 59, 2, 0, decl_refines_28, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Options", 0, 4, decl_fields_29, 0, 0, 0, decl_refines_29, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"BlockKind", 1, 0, decl_fields_30, 61, 2, 0, decl_refines_30, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Block", 0, 7, decl_fields_31, 0, 0, 0, decl_refines_31, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Message", 0, 9, decl_fields_32, 0, 0, 0, decl_refines_32, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Seen", 0, 2, decl_fields_33, 0, 0, 0, decl_refines_33, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Issue", 0, 3, decl_fields_34, 0, 0, 0, decl_refines_34, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Scan", 0, 9, decl_fields_35, 0, 0, 0, decl_refines_35, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Discovery", 0, 6, decl_fields_36, 0, 0, 0, decl_refines_36, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Hit", 0, 2, decl_fields_37, 0, 0, 0, decl_refines_37, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Session", 0, 4, decl_fields_38, 0, 0, 0, decl_refines_38, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Report", 0, 4, decl_fields_39, 0, 0, 0, decl_refines_39, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"FileFold", 0, 9, decl_fields_40, 0, 0, 0, decl_refines_40, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ParsedBlocks", 0, 2, decl_fields_41, 0, 0, 0, decl_refines_41, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ConversationInput", 0, 5, decl_fields_42, 0, 0, 0, decl_refines_42, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Identity", 0, 3, decl_fields_43, 0, 0, 0, decl_refines_43, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ResultPlace", 0, 5, decl_fields_44, 0, 0, 0, decl_refines_44, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"EntryPlace", 0, 2, decl_fields_45, 0, 0, 0, decl_refines_45, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Searched", 0, 2, decl_fields_46, 0, 0, 0, decl_refines_46, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Render", 0, 2, decl_fields_47, 0, 0, 0, decl_refines_47, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Problem", 1, 0, decl_fields_48, 63, 1, 0, decl_refines_48, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {NULL, 0, 0, NULL, 0, 0, 0, NULL, false, 0, 0, 0}
};
const MoVariantDef mo_variants[] = {
    {4, 1, variant_fields_0},
    {5, 0, variant_fields_1},
    {21, 0, variant_fields_2},
    {5, 0, variant_fields_3},
    {13, 0, variant_fields_4},
    {5, 0, variant_fields_5},
    {7, 1, variant_fields_6},
    {8, 1, variant_fields_7},
    {9, 1, variant_fields_8},
    {10, 1, variant_fields_9},
    {11, 1, variant_fields_10},
    {12, 0, variant_fields_11},
    {6, 1, variant_fields_12},
    {5, 0, variant_fields_13},
    {14, 0, variant_fields_14},
    {15, 0, variant_fields_15},
    {16, 0, variant_fields_16},
    {17, 0, variant_fields_17},
    {5, 0, variant_fields_18},
    {14, 0, variant_fields_19},
    {15, 0, variant_fields_20},
    {17, 0, variant_fields_21},
    {18, 0, variant_fields_22},
    {19, 0, variant_fields_23},
    {20, 0, variant_fields_24},
    {26, 0, variant_fields_25},
    {27, 1, variant_fields_26},
    {28, 0, variant_fields_27},
    {29, 0, variant_fields_28},
    {5, 0, variant_fields_29},
    {30, 7, variant_fields_30},
    {31, 4, variant_fields_31},
    {32, 3, variant_fields_32},
    {33, 4, variant_fields_33},
    {34, 7, variant_fields_34},
    {35, 5, variant_fields_35},
    {36, 4, variant_fields_36},
    {37, 5, variant_fields_37},
    {38, 5, variant_fields_38},
    {39, 4, variant_fields_39},
    {40, 3, variant_fields_40},
    {41, 3, variant_fields_41},
    {44, 7, variant_fields_42},
    {42, 0, variant_fields_43},
    {43, 0, variant_fields_44},
    {48, 0, variant_fields_45},
    {45, 0, variant_fields_46},
    {46, 0, variant_fields_47},
    {5, 0, variant_fields_48},
    {15, 0, variant_fields_49},
    {47, 0, variant_fields_50},
    {49, 1, variant_fields_51},
    {50, 0, variant_fields_52},
    {51, 1, variant_fields_53},
    {52, 1, variant_fields_54},
    {4, 0, variant_fields_55},
    {14, 0, variant_fields_56},
    {5, 0, variant_fields_57},
    {53, 1, variant_fields_58},
    {56, 0, variant_fields_59},
    {57, 0, variant_fields_60},
    {54, 0, variant_fields_61},
    {55, 0, variant_fields_62},
    {58, 1, variant_fields_63},
    {0, 0, NULL}
};
const uint32_t mo_nvariants = 64;
static const uint32_t type_items_0[] = {1, 1, 1, 1, 1, 0};
const MoType mo_types[] = {
    {14, "(String, String, String, String, String)", UINT32_MAX, false, 0, 5, type_items_0},
    {4, "String", UINT32_MAX, false, 0, 0, NULL},
    {16, "Json", UINT32_MAX, false, 6, 0, NULL},
    {17, "ChargeId", UINT32_MAX, false, 0, 1, NULL},
    {5, "Time", UINT32_MAX, false, 0, 0, NULL},
    {17, "Money", UINT32_MAX, false, 1, 6, NULL},
    {7, "UInt64", UINT32_MAX, false, 7, 0, NULL},
    {3, "Bool", UINT32_MAX, false, 0, 0, NULL},
    {24, "a type not yet known", UINT32_MAX, false, 0, 0, NULL},
    {16, "RefundRequest", UINT32_MAX, false, 18, 0, NULL},
    {24, "a type not yet known", UINT32_MAX, false, 0, 0, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {7, "UInt16", UINT32_MAX, false, 5, 0, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {10, "Option(String)", UINT32_MAX, false, 1, 0, NULL},
    {16, "EntryKind", UINT32_MAX, false, 12, 0, NULL},
    {16, "Exit", UINT32_MAX, false, 15, 0, NULL},
    {9, "List(UInt8)", UINT32_MAX, false, 19, 0, NULL},
    {7, "UInt8", UINT32_MAX, false, 4, 0, NULL},
    {9, "List(UInt8)", UINT32_MAX, false, 19, 0, NULL},
    {6, "Duration", UINT32_MAX, false, 0, 0, NULL},
    {9, "List(ProcessInfo)", UINT32_MAX, false, 23, 0, NULL},
    {16, "ProcessInfo", UINT32_MAX, false, 23, 0, NULL},
    {16, "Mode", UINT32_MAX, false, 28, 0, NULL},
    {16, "BlockKind", UINT32_MAX, false, 30, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 6, 0, NULL},
    {10, "Option(Time)", UINT32_MAX, false, 4, 0, NULL},
    {9, "List(Block)", UINT32_MAX, false, 29, 0, NULL},
    {16, "Block", UINT32_MAX, false, 31, 0, NULL},
    {12, "Map(String, Message)", UINT32_MAX, false, 1, 31, NULL},
    {16, "Message", UINT32_MAX, false, 32, 0, NULL},
    {9, "List(Issue)", UINT32_MAX, false, 33, 0, NULL},
    {16, "Issue", UINT32_MAX, false, 34, 0, NULL},
    {12, "Map(String, UInt64)", UINT32_MAX, false, 1, 6, NULL},
    {9, "List(String)", UINT32_MAX, false, 1, 0, NULL},
    {9, "List(Issue)", UINT32_MAX, false, 33, 0, NULL},
    {9, "List(Block)", UINT32_MAX, false, 29, 0, NULL},
    {10, "Option(Time)", UINT32_MAX, false, 4, 0, NULL},
    {9, "List(Hit)", UINT32_MAX, false, 40, 0, NULL},
    {16, "Hit", UINT32_MAX, false, 37, 0, NULL},
    {16, "Scan", UINT32_MAX, false, 35, 0, NULL},
    {12, "Map(String, Seen)", UINT32_MAX, false, 1, 43, NULL},
    {16, "Seen", UINT32_MAX, false, 33, 0, NULL},
    {9, "List(Block)", UINT32_MAX, false, 29, 0, NULL},
    {10, "Option(Time)", UINT32_MAX, false, 4, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 6, 0, NULL},
    {9, "List(Hit)", UINT32_MAX, false, 40, 0, NULL},
    {12, "Map(String, Json)", UINT32_MAX, false, 1, 2, NULL},
    {9, "List(Json)", UINT32_MAX, false, 2, 0, NULL},
    {8, "Float64", UINT32_MAX, false, 64, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 6, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 6, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 6, 0, NULL},
    {0, NULL, UINT32_MAX, false, 0, 0, NULL}
};
const uint32_t mo_nrecorded = 0;
const char *const mo_names[] = {"Some", "None", "Ok", "Error", "Missing", "Timeout", "Syntax", "Object", "Array", "String", "Number", "Bool", "Null", "Down", "Refused", "Closed", "LineTooLong", "Busy", "Malformed", "TooLarge", "Unsupported", "NotText", "Accepted", "Line", "Chunk", "Idle", "NoProcess", "Unparsed", "ReadOnly", "MailboxFull", "Updated", "Started", "Ended", "Restarted", "Crashed", "Overflowed", "TimedOut", "SourcePaused", "SourceResumed", "Sent", "Paused", "Resumed", "File", "Folder", "Dropped", "BadPem", "Handshake", "Untrusted", "Link", "Fixed", "Hole", "Exited", "Signalled", "Failed", "Conversation", "Tool", "Phrase", "AllWords", "Usage", NULL};
const uint32_t mo_nnames = 59;
const MoClause mo_clauses[] = {
    {6, false, "next.lines += 1", "folded_line", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:57:3"},
    {6, false, "line.byte_size + 1)", "folded_line", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:58:42"},
    {6, false, "next.file_records += 1", "folded_line", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:89:3"},
    {6, false, "next.scan.records += 1", "folded_line", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:90:3"},
    {10, false, "case Json.decode(line)", "folded_line", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:97:3"},
    {10, false, "case payload", "accepted_uuid", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:113:12"},
    {10, false, "case next.seen.get(uuid)", "accepted_uuid", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:121:7"},
    {10, false, "case fields.get(\"uuid\")", "accepted_uuid", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:118:3"},
    {10, false, "case payload", "decoded_record", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:139:12"},
    {10, false, "case fields.get(\"type\")", "decoded_record", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:144:10"},
    {10, false, "case fields.get(\"sessionId\")", "session_of", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:179:3"},
    {10, false, "case Time.parse(text)", "timestamp_of", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:191:7"},
    {10, false, "case fields.get(\"timestamp\")", "timestamp_of", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:189:3"},
    {10, false, "case fields.get(\"message\")", "message_record", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:202:20"},
    {10, false, "case message_fields.get(\"role\")", "message_record", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:207:10"},
    {10, false, "case message_fields.get(\"content\")", "message_record", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:216:12"},
    {10, false, "case fields.get(\"id\")", "identity_of", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:229:3"},
    {6, false, "next.retained_blocks += kept.size", "retain_message", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:263:3"},
    {10, false, "case existing", "retain_message", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:265:3"},
    {10, false, "case value", "block_of", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:293:12"},
    {10, false, "case fields.get(\"type\")", "block_of", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:300:10"},
    {10, false, "case fields.get(\"text\")", "block_of", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:311:7"},
    {10, false, "case kind", "block_of", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:309:3"},
    {10, false, "case fields.get(\"name\")", "tool_use", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:336:10"},
    {10, false, "case fields.get(\"input\")", "tool_use", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:343:11"},
    {10, false, "case fields.get(\"tool_use_id\")", "tool_result", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:356:8"},
    {10, false, "case fields.get(\"content\")", "tool_result", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:364:3"},
    {10, false, "case value", "result_part", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:390:12"},
    {10, false, "case fields.get(\"text\")", "result_part", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:399:7"},
    {10, false, "case fields.get(\"type\")", "result_part", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:397:3"},
    {10, false, "case value.to_i64", "api_index", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:428:7"},
    {10, false, "case fields.get(\"apiBlockIndex\")", "api_index", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:425:3"},
    {10, false, "case (a, b)", "later", "/home/user/workspace/repo/examples/programs/moscope/parse.mo:459:3"},
    {6, false, "started + process_time()", "scan_tree", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:22:21"},
    {6, false, "started + process_time()", "discover", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:35:19"},
    {10, false, "case folder.list(within: call_time())", "discover", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:42:11"},
    {6, false, "started + process_time()", "discover", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:49:21"},
    {6, false, "found.entries += 1", "discover", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:55:5"},
    {6, false, "level + 1)", "discover", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:57:60"},
    {10, false, "case root.kind_of(entry_path, within: call_time())", "discover", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:58:5"},
    {6, false, "found.skipped_links += 1", "discovered_entry", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:76:7"},
    {10, false, "case kind", "discovered_entry", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:74:3"},
    {10, false, "case root.size(path, within: call_time())", "scan_file", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:96:11"},
    {6, false, "started + process_time()", "scan_file", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:111:19"},
    {6, false, "next.files_read += 1", "scan_file", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:119:7"},
    {10, false, "case folded", "scan_file", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:116:3"},
    {6, false, "started + process_time()", "scan_file", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:123:19"},
    {10, false, "case error", "fs_error", "/home/user/workspace/repo/examples/programs/moscope/scan.mo:147:3"},
    {6, false, "started + process_time()", "report", "/home/user/workspace/repo/examples/programs/moscope/search.mo:26:21"},
    {6, false, "started + process_time()", "report", "/home/user/workspace/repo/examples/programs/moscope/search.mo:39:23"},
    {6, false, "started + process_time()", "searched", "/home/user/workspace/repo/examples/programs/moscope/search.mo:70:21"},
    {10, false, "case options.mode", "searched", "/home/user/workspace/repo/examples/programs/moscope/search.mo:78:13"},
    {10, false, "case session.latest", "session_heading", "/home/user/workspace/repo/examples/programs/moscope/search.mo:133:12"},
    {10, false, "case block.api_index", "render_hit", "/home/user/workspace/repo/examples/programs/moscope/search.mo:147:11"},
    {6, false, "byte + 32 else: byte", "ascii_lower", "/home/user/workspace/repo/examples/programs/moscope/search.mo:242:35"},
    {6, false, "byte / 16).to_u64", "hex", "/home/user/workspace/repo/examples/programs/moscope/search.mo:276:11"},
    {6, false, "byte % 16).to_u64", "hex", "/home/user/workspace/repo/examples/programs/moscope/search.mo:277:10"},
    {6, false, "high + 1)}#{digits.slice(low, low + 1)}\"", "hex", "/home/user/workspace/repo/examples/programs/moscope/search.mo:278:25"},
    {6, false, "low + 1)}\"", "hex", "/home/user/workspace/repo/examples/programs/moscope/search.mo:278:55"},
    {10, false, "case (a, b)", "later", "/home/user/workspace/repo/examples/programs/moscope/search.mo:282:3"},
    {10, false, "case options(platform.args)", "main", "/home/user/workspace/repo/examples/programs/moscope/main.mo:74:3"},
    {5, false, "assert options([\"search\", \"needle\", \"sessions\", \"--all-words\", \"--include-tools\"]) is Ok(both)", "flags combine in either order and duplicate or unsupported arguments are rejected", "/home/user/workspace/repo/examples/programs/moscope/main.mo:95:3"},
    {5, false, "assert both.mode == AllWords and both.include_tools", "flags combine in either order and duplicate or unsupported arguments are rejected", "/home/user/workspace/repo/examples/programs/moscope/main.mo:96:3"},
    {5, false, "assert options([\"search\", \"needle\", \"sessions\", \"--include-tools\", \"--all-words\"]) is Ok(_)", "flags combine in either order and duplicate or unsupported arguments are rejected", "/home/user/workspace/repo/examples/programs/moscope/main.mo:97:3"},
    {5, false, "assert options([\"search\", \"needle\", \"sessions\", \"--all-words\", \"--all-words\"]) is Error(Usage(_))", "flags combine in either order and duplicate or unsupported arguments are rejected", "/home/user/workspace/repo/examples/programs/moscope/main.mo:98:3"},
    {5, false, "assert options([\"search\", \"needle\", \"sessions\", \"--regex\"]) is Error(Usage(_))", "flags combine in either order and duplicate or unsupported arguments are rejected", "/home/user/workspace/repo/examples/programs/moscope/main.mo:99:3"},
    {5, false, "assert options([\"find\", \"needle\", \"sessions\"]) is Error(Usage(_))", "flags combine in either order and duplicate or unsupported arguments are rejected", "/home/user/workspace/repo/examples/programs/moscope/main.mo:100:3"},
    {5, false, "assert options([\"search\", \" \\t\\r\\n\", \"sessions\"]) is Error(Usage(_))", "blank and oversized queries and malformed positional counts are usage errors", "/home/user/workspace/repo/examples/programs/moscope/main.mo:104:3"},
    {5, false, "assert options([\"search\", \"x\".repeat(4_097), \"sessions\"]) is Error(Usage(_))", "blank and oversized queries and malformed positional counts are usage errors", "/home/user/workspace/repo/examples/programs/moscope/main.mo:105:3"},
    {5, false, "assert options([\"search\", \"needle\"]) is Error(Usage(_))", "blank and oversized queries and malformed positional counts are usage errors", "/home/user/workspace/repo/examples/programs/moscope/main.mo:106:3"},
    {5, false, "assert options([\"search\", \"needle\", \"one\", \"two\"]) is Error(Usage(_))", "blank and oversized queries and malformed positional counts are usage errors", "/home/user/workspace/repo/examples/programs/moscope/main.mo:107:3"},
    {5, false, "assert options([\"search\", \" \\t\\n\\u{000B}\\u{000C}\\r\", \"sessions\"]) is Error(Usage(_))", "all six ASCII separators are blank and query and term boundaries are exact", "/home/user/workspace/repo/examples/programs/moscope/main.mo:111:3"},
    {5, false, "assert options([\"search\", \"x\".repeat(4_096), \"sessions\"]) is Ok(_)", "all six ASCII separators are blank and query and term boundaries are exact", "/home/user/workspace/repo/examples/programs/moscope/main.mo:112:3"},
    {5, false, "assert options([\"search\", \"x \".repeat(64), \"sessions\", \"--all-words\"]) is Ok(_)", "all six ASCII separators are blank and query and term boundaries are exact", "/home/user/workspace/repo/examples/programs/moscope/main.mo:113:3"},
    {5, false, "assert options([\"search\", \"x \".repeat(65), \"sessions\", \"--all-words\"]) is Error(Usage(_))", "all six ASCII separators are blank and query and term boundaries are exact", "/home/user/workspace/repo/examples/programs/moscope/main.mo:114:3"},
    {5, false, "assert options([\"search\", \"x \".repeat(65), \"sessions\"]) is Ok(_)", "all six ASCII separators are blank and query and term boundaries are exact", "/home/user/workspace/repo/examples/programs/moscope/main.mo:115:3"},
    {5, false, "assert options([\"search\", \"--all-words\", \"needle\", \"--include-tools\", \"sessions\"]) is Ok(_)", "flags are allowed around positionals while every missing duplicate and option shape rejects", "/home/user/workspace/repo/examples/programs/moscope/main.mo:119:3"},
    {5, false, "assert options([\"search\", \"--include-tools\", \"needle\", \"sessions\", \"--all-words\"]) is Ok(_)", "flags are allowed around positionals while every missing duplicate and option shape rejects", "/home/user/workspace/repo/examples/programs/moscope/main.mo:120:3"},
    {5, false, "assert options([]) is Error(Usage(_))", "flags are allowed around positionals while every missing duplicate and option shape rejects", "/home/user/workspace/repo/examples/programs/moscope/main.mo:121:3"},
    {5, false, "assert options([\"find\", \"needle\", \"sessions\"]) is Error(Usage(_))", "flags are allowed around positionals while every missing duplicate and option shape rejects", "/home/user/workspace/repo/examples/programs/moscope/main.mo:122:3"},
    {5, false, "assert options([\"search\",", "flags are allowed around positionals while every missing duplicate and option shape rejects", "/home/user/workspace/repo/examples/programs/moscope/main.mo:123:3"},
    {5, false, "assert options([\"search\", \"needle\", \"sessions\", \"--bad\\u{0007}\"]) is Error(Usage(_))", "flags are allowed around positionals while every missing duplicate and option shape rejects", "/home/user/workspace/repo/examples/programs/moscope/main.mo:128:3"},
    {5, false, "assert options([\"search\", \"needle\", \"\"]) is Error(Usage(_))", "flags are allowed around positionals while every missing duplicate and option shape rejects", "/home/user/workspace/repo/examples/programs/moscope/main.mo:129:3"},
    {0, false, NULL, NULL, NULL}
};
const MoTest mo_tests[] = {
    {MO_TEST, "flags combine in either order and duplicate or unsupported arguments are rejected", test0},
    {MO_TEST, "blank and oversized queries and malformed positional counts are usage errors", test1},
    {MO_TEST, "all six ASCII separators are blank and query and term boundaries are exact", test2},
    {MO_TEST, "flags are allowed around positionals while every missing duplicate and option shape rejects", test3},
    {0, NULL, NULL}
};
const uint32_t mo_ntests = 4;
const MoNever mo_nevers[] = {
    {NULL, 0, 0, NULL}
};
const uint32_t mo_nnevers = 0;
const MoProcess mo_processes[] = {
    {NULL, 0, 0, NULL, NULL, 0, NULL, false}
};
const uint32_t mo_nprocesses = 0;
const MoSupervisor mo_supervisors[] = {
    {NULL, 0, NULL}
};
const uint32_t mo_nsupervisors = 0;
const uint32_t mo_charge_decl = 17;
const uint32_t mo_request_decl = 21;
const uint32_t mo_response_decl = 22;
const uint32_t mo_process_info_decl = 23;
const uint32_t mo_source_info_decl = 24;
const uint32_t mo_memory_info_decl = 27;
const uint32_t mo_entry_decl = 25;
const uint32_t mo_done_decl = 26;
const bool mo_surface_built = false;
const uint32_t mo_surface_process = UINT32_MAX;
const bool mo_contracts_built = true;

MO_U static MoValue f0(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(4096));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f1(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("terms");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(64));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f2(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("depth");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(24));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f3(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("entries");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(50000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f4(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("files");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(5000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f5(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(67108864));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f6(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("total_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1073741824));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f7(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("line_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1048576));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f8(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_records");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(200000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f9(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("records");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1000000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f10(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("messages");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(100000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f11(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("blocks");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(500000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f12(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("results");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(10000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f13(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("diagnostics");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(10000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f14(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("excerpt");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(240));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f15(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("output_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(8388608));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f16(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("call_time");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Int_seconds((const MoValue[]){mo_i64(INT64_C(10))}, 3);
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f17(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("process_time");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Int_seconds((const MoValue[]){mo_i64(INT64_C(60))}, 3);
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f18(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("empty_scan");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t3 MO_U = mo_record(35, 9, (const MoValue[]){t0, t1, t2, mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_bool(false)});
    R = t3;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f19(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("empty_discovery");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_list_of(0, NULL);
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_record(36, 6, (const MoValue[]){t0, t1, mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_bool(false), mo_bool(false)});
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f20(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("start_file");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t2 MO_U = L1;
    MoValue t3 MO_U = L2;
    MoValue t4 MO_U = mo_record(40, 9, (const MoValue[]){t0, t1, t2, mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), t3, mo_bool(false), mo_bool(false)});
    R = t4;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f21() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = R; } while (0)
#define LOAD_f21() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; R = V_[8]; } while (0)
MO_U static MoValue f21(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("folded_line");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue V_[9];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 9, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L2 = t0;
    MoValue t1 MO_U = L2.as.xs[3];
    MoValue t2 MO_U = mo_add_u64(t1, mo_i64(INT64_C(1)), 0);
    MoValue t3 MO_U = L2;
    MoValue t4 MO_U = mo_set_field(t3, 3, t2);
    L2 = t4;
    MoValue t5 MO_U = L2.as.xs[5];
    MoValue t6 MO_U = L1;
    MoValue t7 MO_U = mo_r_String_byte_size((const MoValue[]){t6}, MO_KIND_NONE);
    MoValue t8 MO_U = mo_add_u64(t7, mo_i64(INT64_C(1)), 1);
    MoValue t9 MO_U = mo_r_Int_saturating_add((const MoValue[]){t5, t8}, 7);
    MoValue t10 MO_U = L2;
    MoValue t11 MO_U = mo_set_field(t10, 5, t9);
    L2 = t11;
    MoValue t12 MO_U = L1;
    MoValue t13 MO_U = mo_r_String_contains_q((const MoValue[]){t12, mo_str("\357\277\275", 3)}, MO_KIND_NONE);
    L3 = t13;
    MoValue t14 MO_U = L2.as.xs[7];
    MoValue t15 MO_U = mo_bool(true);
    if (!t14.as.b) {
        MoValue t16 MO_U = L3;
        t15 = t16;
    }
    MoValue t17 MO_U = L2;
    MoValue t18 MO_U = mo_set_field(t17, 7, t15);
    L2 = t18;
    MoValue t19 MO_U = L2.as.xs[8];
    if (t19.as.b) {
        mo_disown_in(L2);
        MoValue t20 MO_U = L2;
        R = t20;
        goto X22;
    }
    MoValue t21 MO_U = L1;
    MoValue t22 MO_U = mo_r_String_byte_size((const MoValue[]){t21}, MO_KIND_NONE);
    MoValue t23 MO_U = f7();
    MoValue t24 MO_U = mo_bool(t22.as.u > t23.as.u);
    if (t24.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t25 MO_U = L2.as.xs[0];
        MoValue t26 MO_U = L2.as.xs[2];
        MoValue t27 MO_U = L2.as.xs[3];
        SAVE_f21();
        uint64_t w28 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t29 MO_U = f44(t25, t26, t27, mo_str("a JSONL line exceeds 1 MiB", 26));
        FR_.walking = false; if (mo_walks != w28) LOAD_f21();
        MoValue t30 MO_U = L2;
        MoValue t31 MO_U = mo_set_field(t30, 0, t29);
        L2 = t31;
        MoValue t32 MO_U = L2;
        MoValue t33 MO_U = mo_set_field(t32, 8, mo_bool(true));
        L2 = t33;
        mo_disown_in(L2);
        MoValue t34 MO_U = L2;
        R = t34;
        goto X22;
    }
    MoValue t35 MO_U = L2.as.xs[7];
    MoValue t36 MO_U = mo_bool(!t35.as.b);
    MoValue t37 MO_U = mo_bool(false);
    if (t36.as.b) {
        MoValue t38 MO_U = L2.as.xs[5];
        MoValue t39 MO_U = L2.as.xs[6];
        MoValue t40 MO_U = mo_r_Int_saturating_add((const MoValue[]){t39, mo_i64(INT64_C(1))}, 7);
        MoValue t41 MO_U = mo_bool(t38.as.u > t40.as.u);
        t37 = t41;
    }
    if (t37.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t42 MO_U = L2.as.xs[0];
        MoValue t43 MO_U = L2.as.xs[2];
        MoValue t44 MO_U = L2.as.xs[3];
        SAVE_f21();
        uint64_t w45 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t46 MO_U = f44(t42, t43, t44, mo_str("the file grew after size admission; results use only the admitted prefix", 72));
        FR_.walking = false; if (mo_walks != w45) LOAD_f21();
        MoValue t47 MO_U = L2;
        MoValue t48 MO_U = mo_set_field(t47, 0, t46);
        L2 = t48;
        MoValue t49 MO_U = L2;
        MoValue t50 MO_U = mo_set_field(t49, 8, mo_bool(true));
        L2 = t50;
        mo_disown_in(L2);
        MoValue t51 MO_U = L2;
        R = t51;
        goto X22;
    }
    MoValue t52 MO_U = L2.as.xs[4];
    MoValue t53 MO_U = f39(t52);
    MoValue t54 MO_U = mo_bool(!t53.as.b);
    if (t54.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t55 MO_U = L2.as.xs[0];
        MoValue t56 MO_U = L2.as.xs[2];
        MoValue t57 MO_U = L2.as.xs[3];
        SAVE_f21();
        uint64_t w58 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t59 MO_U = f44(t55, t56, t57, mo_str("the file exceeds 200000 records", 31));
        FR_.walking = false; if (mo_walks != w58) LOAD_f21();
        MoValue t60 MO_U = L2;
        MoValue t61 MO_U = mo_set_field(t60, 0, t59);
        L2 = t61;
        MoValue t62 MO_U = L2;
        MoValue t63 MO_U = mo_set_field(t62, 8, mo_bool(true));
        L2 = t63;
        mo_disown_in(L2);
        MoValue t64 MO_U = L2;
        R = t64;
        goto X22;
    }
    MoValue t65 MO_U = L2.as.xs[0];
    MoValue t66 MO_U = t65.as.xs[6];
    MoValue t67 MO_U = f40(t66);
    MoValue t68 MO_U = mo_bool(!t67.as.b);
    if (t68.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t69 MO_U = L2.as.xs[0];
        MoValue t70 MO_U = L2.as.xs[2];
        MoValue t71 MO_U = L2.as.xs[3];
        SAVE_f21();
        uint64_t w72 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t73 MO_U = f44(t69, t70, t71, mo_str("the search exceeds 1000000 records", 34));
        FR_.walking = false; if (mo_walks != w72) LOAD_f21();
        MoValue t74 MO_U = L2;
        MoValue t75 MO_U = mo_set_field(t74, 0, t73);
        L2 = t75;
        MoValue t76 MO_U = L2;
        MoValue t77 MO_U = mo_set_field(t76, 8, mo_bool(true));
        L2 = t77;
        mo_disown_in(L2);
        MoValue t78 MO_U = L2;
        R = t78;
        goto X22;
    }
    MoValue t79 MO_U = L2.as.xs[4];
    MoValue t80 MO_U = mo_add_u64(t79, mo_i64(INT64_C(1)), 2);
    MoValue t81 MO_U = L2;
    MoValue t82 MO_U = mo_set_field(t81, 4, t80);
    L2 = t82;
    MoValue t83 MO_U = L2.as.xs[0];
    MoValue t84 MO_U = t83.as.xs[6];
    MoValue t85 MO_U = mo_add_u64(t84, mo_i64(INT64_C(1)), 3);
    MoValue t86 MO_U = L2;
    MoValue t87 MO_U = t86.as.xs[0];
    MoValue t88 MO_U = mo_set_field(t87, 6, t85);
    MoValue t89 MO_U = L2;
    MoValue t90 MO_U = mo_set_field(t89, 0, t88);
    L2 = t90;
    MoValue t91 MO_U = L3;
    if (t91.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t92 MO_U = L2.as.xs[0];
        MoValue t93 MO_U = L2.as.xs[2];
        MoValue t94 MO_U = L2.as.xs[3];
        SAVE_f21();
        uint64_t w95 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t96 MO_U = f44(t92, t93, t94, mo_str("U+FFFD is present; fold_lines cannot distinguish it from replaced invalid UTF-8", 79));
        FR_.walking = false; if (mo_walks != w95) LOAD_f21();
        MoValue t97 MO_U = L2;
        MoValue t98 MO_U = mo_set_field(t97, 0, t96);
        L2 = t98;
    }
    MoValue t99 MO_U = L1;
    MoValue t100 MO_U = mo_r_Json_decode((const MoValue[]){t99}, MO_KIND_NONE);
    L4 = t100;
    if (!mo_is(L4, 2)) goto F24;
    L5 = L4.as.xs[0];
    L6 = L5;
    if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
    mo_disown_in(L2);
    MoValue t101 MO_U = L2;
    MoValue t102 MO_U = L6;
    SAVE_f21();
    uint64_t w103 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t104 MO_U = f22(t101, t102);
    FR_.walking = false; if (mo_walks != w103) LOAD_f21();
    L7 = t104;
    MoValue t105 MO_U = L7.as.xs[0];
    L2 = t105;
    MoValue t106 MO_U = L7.as.xs[1];
    if (t106.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t107 MO_U = L2.as.xs[0];
        MoValue t108 MO_U = L2.as.xs[2];
        MoValue t109 MO_U = L2.as.xs[3];
        MoValue t110 MO_U = L6;
        SAVE_f21();
        uint64_t w111 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t112 MO_U = f23(t107, t108, t109, t110);
        FR_.walking = false; if (mo_walks != w111) LOAD_f21();
        MoValue t113 MO_U = L2;
        MoValue t114 MO_U = mo_set_field(t113, 0, t112);
        L2 = t114;
    }
    goto E23;
    F24:;
    if (!mo_is(L4, 3)) goto F25;
    if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
    MoValue t115 MO_U = L2.as.xs[0];
    MoValue t116 MO_U = L2.as.xs[2];
    MoValue t117 MO_U = L2.as.xs[3];
    SAVE_f21();
    uint64_t w118 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t119 MO_U = f44(t115, t116, t117, mo_str("malformed JSON record", 21));
    FR_.walking = false; if (mo_walks != w118) LOAD_f21();
    MoValue t120 MO_U = L2;
    MoValue t121 MO_U = mo_set_field(t120, 0, t119);
    L2 = t121;
    goto E23;
    F25:;
    mo_crash(4);
    E23:;
    MoValue t122 MO_U = L2;
    R = t122;
    X22:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f21
#undef LOAD_f21
#define SAVE_f22() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = R; } while (0)
#define LOAD_f22() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; R = V_[14]; } while (0)
MO_U static MoValue f22(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("accepted_uuid");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue V_[15];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 15, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L2 = t0;
    MoValue t1 MO_U = MO_NONE_V;
    MoValue t2 MO_U = L1;
    L3 = t2;
    if (!mo_is(L3, 7)) goto F28;
    L4 = L3.as.xs[0];
    L5 = L4;
    MoValue t3 MO_U = L5;
    t1 = t3;
    goto E27;
    F28:;
    if (!mo_is(L3, 9)) goto F31;
    goto E30;
    F31:;
    if (!mo_is(L3, 8)) goto F32;
    goto E30;
    F32:;
    if (!mo_is(L3, 10)) goto F33;
    goto E30;
    F33:;
    if (!mo_is(L3, 11)) goto F34;
    goto E30;
    F34:;
    if (!mo_is(L3, 12)) goto F29;
    E30:;
    mo_disown_in(L2);
    MoValue t4 MO_U = L2;
    MoValue t5 MO_U = mo_tuple(2, (const MoValue[]){t4, mo_bool(true)});
    R = t5;
    goto X26;
    t1 = MO_NONE_V;
    goto E27;
    F29:;
    mo_crash(5);
    E27:;
    L6 = t1;
    MoValue t6 MO_U = MO_NONE_V;
    MoValue t7 MO_U = L6;
    MoValue t8 MO_U = mo_r_Map_get((const MoValue[]){t7, mo_str("uuid", 4)}, MO_KIND_NONE);
    L7 = t8;
    if (!mo_is(L7, 1)) goto F37;
    mo_disown_in(L2);
    MoValue t9 MO_U = L2;
    MoValue t10 MO_U = mo_tuple(2, (const MoValue[]){t9, mo_bool(true)});
    t6 = t10;
    goto E36;
    F37:;
    if (!mo_is(L7, 0)) goto F38;
    L8 = L7.as.xs[0];
    if (!mo_is(L8, 9)) goto F38;
    L9 = L8.as.xs[0];
    L10 = L9;
    MoValue t11 MO_U = MO_NONE_V;
    MoValue t12 MO_U = L2;
    MoValue t13 MO_U = t12.as.xs[1];
    MoValue t14 MO_U = L10;
    MoValue t15 MO_U = mo_r_Map_get((const MoValue[]){t13, t14}, MO_KIND_NONE);
    L11 = t15;
    if (!mo_is(L11, 1)) goto F40;
    MoValue t16 MO_U = L2;
    MoValue t17 MO_U = t16.as.xs[1];
    MoValue t18 MO_U = L10;
    MoValue t19 MO_U = L1;
    MoValue t20 MO_U = L2.as.xs[3];
    MoValue t21 MO_U = mo_record(33, 2, (const MoValue[]){t19, t20});
    mo_disown_in(t21);
    MoValue t22 MO_U = mo_r_Map_set((const MoValue[]){t17, t18, t21}, MO_KIND_UNIQUE);
    MoValue t23 MO_U = L2;
    MoValue t24 MO_U = mo_set_field(t23, 1, t22);
    L2 = t24;
    mo_disown_in(L2);
    MoValue t25 MO_U = L2;
    MoValue t26 MO_U = mo_tuple(2, (const MoValue[]){t25, mo_bool(true)});
    t11 = t26;
    goto E39;
    F40:;
    if (!mo_is(L11, 0)) goto F41;
    L12 = L11.as.xs[0];
    L13 = L12;
    MoValue t27 MO_U = MO_NONE_V;
    MoValue t28 MO_U = L13.as.xs[0];
    MoValue t29 MO_U = L1;
    MoValue t30 MO_U = mo_bool(mo_compare(MO_EQ, t28, t29));
    if (t30.as.b) {
        mo_disown_in(L2);
        MoValue t31 MO_U = L2;
        MoValue t32 MO_U = mo_tuple(2, (const MoValue[]){t31, mo_bool(false)});
        t27 = t32;
    } else {
        if (mo_walk_due(&FR_)) { SAVE_f22(); mo_walk(&FR_); LOAD_f22(); }
        MoValue t33 MO_U = L2.as.xs[0];
        MoValue t34 MO_U = L2.as.xs[2];
        MoValue t35 MO_U = L2.as.xs[3];
        MoValue t36 MO_U = L10;
        MoValue t37 MO_U = L13.as.xs[1];
        MoValue t38 MO_U = mo_concat(4, (const MoValue[]){mo_str("UUID ", 5), t36, mo_str(" conflicts with line ", 21), t37});
        SAVE_f22();
        uint64_t w39 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t40 MO_U = f44(t33, t34, t35, t38);
        FR_.walking = false; if (mo_walks != w39) LOAD_f22();
        MoValue t41 MO_U = L2;
        MoValue t42 MO_U = mo_set_field(t41, 0, t40);
        L2 = t42;
        mo_disown_in(L2);
        MoValue t43 MO_U = L2;
        MoValue t44 MO_U = mo_tuple(2, (const MoValue[]){t43, mo_bool(false)});
        t27 = t44;
    }
    t11 = t27;
    goto E39;
    F41:;
    mo_crash(6);
    E39:;
    t6 = t11;
    goto E36;
    F38:;
    if (!mo_is(L7, 0)) goto F42;
    MoValue t45 MO_U = L2;
    MoValue t46 MO_U = mo_tuple(2, (const MoValue[]){t45, mo_bool(true)});
    t6 = t46;
    goto E36;
    F42:;
    mo_crash(7);
    E36:;
    R = t6;
    X26:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f22
#undef LOAD_f22
#define SAVE_f23() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = L18; V_[19] = L19; V_[20] = R; } while (0)
#define LOAD_f23() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; L18 = V_[18]; L19 = V_[19]; R = V_[20]; } while (0)
MO_U static MoValue f23(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("decoded_record");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue V_[21];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 21, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L3;
    L4 = t1;
    if (!mo_is(L4, 7)) goto F45;
    L5 = L4.as.xs[0];
    L6 = L5;
    MoValue t2 MO_U = L6;
    t0 = t2;
    goto E44;
    F45:;
    if (!mo_is(L4, 9)) goto F48;
    goto E47;
    F48:;
    if (!mo_is(L4, 8)) goto F49;
    goto E47;
    F49:;
    if (!mo_is(L4, 10)) goto F50;
    goto E47;
    F50:;
    if (!mo_is(L4, 11)) goto F51;
    goto E47;
    F51:;
    if (!mo_is(L4, 12)) goto F46;
    E47:;
    if (mo_walk_due(&FR_)) { SAVE_f23(); mo_walk(&FR_); LOAD_f23(); }
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L1;
    MoValue t5 MO_U = L2;
    SAVE_f23();
    uint64_t w6 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t7 MO_U = f44(t3, t4, t5, mo_str("top-level JSON record is not an object", 38));
    FR_.walking = false; if (mo_walks != w6) LOAD_f23();
    R = t7;
    goto X43;
    t0 = MO_NONE_V;
    goto E44;
    F46:;
    mo_crash(8);
    E44:;
    L7 = t0;
    MoValue t8 MO_U = MO_NONE_V;
    MoValue t9 MO_U = L7;
    MoValue t10 MO_U = mo_r_Map_get((const MoValue[]){t9, mo_str("type", 4)}, MO_KIND_NONE);
    L8 = t10;
    if (!mo_is(L8, 0)) goto F54;
    L9 = L8.as.xs[0];
    if (!mo_is(L9, 9)) goto F54;
    L10 = L9.as.xs[0];
    L11 = L10;
    MoValue t11 MO_U = L11;
    t8 = t11;
    goto E53;
    F54:;
    if (!mo_is(L8, 1)) goto F57;
    goto E56;
    F57:;
    if (!mo_is(L8, 0)) goto F58;
    L12 = L8.as.xs[0];
    if (!mo_is(L12, 7)) goto F58;
    goto E56;
    F58:;
    if (!mo_is(L8, 0)) goto F59;
    L13 = L8.as.xs[0];
    if (!mo_is(L13, 8)) goto F59;
    goto E56;
    F59:;
    if (!mo_is(L8, 0)) goto F60;
    L14 = L8.as.xs[0];
    if (!mo_is(L14, 10)) goto F60;
    goto E56;
    F60:;
    if (!mo_is(L8, 0)) goto F61;
    L15 = L8.as.xs[0];
    if (!mo_is(L15, 11)) goto F61;
    goto E56;
    F61:;
    if (!mo_is(L8, 0)) goto F55;
    L16 = L8.as.xs[0];
    if (!mo_is(L16, 12)) goto F55;
    E56:;
    if (mo_walk_due(&FR_)) { SAVE_f23(); mo_walk(&FR_); LOAD_f23(); }
    mo_disown_in(L0);
    MoValue t12 MO_U = L0;
    MoValue t13 MO_U = L1;
    MoValue t14 MO_U = L2;
    SAVE_f23();
    uint64_t w15 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t16 MO_U = f44(t12, t13, t14, mo_str("top-level record type is missing or not a string", 48));
    FR_.walking = false; if (mo_walks != w15) LOAD_f23();
    R = t16;
    goto X43;
    t8 = MO_NONE_V;
    goto E53;
    F55:;
    mo_crash(9);
    E53:;
    L17 = t8;
    MoValue t17 MO_U = L17;
    MoValue t18 MO_U = mo_bool(mo_compare(MO_NE, t17, mo_str("user", 4)));
    MoValue t19 MO_U = mo_bool(false);
    if (t18.as.b) {
        MoValue t20 MO_U = L17;
        MoValue t21 MO_U = mo_bool(mo_compare(MO_NE, t20, mo_str("assistant", 9)));
        t19 = t21;
    }
    if (t19.as.b) {
        MoValue t22 MO_U = L7;
        MoValue t23 MO_U = mo_r_Map_get((const MoValue[]){t22, mo_str("message", 7)}, MO_KIND_NONE);
        L18 = t23;
        MoValue t24 MO_U = mo_bool(true);
        if (!mo_is(L18, 0)) goto F63;
        L19 = L18.as.xs[0];
        if (!mo_is(L19, 7)) goto F63;
        goto E64;
        F63:;
        t24 = mo_bool(false);
        E64:;
        if (t24.as.b) {
            if (mo_walk_due(&FR_)) { SAVE_f23(); mo_walk(&FR_); LOAD_f23(); }
            mo_disown_in(L0);
            MoValue t25 MO_U = L0;
            MoValue t26 MO_U = L1;
            MoValue t27 MO_U = L2;
            MoValue t28 MO_U = L17;
            MoValue t29 MO_U = mo_concat(3, (const MoValue[]){mo_str("unknown type ", 13), t28, mo_str(" has a conversation-shaped message", 34)});
            SAVE_f23();
            uint64_t w30 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t31 MO_U = f44(t25, t26, t27, t29);
            FR_.walking = false; if (mo_walks != w30) LOAD_f23();
            R = t31;
            goto X43;
        }
        if (mo_walk_due(&FR_)) { SAVE_f23(); mo_walk(&FR_); LOAD_f23(); }
        mo_disown_in(L0);
        MoValue t32 MO_U = L0;
        MoValue t33 MO_U = L17;
        SAVE_f23();
        uint64_t w34 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t35 MO_U = f43(t32, t33);
        FR_.walking = false; if (mo_walks != w34) LOAD_f23();
        R = t35;
        goto X43;
    }
    if (mo_walk_due(&FR_)) { SAVE_f23(); mo_walk(&FR_); LOAD_f23(); }
    MoValue t36 MO_U = L0;
    MoValue t37 MO_U = L1;
    MoValue t38 MO_U = L2;
    MoValue t39 MO_U = L17;
    MoValue t40 MO_U = L7;
    SAVE_f23();
    uint64_t w41 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t42 MO_U = f24(t36, t37, t38, t39, t40);
    FR_.walking = false; if (mo_walks != w41) LOAD_f23();
    R = t42;
    X43:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f23
#undef LOAD_f23
#define SAVE_f24() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = R; } while (0)
#define LOAD_f24() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; R = V_[13]; } while (0)
MO_U static MoValue f24(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("conversation");
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue V_[14];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 14, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L5 = t0;
    mo_disown_in(L4);
    MoValue t1 MO_U = L4;
    MoValue t2 MO_U = f38(t1, mo_str("isMeta", 6));
    MoValue t3 MO_U = mo_bool(true);
    if (!t2.as.b) {
        mo_disown_in(L4);
        MoValue t4 MO_U = L4;
        MoValue t5 MO_U = f38(t4, mo_str("isCompactSummary", 16));
        t3 = t5;
    }
    MoValue t6 MO_U = mo_bool(true);
    if (!t3.as.b) {
        mo_disown_in(L4);
        MoValue t7 MO_U = L4;
        MoValue t8 MO_U = f38(t7, mo_str("isApiErrorMessage", 17));
        t6 = t8;
    }
    if (t6.as.b) {
        mo_disown_in(L5);
        MoValue t9 MO_U = L5;
        R = t9;
        goto X65;
    }
    MoValue t10 MO_U = L4;
    MoValue t11 MO_U = mo_r_Map_get((const MoValue[]){t10, mo_str("uuid", 4)}, MO_KIND_NONE);
    L6 = t11;
    MoValue t12 MO_U = mo_bool(true);
    if (!mo_is(L6, 0)) goto F66;
    L7 = L6.as.xs[0];
    L8 = L7;
    goto E67;
    F66:;
    t12 = mo_bool(false);
    E67:;
    if (t12.as.b) {
        MoValue t13 MO_U = L8;
        L9 = t13;
        MoValue t14 MO_U = mo_bool(true);
        if (!mo_is(L9, 9)) goto F68;
        goto E69;
        F68:;
        t14 = mo_bool(false);
        E69:;
        MoValue t15 MO_U = mo_bool(!t14.as.b);
        if (t15.as.b) {
            if (mo_walk_due(&FR_)) { SAVE_f24(); mo_walk(&FR_); LOAD_f24(); }
            MoValue t16 MO_U = L5;
            MoValue t17 MO_U = L1;
            MoValue t18 MO_U = L2;
            SAVE_f24();
            uint64_t w19 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t20 MO_U = f44(t16, t17, t18, mo_str("conversation uuid is not a string", 33));
            FR_.walking = false; if (mo_walks != w19) LOAD_f24();
            L5 = t20;
        }
    }
    if (mo_walk_due(&FR_)) { SAVE_f24(); mo_walk(&FR_); LOAD_f24(); }
    mo_disown_in(L5);
    MoValue t21 MO_U = L5;
    MoValue t22 MO_U = L1;
    MoValue t23 MO_U = L2;
    mo_disown_in(L4);
    MoValue t24 MO_U = L4;
    SAVE_f24();
    uint64_t w25 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t26 MO_U = f25(t21, t22, t23, t24);
    FR_.walking = false; if (mo_walks != w25) LOAD_f24();
    L10 = t26;
    MoValue t27 MO_U = L10.as.xs[0];
    L5 = t27;
    if (mo_walk_due(&FR_)) { SAVE_f24(); mo_walk(&FR_); LOAD_f24(); }
    mo_disown_in(L5);
    MoValue t28 MO_U = L5;
    MoValue t29 MO_U = L1;
    MoValue t30 MO_U = L2;
    mo_disown_in(L4);
    MoValue t31 MO_U = L4;
    SAVE_f24();
    uint64_t w32 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t33 MO_U = f26(t28, t29, t30, t31);
    FR_.walking = false; if (mo_walks != w32) LOAD_f24();
    L11 = t33;
    MoValue t34 MO_U = L11.as.xs[0];
    L5 = t34;
    MoValue t35 MO_U = L1;
    MoValue t36 MO_U = L2;
    MoValue t37 MO_U = L3;
    MoValue t38 MO_U = L10.as.xs[1];
    MoValue t39 MO_U = L11.as.xs[1];
    MoValue t40 MO_U = mo_record(42, 5, (const MoValue[]){t35, t36, t37, t38, t39});
    L12 = t40;
    if (mo_walk_due(&FR_)) { SAVE_f24(); mo_walk(&FR_); LOAD_f24(); }
    MoValue t41 MO_U = L5;
    MoValue t42 MO_U = L12;
    MoValue t43 MO_U = L4;
    SAVE_f24();
    uint64_t w44 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t45 MO_U = f27(t41, t42, t43);
    FR_.walking = false; if (mo_walks != w44) LOAD_f24();
    R = t45;
    X65:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f24
#undef LOAD_f24
MO_U static MoValue f25(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("session_of");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L3;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("sessionId", 9)}, MO_KIND_NONE);
    L4 = t2;
    if (!mo_is(L4, 0)) goto F72;
    L5 = L4.as.xs[0];
    if (!mo_is(L5, 9)) goto F72;
    L6 = L5.as.xs[0];
    L7 = L6;
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L7;
    MoValue t5 MO_U = mo_tuple(2, (const MoValue[]){t3, t4});
    t0 = t5;
    goto E71;
    F72:;
    if (!mo_is(L4, 1)) goto F73;
    mo_disown_in(L0);
    MoValue t6 MO_U = L0;
    MoValue t7 MO_U = mo_tuple(2, (const MoValue[]){t6, mo_str("", 0)});
    t0 = t7;
    goto E71;
    F73:;
    if (!mo_is(L4, 0)) goto F76;
    L8 = L4.as.xs[0];
    if (!mo_is(L8, 7)) goto F76;
    goto E75;
    F76:;
    if (!mo_is(L4, 0)) goto F77;
    L9 = L4.as.xs[0];
    if (!mo_is(L9, 8)) goto F77;
    goto E75;
    F77:;
    if (!mo_is(L4, 0)) goto F78;
    L10 = L4.as.xs[0];
    if (!mo_is(L10, 10)) goto F78;
    goto E75;
    F78:;
    if (!mo_is(L4, 0)) goto F79;
    L11 = L4.as.xs[0];
    if (!mo_is(L11, 11)) goto F79;
    goto E75;
    F79:;
    if (!mo_is(L4, 0)) goto F74;
    L12 = L4.as.xs[0];
    if (!mo_is(L12, 12)) goto F74;
    E75:;
    MoValue t8 MO_U = L0;
    MoValue t9 MO_U = L1;
    MoValue t10 MO_U = L2;
    MoValue t11 MO_U = f44(t8, t9, t10, mo_str("conversation sessionId is not a string", 38));
    MoValue t12 MO_U = mo_tuple(2, (const MoValue[]){t11, mo_str("", 0)});
    t0 = t12;
    goto E71;
    F74:;
    mo_crash(10);
    E71:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f26(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("timestamp_of");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L3;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("timestamp", 9)}, MO_KIND_NONE);
    L4 = t2;
    if (!mo_is(L4, 0)) goto F83;
    L5 = L4.as.xs[0];
    if (!mo_is(L5, 9)) goto F83;
    L6 = L5.as.xs[0];
    L7 = L6;
    MoValue t3 MO_U = MO_NONE_V;
    MoValue t4 MO_U = L7;
    MoValue t5 MO_U = mo_r_Time_parse((const MoValue[]){t4}, MO_KIND_NONE);
    L8 = t5;
    if (!mo_is(L8, 0)) goto F85;
    L9 = L8.as.xs[0];
    L10 = L9;
    mo_disown_in(L0);
    MoValue t6 MO_U = L0;
    MoValue t7 MO_U = L10;
    MoValue t8 MO_U = mo_variant(0, 1, (const MoValue[]){t7});
    MoValue t9 MO_U = mo_tuple(2, (const MoValue[]){t6, t8});
    t3 = t9;
    goto E84;
    F85:;
    if (!mo_is(L8, 1)) goto F86;
    mo_disown_in(L0);
    MoValue t10 MO_U = L0;
    MoValue t11 MO_U = L1;
    MoValue t12 MO_U = L2;
    MoValue t13 MO_U = f44(t10, t11, t12, mo_str("conversation timestamp is not supported RFC 3339", 48));
    MoValue t14 MO_U = mo_variant(1, 0, NULL);
    MoValue t15 MO_U = mo_tuple(2, (const MoValue[]){t13, t14});
    t3 = t15;
    goto E84;
    F86:;
    mo_crash(11);
    E84:;
    t0 = t3;
    goto E82;
    F83:;
    if (!mo_is(L4, 1)) goto F87;
    mo_disown_in(L0);
    MoValue t16 MO_U = L0;
    MoValue t17 MO_U = mo_variant(1, 0, NULL);
    MoValue t18 MO_U = mo_tuple(2, (const MoValue[]){t16, t17});
    t0 = t18;
    goto E82;
    F87:;
    if (!mo_is(L4, 0)) goto F90;
    L11 = L4.as.xs[0];
    if (!mo_is(L11, 7)) goto F90;
    goto E89;
    F90:;
    if (!mo_is(L4, 0)) goto F91;
    L12 = L4.as.xs[0];
    if (!mo_is(L12, 8)) goto F91;
    goto E89;
    F91:;
    if (!mo_is(L4, 0)) goto F92;
    L13 = L4.as.xs[0];
    if (!mo_is(L13, 10)) goto F92;
    goto E89;
    F92:;
    if (!mo_is(L4, 0)) goto F93;
    L14 = L4.as.xs[0];
    if (!mo_is(L14, 11)) goto F93;
    goto E89;
    F93:;
    if (!mo_is(L4, 0)) goto F88;
    L15 = L4.as.xs[0];
    if (!mo_is(L15, 12)) goto F88;
    E89:;
    MoValue t19 MO_U = L0;
    MoValue t20 MO_U = L1;
    MoValue t21 MO_U = L2;
    MoValue t22 MO_U = f44(t19, t20, t21, mo_str("conversation timestamp is not a string", 38));
    MoValue t23 MO_U = mo_variant(1, 0, NULL);
    MoValue t24 MO_U = mo_tuple(2, (const MoValue[]){t22, t23});
    t0 = t24;
    goto E82;
    F88:;
    mo_crash(12);
    E82:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f27() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = L18; V_[19] = L19; V_[20] = L20; V_[21] = L21; V_[22] = L22; V_[23] = L23; V_[24] = L24; V_[25] = L25; V_[26] = L26; V_[27] = L27; V_[28] = L28; V_[29] = L29; V_[30] = L30; V_[31] = L31; V_[32] = L32; V_[33] = L33; V_[34] = L34; V_[35] = L35; V_[36] = R; } while (0)
#define LOAD_f27() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; L18 = V_[18]; L19 = V_[19]; L20 = V_[20]; L21 = V_[21]; L22 = V_[22]; L23 = V_[23]; L24 = V_[24]; L25 = V_[25]; L26 = V_[26]; L27 = V_[27]; L28 = V_[28]; L29 = V_[29]; L30 = V_[30]; L31 = V_[31]; L32 = V_[32]; L33 = V_[33]; L34 = V_[34]; L35 = V_[35]; R = V_[36]; } while (0)
MO_U static MoValue f27(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("message_record");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    MoValue L21 MO_U = MO_NONE_V;
    MoValue L22 MO_U = MO_NONE_V;
    MoValue L23 MO_U = MO_NONE_V;
    MoValue L24 MO_U = MO_NONE_V;
    MoValue L25 MO_U = MO_NONE_V;
    MoValue L26 MO_U = MO_NONE_V;
    MoValue L27 MO_U = MO_NONE_V;
    MoValue L28 MO_U = MO_NONE_V;
    MoValue L29 MO_U = MO_NONE_V;
    MoValue L30 MO_U = MO_NONE_V;
    MoValue L31 MO_U = MO_NONE_V;
    MoValue L32 MO_U = MO_NONE_V;
    MoValue L33 MO_U = MO_NONE_V;
    MoValue L34 MO_U = MO_NONE_V;
    MoValue L35 MO_U = MO_NONE_V;
    MoValue V_[37];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 37, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L2;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("message", 7)}, MO_KIND_NONE);
    L3 = t2;
    if (!mo_is(L3, 0)) goto F97;
    L4 = L3.as.xs[0];
    if (!mo_is(L4, 7)) goto F97;
    L5 = L4.as.xs[0];
    L6 = L5;
    MoValue t3 MO_U = L6;
    t0 = t3;
    goto E96;
    F97:;
    if (!mo_is(L3, 1)) goto F100;
    goto E99;
    F100:;
    if (!mo_is(L3, 0)) goto F101;
    L7 = L3.as.xs[0];
    if (!mo_is(L7, 9)) goto F101;
    goto E99;
    F101:;
    if (!mo_is(L3, 0)) goto F102;
    L8 = L3.as.xs[0];
    if (!mo_is(L8, 8)) goto F102;
    goto E99;
    F102:;
    if (!mo_is(L3, 0)) goto F103;
    L9 = L3.as.xs[0];
    if (!mo_is(L9, 10)) goto F103;
    goto E99;
    F103:;
    if (!mo_is(L3, 0)) goto F104;
    L10 = L3.as.xs[0];
    if (!mo_is(L10, 11)) goto F104;
    goto E99;
    F104:;
    if (!mo_is(L3, 0)) goto F98;
    L11 = L3.as.xs[0];
    if (!mo_is(L11, 12)) goto F98;
    E99:;
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    mo_disown_in(L0);
    MoValue t4 MO_U = L0;
    MoValue t5 MO_U = L1.as.xs[0];
    MoValue t6 MO_U = L1.as.xs[1];
    SAVE_f27();
    uint64_t w7 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t8 MO_U = f44(t4, t5, t6, mo_str("conversation message is not an object", 37));
    FR_.walking = false; if (mo_walks != w7) LOAD_f27();
    R = t8;
    goto X95;
    t0 = MO_NONE_V;
    goto E96;
    F98:;
    mo_crash(13);
    E96:;
    L12 = t0;
    MoValue t9 MO_U = MO_NONE_V;
    MoValue t10 MO_U = L12;
    MoValue t11 MO_U = mo_r_Map_get((const MoValue[]){t10, mo_str("role", 4)}, MO_KIND_NONE);
    L13 = t11;
    if (!mo_is(L13, 0)) goto F107;
    L14 = L13.as.xs[0];
    if (!mo_is(L14, 9)) goto F107;
    L15 = L14.as.xs[0];
    L16 = L15;
    MoValue t12 MO_U = L16;
    t9 = t12;
    goto E106;
    F107:;
    if (!mo_is(L13, 1)) goto F110;
    goto E109;
    F110:;
    if (!mo_is(L13, 0)) goto F111;
    L17 = L13.as.xs[0];
    if (!mo_is(L17, 7)) goto F111;
    goto E109;
    F111:;
    if (!mo_is(L13, 0)) goto F112;
    L18 = L13.as.xs[0];
    if (!mo_is(L18, 8)) goto F112;
    goto E109;
    F112:;
    if (!mo_is(L13, 0)) goto F113;
    L19 = L13.as.xs[0];
    if (!mo_is(L19, 10)) goto F113;
    goto E109;
    F113:;
    if (!mo_is(L13, 0)) goto F114;
    L20 = L13.as.xs[0];
    if (!mo_is(L20, 11)) goto F114;
    goto E109;
    F114:;
    if (!mo_is(L13, 0)) goto F108;
    L21 = L13.as.xs[0];
    if (!mo_is(L21, 12)) goto F108;
    E109:;
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    mo_disown_in(L0);
    MoValue t13 MO_U = L0;
    MoValue t14 MO_U = L1.as.xs[0];
    MoValue t15 MO_U = L1.as.xs[1];
    SAVE_f27();
    uint64_t w16 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t17 MO_U = f44(t13, t14, t15, mo_str("conversation message role is not a string", 41));
    FR_.walking = false; if (mo_walks != w16) LOAD_f27();
    R = t17;
    goto X95;
    t9 = MO_NONE_V;
    goto E106;
    F108:;
    mo_crash(14);
    E106:;
    L22 = t9;
    MoValue t18 MO_U = L22;
    MoValue t19 MO_U = L1.as.xs[2];
    MoValue t20 MO_U = mo_bool(mo_compare(MO_NE, t18, t19));
    if (t20.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
        mo_disown_in(L0);
        MoValue t21 MO_U = L0;
        MoValue t22 MO_U = L1.as.xs[0];
        MoValue t23 MO_U = L1.as.xs[1];
        SAVE_f27();
        uint64_t w24 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t25 MO_U = f44(t21, t22, t23, mo_str("top-level type and message role disagree", 40));
        FR_.walking = false; if (mo_walks != w24) LOAD_f27();
        R = t25;
        goto X95;
    }
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    MoValue t26 MO_U = L0;
    MoValue t27 MO_U = L1.as.xs[0];
    MoValue t28 MO_U = L1.as.xs[1];
    mo_disown_in(L12);
    MoValue t29 MO_U = L12;
    SAVE_f27();
    uint64_t w30 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t31 MO_U = f28(t26, t27, t28, t29);
    FR_.walking = false; if (mo_walks != w30) LOAD_f27();
    L23 = t31;
    MoValue t32 MO_U = MO_NONE_V;
    MoValue t33 MO_U = L12;
    MoValue t34 MO_U = mo_r_Map_get((const MoValue[]){t33, mo_str("content", 7)}, MO_KIND_NONE);
    L24 = t34;
    if (!mo_is(L24, 0)) goto F117;
    L25 = L24.as.xs[0];
    if (!mo_is(L25, 9)) goto F117;
    L26 = L25.as.xs[0];
    L27 = L26;
    MoValue t35 MO_U = L23.as.xs[0];
    mo_disown_in(t35);
    MoValue t36 MO_U = L22;
    MoValue t37 MO_U = L27;
    MoValue t38 MO_U = L1.as.xs[0];
    MoValue t39 MO_U = L1.as.xs[1];
    MoValue t40 MO_U = mo_variant(1, 0, NULL);
    MoValue t41 MO_U = f32(t36, t37, t38, t39, mo_i64(INT64_C(0)), t40);
    mo_disown_in(t41);
    MoValue t42 MO_U = mo_list_of(1, (const MoValue[]){t41});
    MoValue t43 MO_U = mo_record(41, 2, (const MoValue[]){t35, t42});
    t32 = t43;
    goto E116;
    F117:;
    if (!mo_is(L24, 0)) goto F118;
    L28 = L24.as.xs[0];
    if (!mo_is(L28, 8)) goto F118;
    L29 = L28.as.xs[0];
    L30 = L29;
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    MoValue t44 MO_U = L23.as.xs[0];
    mo_disown_in(t44);
    MoValue t45 MO_U = L22;
    MoValue t46 MO_U = L1.as.xs[0];
    MoValue t47 MO_U = L1.as.xs[1];
    MoValue t48 MO_U = L30;
    SAVE_f27();
    uint64_t w49 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t50 MO_U = f30(t44, t45, t46, t47, t48);
    FR_.walking = false; if (mo_walks != w49) LOAD_f27();
    t32 = t50;
    goto E116;
    F118:;
    if (!mo_is(L24, 1)) goto F121;
    goto E120;
    F121:;
    if (!mo_is(L24, 0)) goto F122;
    L31 = L24.as.xs[0];
    if (!mo_is(L31, 7)) goto F122;
    goto E120;
    F122:;
    if (!mo_is(L24, 0)) goto F123;
    L32 = L24.as.xs[0];
    if (!mo_is(L32, 10)) goto F123;
    goto E120;
    F123:;
    if (!mo_is(L24, 0)) goto F124;
    L33 = L24.as.xs[0];
    if (!mo_is(L33, 11)) goto F124;
    goto E120;
    F124:;
    if (!mo_is(L24, 0)) goto F119;
    L34 = L24.as.xs[0];
    if (!mo_is(L34, 12)) goto F119;
    E120:;
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    MoValue t51 MO_U = L23.as.xs[0];
    MoValue t52 MO_U = L1.as.xs[0];
    MoValue t53 MO_U = L1.as.xs[1];
    SAVE_f27();
    uint64_t w54 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t55 MO_U = f44(t51, t52, t53, mo_str("conversation content is neither text nor a block array", 54));
    FR_.walking = false; if (mo_walks != w54) LOAD_f27();
    R = t55;
    goto X95;
    t32 = MO_NONE_V;
    goto E116;
    F119:;
    mo_crash(15);
    E116:;
    L35 = t32;
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    MoValue t56 MO_U = L35.as.xs[0];
    MoValue t57 MO_U = L1;
    MoValue t58 MO_U = L23.as.xs[1];
    MoValue t59 MO_U = L35.as.xs[1];
    SAVE_f27();
    uint64_t w60 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t61 MO_U = f29(t56, t57, t58, t59);
    FR_.walking = false; if (mo_walks != w60) LOAD_f27();
    R = t61;
    X95:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f27
#undef LOAD_f27
MO_U static MoValue f28(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("identity_of");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L3;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("id", 2)}, MO_KIND_NONE);
    L4 = t2;
    if (!mo_is(L4, 0)) goto F128;
    L5 = L4.as.xs[0];
    if (!mo_is(L5, 9)) goto F128;
    L6 = L5.as.xs[0];
    L7 = L6;
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L7;
    MoValue t5 MO_U = L7;
    MoValue t6 MO_U = mo_record(43, 3, (const MoValue[]){mo_str("provided", 8), t4, t5});
    MoValue t7 MO_U = mo_tuple(2, (const MoValue[]){t3, t6});
    t0 = t7;
    goto E127;
    F128:;
    if (!mo_is(L4, 1)) goto F129;
    MoValue t8 MO_U = L2;
    MoValue t9 MO_U = mo_concat(2, (const MoValue[]){mo_str("physical:", 9), t8});
    L8 = t9;
    mo_disown_in(L0);
    MoValue t10 MO_U = L0;
    MoValue t11 MO_U = L2;
    MoValue t12 MO_U = mo_concat(1, (const MoValue[]){t11});
    MoValue t13 MO_U = L8;
    MoValue t14 MO_U = mo_record(43, 3, (const MoValue[]){mo_str("physical", 8), t12, t13});
    MoValue t15 MO_U = mo_tuple(2, (const MoValue[]){t10, t14});
    t0 = t15;
    goto E127;
    F129:;
    if (!mo_is(L4, 0)) goto F132;
    L9 = L4.as.xs[0];
    if (!mo_is(L9, 7)) goto F132;
    goto E131;
    F132:;
    if (!mo_is(L4, 0)) goto F133;
    L10 = L4.as.xs[0];
    if (!mo_is(L10, 8)) goto F133;
    goto E131;
    F133:;
    if (!mo_is(L4, 0)) goto F134;
    L11 = L4.as.xs[0];
    if (!mo_is(L11, 10)) goto F134;
    goto E131;
    F134:;
    if (!mo_is(L4, 0)) goto F135;
    L12 = L4.as.xs[0];
    if (!mo_is(L12, 11)) goto F135;
    goto E131;
    F135:;
    if (!mo_is(L4, 0)) goto F130;
    L13 = L4.as.xs[0];
    if (!mo_is(L13, 12)) goto F130;
    E131:;
    MoValue t16 MO_U = L2;
    MoValue t17 MO_U = mo_concat(2, (const MoValue[]){mo_str("physical:", 9), t16});
    L14 = t17;
    MoValue t18 MO_U = L0;
    MoValue t19 MO_U = L1;
    MoValue t20 MO_U = L2;
    MoValue t21 MO_U = f44(t18, t19, t20, mo_str("message id is not a string", 26));
    MoValue t22 MO_U = L2;
    MoValue t23 MO_U = mo_concat(1, (const MoValue[]){t22});
    MoValue t24 MO_U = L14;
    MoValue t25 MO_U = mo_record(43, 3, (const MoValue[]){mo_str("physical", 8), t23, t24});
    MoValue t26 MO_U = mo_tuple(2, (const MoValue[]){t21, t25});
    t0 = t26;
    goto E127;
    F130:;
    mo_crash(16);
    E127:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a0(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("retain_message");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = mo_variant(54, 0, NULL);
    MoValue t2 MO_U = mo_bool(mo_compare(MO_EQ, t0, t1));
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f29() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = R; } while (0)
#define LOAD_f29() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; R = V_[18]; } while (0)
MO_U static MoValue f29(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("retain_message");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue V_[19];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 19, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L4 = t0;
    MoValue t1 MO_U = L3;
    MoValue t2 MO_U = mo_r_List_size((const MoValue[]){t1}, MO_KIND_NONE);
    MoValue t3 MO_U = mo_bool(t2.as.u == mo_i64(INT64_C(0)).as.u);
    if (t3.as.b) {
        mo_disown_in(L4);
        MoValue t4 MO_U = L4;
        R = t4;
        goto X137;
    }
    MoValue t5 MO_U = MO_NONE_V;
    MoValue t6 MO_U = L1.as.xs[3];
    MoValue t7 MO_U = mo_bool(mo_compare(MO_EQ, t6, mo_str("", 0)));
    if (t7.as.b) {
        MoValue t8 MO_U = L1.as.xs[0];
        MoValue t9 MO_U = mo_concat(2, (const MoValue[]){mo_str("file:", 5), t8});
        t5 = t9;
    } else {
        MoValue t10 MO_U = L1.as.xs[3];
        MoValue t11 MO_U = mo_concat(2, (const MoValue[]){mo_str("session:", 8), t10});
        t5 = t11;
    }
    L5 = t5;
    MoValue t12 MO_U = MO_NONE_V;
    MoValue t13 MO_U = L1.as.xs[3];
    MoValue t14 MO_U = mo_bool(mo_compare(MO_EQ, t13, mo_str("", 0)));
    if (t14.as.b) {
        MoValue t15 MO_U = L1.as.xs[0];
        MoValue t16 MO_U = mo_concat(3, (const MoValue[]){mo_str("(missing session id in ", 23), t15, mo_str(")", 1)});
        t12 = t16;
    } else {
        MoValue t17 MO_U = L1.as.xs[3];
        t12 = t17;
    }
    L6 = t12;
    MoValue t18 MO_U = L1.as.xs[0];
    MoValue t19 MO_U = L5;
    MoValue t20 MO_U = L1.as.xs[2];
    MoValue t21 MO_U = L2.as.xs[0];
    MoValue t22 MO_U = L2.as.xs[1];
    MoValue t23 MO_U = mo_tuple(5, (const MoValue[]){t18, t19, t20, t21, t22});
    MoValue t24 MO_U = mo_r_Json_encode((const MoValue[]){t23}, 0);
    L7 = t24;
    MoValue t25 MO_U = L4;
    MoValue t26 MO_U = t25.as.xs[0];
    MoValue t27 MO_U = L7;
    MoValue t28 MO_U = mo_r_Map_get((const MoValue[]){t26, t27}, MO_KIND_NONE);
    L8 = t28;
    mo_disown_in(L8);
    MoValue t29 MO_U = L8;
    L9 = t29;
    MoValue t30 MO_U = mo_bool(true);
    if (!mo_is(L9, 1)) goto F138;
    goto E139;
    F138:;
    t30 = mo_bool(false);
    E139:;
    MoValue t31 MO_U = mo_bool(false);
    if (t30.as.b) {
        MoValue t32 MO_U = L4;
        MoValue t33 MO_U = t32.as.xs[0];
        MoValue t34 MO_U = mo_r_Map_size((const MoValue[]){t33}, MO_KIND_NONE);
        MoValue t35 MO_U = f41(t34);
        MoValue t36 MO_U = mo_bool(!t35.as.b);
        t31 = t36;
    }
    if (t31.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f29(); mo_walk(&FR_); LOAD_f29(); }
        mo_disown_in(L4);
        MoValue t37 MO_U = L4;
        MoValue t38 MO_U = L1.as.xs[0];
        MoValue t39 MO_U = L1.as.xs[1];
        SAVE_f29();
        uint64_t w40 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t41 MO_U = f44(t37, t38, t39, mo_str("more than 100000 logical messages would be retained", 51));
        FR_.walking = false; if (mo_walks != w40) LOAD_f29();
        R = t41;
        goto X137;
    }
    MoValue t42 MO_U = f11();
    MoValue t43 MO_U = L4.as.xs[7];
    MoValue t44 MO_U = mo_r_Int_saturating_sub((const MoValue[]){t42, t43}, 7);
    L10 = t44;
    MoValue t45 MO_U = L3;
    MoValue t46 MO_U = L10;
    MoValue t47 MO_U = mo_r_List_take((const MoValue[]){t45, t46}, MO_KIND_NONE);
    L11 = t47;
    MoValue t48 MO_U = L11;
    MoValue t49 MO_U = mo_r_List_size((const MoValue[]){t48}, MO_KIND_NONE);
    MoValue t50 MO_U = L3;
    MoValue t51 MO_U = mo_r_List_size((const MoValue[]){t50}, MO_KIND_NONE);
    MoValue t52 MO_U = mo_bool(t49.as.u < t51.as.u);
    if (t52.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f29(); mo_walk(&FR_); LOAD_f29(); }
        MoValue t53 MO_U = L4;
        MoValue t54 MO_U = L1.as.xs[0];
        MoValue t55 MO_U = L1.as.xs[1];
        SAVE_f29();
        uint64_t w56 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t57 MO_U = f44(t53, t54, t55, mo_str("more than 500000 searchable blocks would be retained", 52));
        FR_.walking = false; if (mo_walks != w56) LOAD_f29();
        L4 = t57;
    }
    MoValue t58 MO_U = L4.as.xs[7];
    MoValue t59 MO_U = L11;
    MoValue t60 MO_U = mo_r_List_size((const MoValue[]){t59}, MO_KIND_NONE);
    MoValue t61 MO_U = mo_add_u64(t58, t60, 17);
    MoValue t62 MO_U = L4;
    MoValue t63 MO_U = mo_set_field(t62, 7, t61);
    L4 = t63;
    MoValue t64 MO_U = MO_NONE_V;
    MoValue t65 MO_U = L11;
    MoValue t66 MO_U = mo_closure(a0, 83, 0, NULL);
    MoValue t67 MO_U = mo_r_List_any_q((const MoValue[]){t65, t66}, MO_KIND_NONE);
    if (t67.as.b) {
        MoValue t68 MO_U = L1.as.xs[4];
        t64 = t68;
    } else {
        MoValue t69 MO_U = mo_variant(1, 0, NULL);
        t64 = t69;
    }
    L12 = t64;
    MoValue t70 MO_U = L8;
    L13 = t70;
    if (!mo_is(L13, 0)) goto F142;
    L14 = L13.as.xs[0];
    L15 = L14;
    MoValue t71 MO_U = L7;
    MoValue t72 MO_U = L5;
    MoValue t73 MO_U = L6;
    MoValue t74 MO_U = L1.as.xs[2];
    MoValue t75 MO_U = L2.as.xs[2];
    MoValue t76 MO_U = L1.as.xs[0];
    MoValue t77 MO_U = L15.as.xs[6];
    MoValue t78 MO_U = L15.as.xs[7];
    MoValue t79 MO_U = L12;
    MoValue t80 MO_U = f42(t78, t79);
    MoValue t81 MO_U = L15.as.xs[8];
    MoValue t82 MO_U = L11;
    MoValue t83 MO_U = mo_r_List_concat((const MoValue[]){t81, t82}, MO_KIND_NONE);
    MoValue t84 MO_U = mo_record(32, 9, (const MoValue[]){t71, t72, t73, t74, t75, t76, t77, t80, t83});
    L16 = t84;
    MoValue t85 MO_U = L4;
    MoValue t86 MO_U = t85.as.xs[0];
    MoValue t87 MO_U = L7;
    MoValue t88 MO_U = L16;
    mo_disown_in(t88);
    MoValue t89 MO_U = mo_r_Map_set((const MoValue[]){t86, t87, t88}, MO_KIND_UNIQUE);
    MoValue t90 MO_U = L4;
    MoValue t91 MO_U = mo_set_field(t90, 0, t89);
    L4 = t91;
    goto E141;
    F142:;
    if (!mo_is(L13, 1)) goto F143;
    MoValue t92 MO_U = L7;
    MoValue t93 MO_U = L5;
    MoValue t94 MO_U = L6;
    MoValue t95 MO_U = L1.as.xs[2];
    MoValue t96 MO_U = L2.as.xs[2];
    MoValue t97 MO_U = L1.as.xs[0];
    MoValue t98 MO_U = L1.as.xs[1];
    MoValue t99 MO_U = L12;
    MoValue t100 MO_U = L11;
    MoValue t101 MO_U = mo_record(32, 9, (const MoValue[]){t92, t93, t94, t95, t96, t97, t98, t99, t100});
    L17 = t101;
    MoValue t102 MO_U = L4;
    MoValue t103 MO_U = t102.as.xs[0];
    MoValue t104 MO_U = L7;
    MoValue t105 MO_U = L17;
    mo_disown_in(t105);
    MoValue t106 MO_U = mo_r_Map_set((const MoValue[]){t103, t104, t105}, MO_KIND_UNIQUE);
    MoValue t107 MO_U = L4;
    MoValue t108 MO_U = mo_set_field(t107, 0, t106);
    L4 = t108;
    goto E141;
    F143:;
    mo_crash(18);
    E141:;
    MoValue t109 MO_U = L4;
    R = t109;
    X137:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f29
#undef LOAD_f29
#define SAVE_f30() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = R; } while (0)
#define LOAD_f30() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; R = V_[9]; } while (0)
#define ROOTS_f30(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, R}; mo_compact(m, r_, 10); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; R = r_[9]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f30(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("blocks_of");
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    size_t m145 MO_U = 0, k145 MO_U = 0;
    MoValue V_[10];
    size_t *const M_[] = {&F_, &m145, &k145};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 10, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_record(41, 2, (const MoValue[]){t0, t1});
    L5 = t2;
    MoValue t3 MO_U = L4;
    MoValue t4 MO_U = mo_r_List_enumerate((const MoValue[]){t3}, MO_KIND_NONE);
    L6 = t4;
    {
        m145 = mo_mark(); k145 = 0;
        for (uint32_t i145 = 0; i145 < L6.aux; i145++) {
            MoValue t5 MO_U = L6.as.xs[i145];
            L7 = t5;
            if (mo_walk_due(&FR_)) { SAVE_f30(); mo_walk(&FR_); LOAD_f30(); }
            MoValue t6 MO_U = L5.as.xs[0];
            mo_disown_in(t6);
            MoValue t7 MO_U = L1;
            MoValue t8 MO_U = L2;
            MoValue t9 MO_U = L3;
            MoValue t10 MO_U = L7.as.xs[0];
            MoValue t11 MO_U = L7.as.xs[1];
            SAVE_f30();
            uint64_t w12 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t13 MO_U = f31(t6, t7, t8, t9, t10, t11);
            FR_.walking = false; if (mo_walks != w12) LOAD_f30();
            L8 = t13;
            MoValue t14 MO_U = L8.as.xs[0];
            MoValue t15 MO_U = L5;
            MoValue t16 MO_U = mo_set_field(t15, 0, t14);
            L5 = t16;
            MoValue t17 MO_U = L5.as.xs[1];
            MoValue t18 MO_U = L8.as.xs[1];
            MoValue t19 MO_U = mo_r_List_concat((const MoValue[]){t17, t18}, MO_KIND_NONE);
            MoValue t20 MO_U = L5;
            MoValue t21 MO_U = mo_set_field(t20, 1, t19);
            L5 = t21;
            ROOTS_f30(m145, k145);
        }
    }
    MoValue t22 MO_U = L5;
    R = t22;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f30
#undef SAVE_f30
#undef LOAD_f30
#define SAVE_f31() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = L18; V_[19] = L19; V_[20] = L20; V_[21] = L21; V_[22] = L22; V_[23] = L23; V_[24] = L24; V_[25] = L25; V_[26] = L26; V_[27] = L27; V_[28] = L28; V_[29] = L29; V_[30] = L30; V_[31] = L31; V_[32] = R; } while (0)
#define LOAD_f31() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; L18 = V_[18]; L19 = V_[19]; L20 = V_[20]; L21 = V_[21]; L22 = V_[22]; L23 = V_[23]; L24 = V_[24]; L25 = V_[25]; L26 = V_[26]; L27 = V_[27]; L28 = V_[28]; L29 = V_[29]; L30 = V_[30]; L31 = V_[31]; R = V_[32]; } while (0)
MO_U static MoValue f31(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("block_of");
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    MoValue L21 MO_U = MO_NONE_V;
    MoValue L22 MO_U = MO_NONE_V;
    MoValue L23 MO_U = MO_NONE_V;
    MoValue L24 MO_U = MO_NONE_V;
    MoValue L25 MO_U = MO_NONE_V;
    MoValue L26 MO_U = MO_NONE_V;
    MoValue L27 MO_U = MO_NONE_V;
    MoValue L28 MO_U = MO_NONE_V;
    MoValue L29 MO_U = MO_NONE_V;
    MoValue L30 MO_U = MO_NONE_V;
    MoValue L31 MO_U = MO_NONE_V;
    MoValue V_[33];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 33, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L5;
    L6 = t1;
    if (!mo_is(L6, 7)) goto F148;
    L7 = L6.as.xs[0];
    L8 = L7;
    MoValue t2 MO_U = L8;
    t0 = t2;
    goto E147;
    F148:;
    if (!mo_is(L6, 9)) goto F151;
    goto E150;
    F151:;
    if (!mo_is(L6, 8)) goto F152;
    goto E150;
    F152:;
    if (!mo_is(L6, 10)) goto F153;
    goto E150;
    F153:;
    if (!mo_is(L6, 11)) goto F154;
    goto E150;
    F154:;
    if (!mo_is(L6, 12)) goto F149;
    E150:;
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L2;
    MoValue t5 MO_U = L3;
    MoValue t6 MO_U = L4;
    MoValue t7 MO_U = mo_concat(3, (const MoValue[]){mo_str("content block ", 14), t6, mo_str(" is not an object", 17)});
    MoValue t8 MO_U = f44(t3, t4, t5, t7);
    MoValue t9 MO_U = mo_list_of(0, NULL);
    MoValue t10 MO_U = mo_record(41, 2, (const MoValue[]){t8, t9});
    R = t10;
    goto X146;
    t0 = MO_NONE_V;
    goto E147;
    F149:;
    mo_crash(19);
    E147:;
    L9 = t0;
    MoValue t11 MO_U = MO_NONE_V;
    MoValue t12 MO_U = L9;
    MoValue t13 MO_U = mo_r_Map_get((const MoValue[]){t12, mo_str("type", 4)}, MO_KIND_NONE);
    L10 = t13;
    if (!mo_is(L10, 0)) goto F157;
    L11 = L10.as.xs[0];
    if (!mo_is(L11, 9)) goto F157;
    L12 = L11.as.xs[0];
    L13 = L12;
    MoValue t14 MO_U = L13;
    t11 = t14;
    goto E156;
    F157:;
    if (!mo_is(L10, 1)) goto F160;
    goto E159;
    F160:;
    if (!mo_is(L10, 0)) goto F161;
    L14 = L10.as.xs[0];
    if (!mo_is(L14, 7)) goto F161;
    goto E159;
    F161:;
    if (!mo_is(L10, 0)) goto F162;
    L15 = L10.as.xs[0];
    if (!mo_is(L15, 8)) goto F162;
    goto E159;
    F162:;
    if (!mo_is(L10, 0)) goto F163;
    L16 = L10.as.xs[0];
    if (!mo_is(L16, 10)) goto F163;
    goto E159;
    F163:;
    if (!mo_is(L10, 0)) goto F164;
    L17 = L10.as.xs[0];
    if (!mo_is(L17, 11)) goto F164;
    goto E159;
    F164:;
    if (!mo_is(L10, 0)) goto F158;
    L18 = L10.as.xs[0];
    if (!mo_is(L18, 12)) goto F158;
    E159:;
    mo_disown_in(L0);
    MoValue t15 MO_U = L0;
    MoValue t16 MO_U = L2;
    MoValue t17 MO_U = L3;
    MoValue t18 MO_U = L4;
    MoValue t19 MO_U = mo_concat(3, (const MoValue[]){mo_str("content block ", 14), t18, mo_str(" has no string type", 19)});
    MoValue t20 MO_U = f44(t15, t16, t17, t19);
    MoValue t21 MO_U = mo_list_of(0, NULL);
    MoValue t22 MO_U = mo_record(41, 2, (const MoValue[]){t20, t21});
    R = t22;
    goto X146;
    t11 = MO_NONE_V;
    goto E156;
    F158:;
    mo_crash(20);
    E156:;
    L19 = t11;
    if (mo_walk_due(&FR_)) { SAVE_f31(); mo_walk(&FR_); LOAD_f31(); }
    MoValue t23 MO_U = L0;
    MoValue t24 MO_U = L2;
    MoValue t25 MO_U = L3;
    MoValue t26 MO_U = L4;
    mo_disown_in(L9);
    MoValue t27 MO_U = L9;
    SAVE_f31();
    uint64_t w28 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t29 MO_U = f37(t23, t24, t25, t26, t27);
    FR_.walking = false; if (mo_walks != w28) LOAD_f31();
    L20 = t29;
    MoValue t30 MO_U = L20.as.xs[0];
    L21 = t30;
    MoValue t31 MO_U = MO_NONE_V;
    MoValue t32 MO_U = L19;
    L22 = t32;
    if (!mo_equal(L22, mo_str("text", 4))) goto F167;
    MoValue t33 MO_U = MO_NONE_V;
    MoValue t34 MO_U = L9;
    MoValue t35 MO_U = mo_r_Map_get((const MoValue[]){t34, mo_str("text", 4)}, MO_KIND_NONE);
    L23 = t35;
    if (!mo_is(L23, 0)) goto F169;
    L24 = L23.as.xs[0];
    if (!mo_is(L24, 9)) goto F169;
    L25 = L24.as.xs[0];
    L26 = L25;
    mo_disown_in(L21);
    MoValue t36 MO_U = L21;
    MoValue t37 MO_U = L1;
    MoValue t38 MO_U = L26;
    MoValue t39 MO_U = L2;
    MoValue t40 MO_U = L3;
    MoValue t41 MO_U = L4;
    MoValue t42 MO_U = L20.as.xs[1];
    MoValue t43 MO_U = f32(t37, t38, t39, t40, t41, t42);
    mo_disown_in(t43);
    MoValue t44 MO_U = mo_list_of(1, (const MoValue[]){t43});
    MoValue t45 MO_U = mo_record(41, 2, (const MoValue[]){t36, t44});
    t33 = t45;
    goto E168;
    F169:;
    if (!mo_is(L23, 1)) goto F172;
    goto E171;
    F172:;
    if (!mo_is(L23, 0)) goto F173;
    L27 = L23.as.xs[0];
    if (!mo_is(L27, 7)) goto F173;
    goto E171;
    F173:;
    if (!mo_is(L23, 0)) goto F174;
    L28 = L23.as.xs[0];
    if (!mo_is(L28, 8)) goto F174;
    goto E171;
    F174:;
    if (!mo_is(L23, 0)) goto F175;
    L29 = L23.as.xs[0];
    if (!mo_is(L29, 10)) goto F175;
    goto E171;
    F175:;
    if (!mo_is(L23, 0)) goto F176;
    L30 = L23.as.xs[0];
    if (!mo_is(L30, 11)) goto F176;
    goto E171;
    F176:;
    if (!mo_is(L23, 0)) goto F170;
    L31 = L23.as.xs[0];
    if (!mo_is(L31, 12)) goto F170;
    E171:;
    mo_disown_in(L21);
    MoValue t46 MO_U = L21;
    MoValue t47 MO_U = L2;
    MoValue t48 MO_U = L3;
    MoValue t49 MO_U = L4;
    MoValue t50 MO_U = mo_concat(3, (const MoValue[]){mo_str("text block ", 11), t49, mo_str(" has no string text", 19)});
    MoValue t51 MO_U = f44(t46, t47, t48, t50);
    MoValue t52 MO_U = mo_list_of(0, NULL);
    MoValue t53 MO_U = mo_record(41, 2, (const MoValue[]){t51, t52});
    t33 = t53;
    goto E168;
    F170:;
    mo_crash(21);
    E168:;
    t31 = t33;
    goto E166;
    F167:;
    if (!mo_equal(L22, mo_str("thinking", 8))) goto F180;
    goto E179;
    F180:;
    if (!mo_equal(L22, mo_str("redacted_thinking", 17))) goto F181;
    goto E179;
    F181:;
    if (!mo_equal(L22, mo_str("image", 5))) goto F178;
    E179:;
    mo_disown_in(L21);
    MoValue t54 MO_U = L21;
    MoValue t55 MO_U = mo_list_of(0, NULL);
    MoValue t56 MO_U = mo_record(41, 2, (const MoValue[]){t54, t55});
    t31 = t56;
    goto E166;
    F178:;
    if (!mo_equal(L22, mo_str("tool_use", 8))) goto F183;
    if (mo_walk_due(&FR_)) { SAVE_f31(); mo_walk(&FR_); LOAD_f31(); }
    mo_disown_in(L21);
    MoValue t57 MO_U = L21;
    MoValue t58 MO_U = L2;
    MoValue t59 MO_U = L3;
    MoValue t60 MO_U = L4;
    MoValue t61 MO_U = L20.as.xs[1];
    mo_disown_in(L9);
    MoValue t62 MO_U = L9;
    SAVE_f31();
    uint64_t w63 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t64 MO_U = f33(t57, t58, t59, t60, t61, t62);
    FR_.walking = false; if (mo_walks != w63) LOAD_f31();
    t31 = t64;
    goto E166;
    F183:;
    if (!mo_equal(L22, mo_str("tool_result", 11))) goto F184;
    if (mo_walk_due(&FR_)) { SAVE_f31(); mo_walk(&FR_); LOAD_f31(); }
    mo_disown_in(L21);
    MoValue t65 MO_U = L21;
    MoValue t66 MO_U = L2;
    MoValue t67 MO_U = L3;
    MoValue t68 MO_U = L4;
    MoValue t69 MO_U = L20.as.xs[1];
    MoValue t70 MO_U = L9;
    SAVE_f31();
    uint64_t w71 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t72 MO_U = f34(t65, t66, t67, t68, t69, t70);
    FR_.walking = false; if (mo_walks != w71) LOAD_f31();
    t31 = t72;
    goto E166;
    F184:;
    MoValue t73 MO_U = L21;
    MoValue t74 MO_U = L2;
    MoValue t75 MO_U = L3;
    MoValue t76 MO_U = L19;
    MoValue t77 MO_U = mo_concat(2, (const MoValue[]){mo_str("unsupported conversation block type ", 36), t76});
    MoValue t78 MO_U = f44(t73, t74, t75, t77);
    MoValue t79 MO_U = mo_list_of(0, NULL);
    MoValue t80 MO_U = mo_record(41, 2, (const MoValue[]){t78, t79});
    t31 = t80;
    goto E166;
    mo_crash(22);
    E166:;
    R = t31;
    X146:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f31
#undef LOAD_f31
MO_U static MoValue f32(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("conversation_block");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_variant(54, 0, NULL);
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_concat(2, (const MoValue[]){t1, mo_str(" text", 5)});
    MoValue t3 MO_U = L1;
    MoValue t4 MO_U = L2;
    MoValue t5 MO_U = L3;
    MoValue t6 MO_U = L4;
    MoValue t7 MO_U = L5;
    MoValue t8 MO_U = mo_record(31, 7, (const MoValue[]){t0, t2, t3, t4, t5, t6, t7});
    R = t8;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f33(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("tool_use");
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L5;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("name", 4)}, MO_KIND_NONE);
    L6 = t2;
    if (!mo_is(L6, 0)) goto F189;
    L7 = L6.as.xs[0];
    if (!mo_is(L7, 9)) goto F189;
    L8 = L7.as.xs[0];
    L9 = L8;
    MoValue t3 MO_U = L9;
    t0 = t3;
    goto E188;
    F189:;
    if (!mo_is(L6, 1)) goto F192;
    goto E191;
    F192:;
    if (!mo_is(L6, 0)) goto F193;
    L10 = L6.as.xs[0];
    if (!mo_is(L10, 7)) goto F193;
    goto E191;
    F193:;
    if (!mo_is(L6, 0)) goto F194;
    L11 = L6.as.xs[0];
    if (!mo_is(L11, 8)) goto F194;
    goto E191;
    F194:;
    if (!mo_is(L6, 0)) goto F195;
    L12 = L6.as.xs[0];
    if (!mo_is(L12, 10)) goto F195;
    goto E191;
    F195:;
    if (!mo_is(L6, 0)) goto F196;
    L13 = L6.as.xs[0];
    if (!mo_is(L13, 11)) goto F196;
    goto E191;
    F196:;
    if (!mo_is(L6, 0)) goto F190;
    L14 = L6.as.xs[0];
    if (!mo_is(L14, 12)) goto F190;
    E191:;
    mo_disown_in(L0);
    MoValue t4 MO_U = L0;
    MoValue t5 MO_U = L1;
    MoValue t6 MO_U = L2;
    MoValue t7 MO_U = L3;
    MoValue t8 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool_use block ", 15), t7, mo_str(" has no string name", 19)});
    MoValue t9 MO_U = f44(t4, t5, t6, t8);
    MoValue t10 MO_U = mo_list_of(0, NULL);
    MoValue t11 MO_U = mo_record(41, 2, (const MoValue[]){t9, t10});
    R = t11;
    goto X187;
    t0 = MO_NONE_V;
    goto E188;
    F190:;
    mo_crash(23);
    E188:;
    L15 = t0;
    MoValue t12 MO_U = MO_NONE_V;
    MoValue t13 MO_U = L5;
    MoValue t14 MO_U = mo_r_Map_get((const MoValue[]){t13, mo_str("input", 5)}, MO_KIND_NONE);
    L16 = t14;
    if (!mo_is(L16, 0)) goto F199;
    L17 = L16.as.xs[0];
    L18 = L17;
    MoValue t15 MO_U = L18;
    t12 = t15;
    goto E198;
    F199:;
    if (!mo_is(L16, 1)) goto F200;
    mo_disown_in(L0);
    MoValue t16 MO_U = L0;
    MoValue t17 MO_U = L1;
    MoValue t18 MO_U = L2;
    MoValue t19 MO_U = L3;
    MoValue t20 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool_use block ", 15), t19, mo_str(" has no input", 13)});
    MoValue t21 MO_U = f44(t16, t17, t18, t20);
    MoValue t22 MO_U = mo_list_of(0, NULL);
    MoValue t23 MO_U = mo_record(41, 2, (const MoValue[]){t21, t22});
    R = t23;
    goto X187;
    t12 = MO_NONE_V;
    goto E198;
    F200:;
    mo_crash(24);
    E198:;
    L19 = t12;
    MoValue t24 MO_U = mo_variant(55, 0, NULL);
    MoValue t25 MO_U = L15;
    MoValue t26 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool ", 5), t25, mo_str(" arguments", 10)});
    MoValue t27 MO_U = L19;
    MoValue t28 MO_U = mo_r_Json_encode((const MoValue[]){t27}, 2);
    MoValue t29 MO_U = L1;
    MoValue t30 MO_U = L2;
    MoValue t31 MO_U = L3;
    MoValue t32 MO_U = L4;
    MoValue t33 MO_U = mo_record(31, 7, (const MoValue[]){t24, t26, t28, t29, t30, t31, t32});
    L20 = t33;
    MoValue t34 MO_U = L0;
    MoValue t35 MO_U = L20;
    mo_disown_in(t35);
    MoValue t36 MO_U = mo_list_of(1, (const MoValue[]){t35});
    MoValue t37 MO_U = mo_record(41, 2, (const MoValue[]){t34, t36});
    R = t37;
    X187:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f34() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = L18; V_[19] = L19; V_[20] = L20; V_[21] = L21; V_[22] = L22; V_[23] = L23; V_[24] = R; } while (0)
#define LOAD_f34() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; L18 = V_[18]; L19 = V_[19]; L20 = V_[20]; L21 = V_[21]; L22 = V_[22]; L23 = V_[23]; R = V_[24]; } while (0)
MO_U static MoValue f34(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("tool_result");
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    MoValue L21 MO_U = MO_NONE_V;
    MoValue L22 MO_U = MO_NONE_V;
    MoValue L23 MO_U = MO_NONE_V;
    MoValue V_[25];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 25, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L5;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("tool_use_id", 11)}, MO_KIND_NONE);
    L6 = t2;
    if (!mo_is(L6, 0)) goto F203;
    L7 = L6.as.xs[0];
    if (!mo_is(L7, 9)) goto F203;
    L8 = L7.as.xs[0];
    L9 = L8;
    MoValue t3 MO_U = L9;
    t0 = t3;
    goto E202;
    F203:;
    if (!mo_is(L6, 1)) goto F204;
    t0 = mo_str("unknown", 7);
    goto E202;
    F204:;
    if (!mo_is(L6, 0)) goto F205;
    mo_disown_in(L0);
    MoValue t4 MO_U = L0;
    MoValue t5 MO_U = L1;
    MoValue t6 MO_U = L2;
    MoValue t7 MO_U = L3;
    MoValue t8 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool_result block ", 18), t7, mo_str(" has a non-string tool_use_id", 29)});
    MoValue t9 MO_U = f44(t4, t5, t6, t8);
    MoValue t10 MO_U = mo_list_of(0, NULL);
    MoValue t11 MO_U = mo_record(41, 2, (const MoValue[]){t9, t10});
    R = t11;
    goto X201;
    t0 = MO_NONE_V;
    goto E202;
    F205:;
    mo_crash(25);
    E202:;
    L10 = t0;
    MoValue t12 MO_U = MO_NONE_V;
    MoValue t13 MO_U = L5;
    MoValue t14 MO_U = mo_r_Map_get((const MoValue[]){t13, mo_str("content", 7)}, MO_KIND_NONE);
    L11 = t14;
    if (!mo_is(L11, 0)) goto F207;
    L12 = L11.as.xs[0];
    if (!mo_is(L12, 9)) goto F207;
    L13 = L12.as.xs[0];
    L14 = L13;
    MoValue t15 MO_U = mo_variant(55, 0, NULL);
    MoValue t16 MO_U = L10;
    MoValue t17 MO_U = mo_concat(2, (const MoValue[]){mo_str("tool result ", 12), t16});
    MoValue t18 MO_U = L14;
    MoValue t19 MO_U = L1;
    MoValue t20 MO_U = L2;
    MoValue t21 MO_U = L3;
    MoValue t22 MO_U = L4;
    MoValue t23 MO_U = mo_record(31, 7, (const MoValue[]){t15, t17, t18, t19, t20, t21, t22});
    L15 = t23;
    mo_disown_in(L0);
    MoValue t24 MO_U = L0;
    MoValue t25 MO_U = L15;
    mo_disown_in(t25);
    MoValue t26 MO_U = mo_list_of(1, (const MoValue[]){t25});
    MoValue t27 MO_U = mo_record(41, 2, (const MoValue[]){t24, t26});
    t12 = t27;
    goto E206;
    F207:;
    if (!mo_is(L11, 0)) goto F208;
    L16 = L11.as.xs[0];
    if (!mo_is(L16, 8)) goto F208;
    L17 = L16.as.xs[0];
    L18 = L17;
    MoValue t28 MO_U = L1;
    MoValue t29 MO_U = L2;
    MoValue t30 MO_U = L3;
    MoValue t31 MO_U = L4;
    MoValue t32 MO_U = L10;
    MoValue t33 MO_U = mo_record(44, 5, (const MoValue[]){t28, t29, t30, t31, t32});
    L19 = t33;
    if (mo_walk_due(&FR_)) { SAVE_f34(); mo_walk(&FR_); LOAD_f34(); }
    mo_disown_in(L0);
    MoValue t34 MO_U = L0;
    MoValue t35 MO_U = L19;
    MoValue t36 MO_U = L18;
    SAVE_f34();
    uint64_t w37 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t38 MO_U = f35(t34, t35, t36);
    FR_.walking = false; if (mo_walks != w37) LOAD_f34();
    t12 = t38;
    goto E206;
    F208:;
    if (!mo_is(L11, 1)) goto F211;
    goto E210;
    F211:;
    if (!mo_is(L11, 0)) goto F212;
    L20 = L11.as.xs[0];
    if (!mo_is(L20, 7)) goto F212;
    goto E210;
    F212:;
    if (!mo_is(L11, 0)) goto F213;
    L21 = L11.as.xs[0];
    if (!mo_is(L21, 10)) goto F213;
    goto E210;
    F213:;
    if (!mo_is(L11, 0)) goto F214;
    L22 = L11.as.xs[0];
    if (!mo_is(L22, 11)) goto F214;
    goto E210;
    F214:;
    if (!mo_is(L11, 0)) goto F209;
    L23 = L11.as.xs[0];
    if (!mo_is(L23, 12)) goto F209;
    E210:;
    MoValue t39 MO_U = L0;
    MoValue t40 MO_U = L1;
    MoValue t41 MO_U = L2;
    MoValue t42 MO_U = L3;
    MoValue t43 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool_result block ", 18), t42, mo_str(" has unsupported content", 24)});
    MoValue t44 MO_U = f44(t39, t40, t41, t43);
    MoValue t45 MO_U = mo_list_of(0, NULL);
    MoValue t46 MO_U = mo_record(41, 2, (const MoValue[]){t44, t45});
    t12 = t46;
    goto E206;
    F209:;
    mo_crash(26);
    E206:;
    R = t12;
    X201:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f34
#undef LOAD_f34
#define SAVE_f35() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = R; } while (0)
#define LOAD_f35() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; R = V_[7]; } while (0)
#define ROOTS_f35(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, R}; mo_compact(m, r_, 8); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; R = r_[7]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f35(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("result_parts");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    size_t m217 MO_U = 0, k217 MO_U = 0;
    MoValue V_[8];
    size_t *const M_[] = {&F_, &m217, &k217};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 8, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_record(41, 2, (const MoValue[]){t0, t1});
    L3 = t2;
    MoValue t3 MO_U = L2;
    MoValue t4 MO_U = mo_r_List_enumerate((const MoValue[]){t3}, MO_KIND_NONE);
    L4 = t4;
    {
        m217 = mo_mark(); k217 = 0;
        for (uint32_t i217 = 0; i217 < L4.aux; i217++) {
            MoValue t5 MO_U = L4.as.xs[i217];
            L5 = t5;
            if (mo_walk_due(&FR_)) { SAVE_f35(); mo_walk(&FR_); LOAD_f35(); }
            MoValue t6 MO_U = L3.as.xs[0];
            mo_disown_in(t6);
            mo_disown_in(L1);
            MoValue t7 MO_U = L1;
            MoValue t8 MO_U = L5.as.xs[0];
            MoValue t9 MO_U = L5.as.xs[1];
            SAVE_f35();
            uint64_t w10 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t11 MO_U = f36(t6, t7, t8, t9);
            FR_.walking = false; if (mo_walks != w10) LOAD_f35();
            L6 = t11;
            MoValue t12 MO_U = L6.as.xs[0];
            MoValue t13 MO_U = L3;
            MoValue t14 MO_U = mo_set_field(t13, 0, t12);
            L3 = t14;
            MoValue t15 MO_U = L3.as.xs[1];
            MoValue t16 MO_U = L6.as.xs[1];
            MoValue t17 MO_U = mo_r_List_concat((const MoValue[]){t15, t16}, MO_KIND_NONE);
            MoValue t18 MO_U = L3;
            MoValue t19 MO_U = mo_set_field(t18, 1, t17);
            L3 = t19;
            ROOTS_f35(m217, k217);
        }
    }
    MoValue t20 MO_U = L3;
    R = t20;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f35
#undef SAVE_f35
#undef LOAD_f35
MO_U static MoValue f36(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("result_part");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    MoValue L21 MO_U = MO_NONE_V;
    MoValue L22 MO_U = MO_NONE_V;
    MoValue L23 MO_U = MO_NONE_V;
    MoValue L24 MO_U = MO_NONE_V;
    MoValue L25 MO_U = MO_NONE_V;
    MoValue L26 MO_U = MO_NONE_V;
    MoValue L27 MO_U = MO_NONE_V;
    MoValue L28 MO_U = MO_NONE_V;
    MoValue L29 MO_U = MO_NONE_V;
    MoValue L30 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L3;
    L4 = t1;
    if (!mo_is(L4, 7)) goto F220;
    L5 = L4.as.xs[0];
    L6 = L5;
    MoValue t2 MO_U = L6;
    t0 = t2;
    goto E219;
    F220:;
    if (!mo_is(L4, 9)) goto F223;
    goto E222;
    F223:;
    if (!mo_is(L4, 8)) goto F224;
    goto E222;
    F224:;
    if (!mo_is(L4, 10)) goto F225;
    goto E222;
    F225:;
    if (!mo_is(L4, 11)) goto F226;
    goto E222;
    F226:;
    if (!mo_is(L4, 12)) goto F221;
    E222:;
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L1.as.xs[0];
    MoValue t5 MO_U = L1.as.xs[1];
    MoValue t6 MO_U = L2;
    MoValue t7 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool result part ", 17), t6, mo_str(" is not an object", 17)});
    MoValue t8 MO_U = f44(t3, t4, t5, t7);
    MoValue t9 MO_U = mo_list_of(0, NULL);
    MoValue t10 MO_U = mo_record(41, 2, (const MoValue[]){t8, t9});
    R = t10;
    goto X218;
    t0 = MO_NONE_V;
    goto E219;
    F221:;
    mo_crash(27);
    E219:;
    L7 = t0;
    MoValue t11 MO_U = MO_NONE_V;
    MoValue t12 MO_U = L7;
    MoValue t13 MO_U = mo_r_Map_get((const MoValue[]){t12, mo_str("type", 4)}, MO_KIND_NONE);
    L8 = t13;
    if (!mo_is(L8, 0)) goto F229;
    L9 = L8.as.xs[0];
    if (!mo_is(L9, 9)) goto F229;
    L10 = L9.as.xs[0];
    if (!mo_equal(L10, mo_str("text", 4))) goto F229;
    MoValue t14 MO_U = MO_NONE_V;
    MoValue t15 MO_U = L7;
    MoValue t16 MO_U = mo_r_Map_get((const MoValue[]){t15, mo_str("text", 4)}, MO_KIND_NONE);
    L11 = t16;
    if (!mo_is(L11, 0)) goto F231;
    L12 = L11.as.xs[0];
    if (!mo_is(L12, 9)) goto F231;
    L13 = L12.as.xs[0];
    L14 = L13;
    MoValue t17 MO_U = mo_variant(55, 0, NULL);
    MoValue t18 MO_U = L1.as.xs[4];
    MoValue t19 MO_U = L2;
    MoValue t20 MO_U = mo_concat(4, (const MoValue[]){mo_str("tool result ", 12), t18, mo_str(" part ", 6), t19});
    MoValue t21 MO_U = L14;
    MoValue t22 MO_U = L1.as.xs[0];
    MoValue t23 MO_U = L1.as.xs[1];
    MoValue t24 MO_U = L1.as.xs[2];
    MoValue t25 MO_U = L1.as.xs[3];
    MoValue t26 MO_U = mo_record(31, 7, (const MoValue[]){t17, t20, t21, t22, t23, t24, t25});
    L15 = t26;
    mo_disown_in(L0);
    MoValue t27 MO_U = L0;
    MoValue t28 MO_U = L15;
    mo_disown_in(t28);
    MoValue t29 MO_U = mo_list_of(1, (const MoValue[]){t28});
    MoValue t30 MO_U = mo_record(41, 2, (const MoValue[]){t27, t29});
    t14 = t30;
    goto E230;
    F231:;
    if (!mo_is(L11, 1)) goto F234;
    goto E233;
    F234:;
    if (!mo_is(L11, 0)) goto F235;
    L16 = L11.as.xs[0];
    if (!mo_is(L16, 7)) goto F235;
    goto E233;
    F235:;
    if (!mo_is(L11, 0)) goto F236;
    L17 = L11.as.xs[0];
    if (!mo_is(L17, 8)) goto F236;
    goto E233;
    F236:;
    if (!mo_is(L11, 0)) goto F237;
    L18 = L11.as.xs[0];
    if (!mo_is(L18, 10)) goto F237;
    goto E233;
    F237:;
    if (!mo_is(L11, 0)) goto F238;
    L19 = L11.as.xs[0];
    if (!mo_is(L19, 11)) goto F238;
    goto E233;
    F238:;
    if (!mo_is(L11, 0)) goto F232;
    L20 = L11.as.xs[0];
    if (!mo_is(L20, 12)) goto F232;
    E233:;
    mo_disown_in(L0);
    MoValue t31 MO_U = L0;
    MoValue t32 MO_U = L1.as.xs[0];
    MoValue t33 MO_U = L1.as.xs[1];
    MoValue t34 MO_U = L2;
    MoValue t35 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool result text part ", 22), t34, mo_str(" has no string text", 19)});
    MoValue t36 MO_U = f44(t31, t32, t33, t35);
    MoValue t37 MO_U = mo_list_of(0, NULL);
    MoValue t38 MO_U = mo_record(41, 2, (const MoValue[]){t36, t37});
    t14 = t38;
    goto E230;
    F232:;
    mo_crash(28);
    E230:;
    t11 = t14;
    goto E228;
    F229:;
    if (!mo_is(L8, 0)) goto F240;
    L21 = L8.as.xs[0];
    if (!mo_is(L21, 9)) goto F240;
    L22 = L21.as.xs[0];
    if (!mo_equal(L22, mo_str("image", 5))) goto F240;
    mo_disown_in(L0);
    MoValue t39 MO_U = L0;
    MoValue t40 MO_U = mo_list_of(0, NULL);
    MoValue t41 MO_U = mo_record(41, 2, (const MoValue[]){t39, t40});
    t11 = t41;
    goto E228;
    F240:;
    if (!mo_is(L8, 0)) goto F241;
    L23 = L8.as.xs[0];
    if (!mo_is(L23, 9)) goto F241;
    L24 = L23.as.xs[0];
    L25 = L24;
    mo_disown_in(L0);
    MoValue t42 MO_U = L0;
    MoValue t43 MO_U = L1.as.xs[0];
    MoValue t44 MO_U = L1.as.xs[1];
    MoValue t45 MO_U = L25;
    MoValue t46 MO_U = mo_concat(2, (const MoValue[]){mo_str("unsupported tool result part type ", 34), t45});
    MoValue t47 MO_U = f44(t42, t43, t44, t46);
    MoValue t48 MO_U = mo_list_of(0, NULL);
    MoValue t49 MO_U = mo_record(41, 2, (const MoValue[]){t47, t48});
    t11 = t49;
    goto E228;
    F241:;
    if (!mo_is(L8, 1)) goto F244;
    goto E243;
    F244:;
    if (!mo_is(L8, 0)) goto F245;
    L26 = L8.as.xs[0];
    if (!mo_is(L26, 7)) goto F245;
    goto E243;
    F245:;
    if (!mo_is(L8, 0)) goto F246;
    L27 = L8.as.xs[0];
    if (!mo_is(L27, 8)) goto F246;
    goto E243;
    F246:;
    if (!mo_is(L8, 0)) goto F247;
    L28 = L8.as.xs[0];
    if (!mo_is(L28, 10)) goto F247;
    goto E243;
    F247:;
    if (!mo_is(L8, 0)) goto F248;
    L29 = L8.as.xs[0];
    if (!mo_is(L29, 11)) goto F248;
    goto E243;
    F248:;
    if (!mo_is(L8, 0)) goto F242;
    L30 = L8.as.xs[0];
    if (!mo_is(L30, 12)) goto F242;
    E243:;
    MoValue t50 MO_U = L0;
    MoValue t51 MO_U = L1.as.xs[0];
    MoValue t52 MO_U = L1.as.xs[1];
    MoValue t53 MO_U = L2;
    MoValue t54 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool result part ", 17), t53, mo_str(" has no string type", 19)});
    MoValue t55 MO_U = f44(t50, t51, t52, t54);
    MoValue t56 MO_U = mo_list_of(0, NULL);
    MoValue t57 MO_U = mo_record(41, 2, (const MoValue[]){t55, t56});
    t11 = t57;
    goto E228;
    F242:;
    mo_crash(29);
    E228:;
    R = t11;
    X218:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f37(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("api_index");
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L4;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("apiBlockIndex", 13)}, MO_KIND_NONE);
    L5 = t2;
    if (!mo_is(L5, 1)) goto F252;
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = mo_variant(1, 0, NULL);
    MoValue t5 MO_U = mo_tuple(2, (const MoValue[]){t3, t4});
    t0 = t5;
    goto E251;
    F252:;
    if (!mo_is(L5, 0)) goto F253;
    L6 = L5.as.xs[0];
    L7 = L6;
    MoValue t6 MO_U = MO_NONE_V;
    MoValue t7 MO_U = L7;
    MoValue t8 MO_U = mo_r_Json_to_i64((const MoValue[]){t7}, MO_KIND_NONE);
    L8 = t8;
    if (!mo_is(L8, 0)) goto F255;
    L9 = L8.as.xs[0];
    L10 = L9;
    MoValue t9 MO_U = MO_NONE_V;
    MoValue t10 MO_U = L10;
    MoValue t11 MO_U = mo_bool(t10.as.i >= mo_i64(INT64_C(0)).as.i);
    if (t11.as.b) {
        mo_disown_in(L0);
        MoValue t12 MO_U = L0;
        MoValue t13 MO_U = L10;
        MoValue t14 MO_U = mo_r_Int_to_u64((const MoValue[]){t13}, 3);
        MoValue t15 MO_U = mo_variant(0, 1, (const MoValue[]){t14});
        MoValue t16 MO_U = mo_tuple(2, (const MoValue[]){t12, t15});
        t9 = t16;
    } else {
        mo_disown_in(L0);
        MoValue t17 MO_U = L0;
        MoValue t18 MO_U = L1;
        MoValue t19 MO_U = L2;
        MoValue t20 MO_U = L3;
        MoValue t21 MO_U = mo_concat(3, (const MoValue[]){mo_str("apiBlockIndex on block ", 23), t20, mo_str(" is negative", 12)});
        MoValue t22 MO_U = f44(t17, t18, t19, t21);
        MoValue t23 MO_U = mo_variant(1, 0, NULL);
        MoValue t24 MO_U = mo_tuple(2, (const MoValue[]){t22, t23});
        t9 = t24;
    }
    t6 = t9;
    goto E254;
    F255:;
    if (!mo_is(L8, 1)) goto F256;
    MoValue t25 MO_U = L0;
    MoValue t26 MO_U = L1;
    MoValue t27 MO_U = L2;
    MoValue t28 MO_U = L3;
    MoValue t29 MO_U = mo_concat(3, (const MoValue[]){mo_str("apiBlockIndex on block ", 23), t28, mo_str(" is not a whole integer", 23)});
    MoValue t30 MO_U = f44(t25, t26, t27, t29);
    MoValue t31 MO_U = mo_variant(1, 0, NULL);
    MoValue t32 MO_U = mo_tuple(2, (const MoValue[]){t30, t31});
    t6 = t32;
    goto E254;
    F256:;
    mo_crash(30);
    E254:;
    t0 = t6;
    goto E251;
    F253:;
    mo_crash(31);
    E251:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f38(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("marked\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t0, t1}, MO_KIND_NONE);
    MoValue t3 MO_U = mo_variant(11, 1, (const MoValue[]){mo_bool(true)});
    MoValue t4 MO_U = mo_variant(0, 1, (const MoValue[]){t3});
    MoValue t5 MO_U = mo_bool(mo_compare(MO_EQ, t2, t4));
    R = t5;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f39(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_record_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f8();
    MoValue t2 MO_U = mo_bool(t0.as.u < t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f40(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("record_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f9();
    MoValue t2 MO_U = mo_bool(t0.as.u < t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f41(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("message_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f10();
    MoValue t2 MO_U = mo_bool(t0.as.u < t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f42(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("later");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = L1;
    MoValue t3 MO_U = mo_tuple(2, (const MoValue[]){t1, t2});
    L2 = t3;
    L3 = L2.as.xs[0];
    if (!mo_is(L3, 0)) goto F263;
    L4 = L3.as.xs[0];
    L5 = L4;
    L6 = L2.as.xs[1];
    if (!mo_is(L6, 0)) goto F263;
    L7 = L6.as.xs[0];
    L8 = L7;
    MoValue t4 MO_U = L5;
    MoValue t5 MO_U = L8;
    MoValue t6 MO_U = mo_r_max_of((const MoValue[]){t4, t5}, MO_KIND_NONE);
    MoValue t7 MO_U = mo_variant(0, 1, (const MoValue[]){t6});
    t0 = t7;
    goto E262;
    F263:;
    L9 = L2.as.xs[0];
    if (!mo_is(L9, 0)) goto F264;
    L10 = L9.as.xs[0];
    L11 = L10;
    L12 = L2.as.xs[1];
    if (!mo_is(L12, 1)) goto F264;
    MoValue t8 MO_U = L11;
    MoValue t9 MO_U = mo_variant(0, 1, (const MoValue[]){t8});
    t0 = t9;
    goto E262;
    F264:;
    L13 = L2.as.xs[0];
    if (!mo_is(L13, 1)) goto F265;
    L14 = L2.as.xs[1];
    if (!mo_is(L14, 0)) goto F265;
    L15 = L14.as.xs[0];
    L16 = L15;
    MoValue t10 MO_U = L16;
    MoValue t11 MO_U = mo_variant(0, 1, (const MoValue[]){t10});
    t0 = t11;
    goto E262;
    F265:;
    L17 = L2.as.xs[0];
    if (!mo_is(L17, 1)) goto F266;
    L18 = L2.as.xs[1];
    if (!mo_is(L18, 1)) goto F266;
    MoValue t12 MO_U = mo_variant(1, 0, NULL);
    t0 = t12;
    goto E262;
    F266:;
    mo_crash(32);
    E262:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a1(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("unknown");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_Int_saturating_add((const MoValue[]){t0, mo_i64(INT64_C(1))}, 7);
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a2(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("unknown");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_Int_saturating_add((const MoValue[]){t0, mo_i64(INT64_C(1))}, 7);
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f43(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("unknown");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L2 = t0;
    MoValue t1 MO_U = MO_NONE_V;
    MoValue t2 MO_U = L1;
    MoValue t3 MO_U = mo_r_String_size((const MoValue[]){t2}, MO_KIND_NONE);
    MoValue t4 MO_U = mo_bool(t3.as.u <= mo_i64(INT64_C(128)).as.u);
    if (t4.as.b) {
        MoValue t5 MO_U = L1;
        t1 = t5;
    } else {
        MoValue t6 MO_U = L1;
        MoValue t7 MO_U = mo_r_String_slice((const MoValue[]){t6, mo_i64(INT64_C(0)), mo_i64(INT64_C(128))}, MO_KIND_NONE);
        MoValue t8 MO_U = mo_concat(2, (const MoValue[]){t7, mo_str("...", 3)});
        t1 = t8;
    }
    L3 = t1;
    MoValue t9 MO_U = L2;
    MoValue t10 MO_U = t9.as.xs[2];
    MoValue t11 MO_U = L3;
    MoValue t12 MO_U = mo_r_Map_has_q((const MoValue[]){t10, t11}, MO_KIND_NONE);
    if (t12.as.b) {
        MoValue t13 MO_U = L2;
        MoValue t14 MO_U = t13.as.xs[2];
        MoValue t15 MO_U = L3;
        MoValue t16 MO_U = mo_closure(a1, 84, 0, NULL);
        MoValue t17 MO_U = mo_r_Map_update((const MoValue[]){t14, t15, mo_i64(INT64_C(0)), t16}, MO_KIND_UNIQUE);
        MoValue t18 MO_U = L2;
        MoValue t19 MO_U = mo_set_field(t18, 2, t17);
        L2 = t19;
    } else {
        MoValue t20 MO_U = L2;
        MoValue t21 MO_U = t20.as.xs[2];
        MoValue t22 MO_U = mo_r_Map_size((const MoValue[]){t21}, MO_KIND_NONE);
        MoValue t23 MO_U = f13();
        MoValue t24 MO_U = mo_r_Int_saturating_sub((const MoValue[]){t23, mo_i64(INT64_C(1))}, 7);
        MoValue t25 MO_U = mo_bool(t22.as.u < t24.as.u);
        if (t25.as.b) {
            MoValue t26 MO_U = L2;
            MoValue t27 MO_U = t26.as.xs[2];
            MoValue t28 MO_U = L3;
            MoValue t29 MO_U = mo_r_Map_set((const MoValue[]){t27, t28, mo_i64(INT64_C(1))}, MO_KIND_UNIQUE);
            MoValue t30 MO_U = L2;
            MoValue t31 MO_U = mo_set_field(t30, 2, t29);
            L2 = t31;
        } else {
            MoValue t32 MO_U = L2;
            MoValue t33 MO_U = t32.as.xs[2];
            MoValue t34 MO_U = mo_closure(a2, 85, 0, NULL);
            MoValue t35 MO_U = mo_r_Map_update((const MoValue[]){t33, mo_str("<additional kinds>", 18), mo_i64(INT64_C(0)), t34}, MO_KIND_UNIQUE);
            MoValue t36 MO_U = L2;
            MoValue t37 MO_U = mo_set_field(t36, 2, t35);
            L2 = t37;
        }
    }
    MoValue t38 MO_U = L2;
    R = t38;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f44(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("problem");
    MoValue L4 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L4 = t0;
    MoValue t1 MO_U = L4;
    MoValue t2 MO_U = mo_set_field(t1, 8, mo_bool(true));
    L4 = t2;
    MoValue t3 MO_U = L4.as.xs[1];
    MoValue t4 MO_U = mo_r_List_size((const MoValue[]){t3}, MO_KIND_NONE);
    MoValue t5 MO_U = f13();
    MoValue t6 MO_U = mo_bool(t4.as.u < t5.as.u);
    if (t6.as.b) {
        MoValue t7 MO_U = L4.as.xs[1];
        MoValue t8 MO_U = L1;
        MoValue t9 MO_U = L2;
        MoValue t10 MO_U = L3;
        MoValue t11 MO_U = mo_record(34, 3, (const MoValue[]){t8, t9, t10});
        mo_disown_in(t11);
        MoValue t12 MO_U = mo_r_List_push((const MoValue[]){t7, t11}, MO_KIND_NONE);
        MoValue t13 MO_U = L4;
        MoValue t14 MO_U = mo_set_field(t13, 1, t12);
        L4 = t14;
    }
    MoValue t15 MO_U = L4;
    R = t15;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f45() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = R; } while (0)
#define LOAD_f45() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; R = V_[7]; } while (0)
#define ROOTS_f45(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, R}; mo_compact(m, r_, 8); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; R = r_[7]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f45(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("scan_tree");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    size_t m272 MO_U = 0, k272 MO_U = 0;
    MoValue V_[8];
    size_t *const M_[] = {&F_, &m272, &k272};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 8, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    if (mo_walk_due(&FR_)) { SAVE_f45(); mo_walk(&FR_); LOAD_f45(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f19();
    MoValue t2 MO_U = L1;
    MoValue t3 MO_U = L2;
    SAVE_f45();
    uint64_t w4 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t5 MO_U = f46(t0, mo_str(".", 1), mo_i64(INT64_C(0)), t1, t2, t3);
    FR_.walking = false; if (mo_walks != w4) LOAD_f45();
    L3 = t5;
    if (mo_walk_due(&FR_)) { SAVE_f45(); mo_walk(&FR_); LOAD_f45(); }
    SAVE_f45();
    uint64_t w6 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t7 MO_U = f18();
    FR_.walking = false; if (mo_walks != w6) LOAD_f45();
    L4 = t7;
    MoValue t8 MO_U = L3.as.xs[1];
    MoValue t9 MO_U = L4;
    MoValue t10 MO_U = mo_set_field(t9, 1, t8);
    L4 = t10;
    MoValue t11 MO_U = L3.as.xs[4];
    MoValue t12 MO_U = L4;
    MoValue t13 MO_U = mo_set_field(t12, 8, t11);
    L4 = t13;
    MoValue t14 MO_U = L3.as.xs[3];
    MoValue t15 MO_U = L4;
    MoValue t16 MO_U = mo_set_field(t15, 3, t14);
    L4 = t16;
    MoValue t17 MO_U = L3.as.xs[0];
    MoValue t18 MO_U = mo_r_List_sort((const MoValue[]){t17}, MO_KIND_NONE);
    L5 = t18;
    {
        m272 = mo_mark(); k272 = 0;
        for (uint32_t i272 = 0; i272 < L5.aux; i272++) {
            MoValue t19 MO_U = L5.as.xs[i272];
            L6 = t19;
            MoValue t20 MO_U = L1;
            MoValue t21 MO_U = mo_r_Clock_now((const MoValue[]){t20}, MO_KIND_NONE);
            MoValue t22 MO_U = L2;
            MoValue t23 MO_U = f17();
            MoValue t24 MO_U = mo_arith(MO_OP_ADD, t22, t23, 33);
            MoValue t25 MO_U = mo_bool(mo_compare(MO_GE, t21, t24));
            if (t25.as.b) {
                if (mo_walk_due(&FR_)) { SAVE_f45(); mo_walk(&FR_); LOAD_f45(); }
                MoValue t26 MO_U = L4;
                MoValue t27 MO_U = L6;
                SAVE_f45();
                uint64_t w28 MO_U = mo_walks;
                FR_.walking = true;
                MoValue t29 MO_U = f56(t26, t27, mo_i64(INT64_C(0)), mo_str("the 60 second processing deadline was exceeded", 46));
                FR_.walking = false; if (mo_walks != w28) LOAD_f45();
                L4 = t29;
                goto B272;
            }
            if (mo_walk_due(&FR_)) { SAVE_f45(); mo_walk(&FR_); LOAD_f45(); }
            MoValue t30 MO_U = L0;
            MoValue t31 MO_U = L6;
            MoValue t32 MO_U = L4;
            MoValue t33 MO_U = L1;
            MoValue t34 MO_U = L2;
            SAVE_f45();
            uint64_t w35 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t36 MO_U = f48(t30, t31, t32, t33, t34);
            FR_.walking = false; if (mo_walks != w35) LOAD_f45();
            L4 = t36;
            ROOTS_f45(m272, k272);
        }
    }
    B272:;
    MoValue t37 MO_U = L4;
    R = t37;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f45
#undef SAVE_f45
#undef LOAD_f45
#define SAVE_f46() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = L18; V_[19] = L19; V_[20] = L20; V_[21] = L21; V_[22] = L22; V_[23] = R; } while (0)
#define LOAD_f46() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; L18 = V_[18]; L19 = V_[19]; L20 = V_[20]; L21 = V_[21]; L22 = V_[22]; R = V_[23]; } while (0)
#define ROOTS_f46(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11, L12, L13, L14, L15, L16, L17, L18, L19, L20, L21, L22, R}; mo_compact(m, r_, 24); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; L9 = r_[9]; L10 = r_[10]; L11 = r_[11]; L12 = r_[12]; L13 = r_[13]; L14 = r_[14]; L15 = r_[15]; L16 = r_[16]; L17 = r_[17]; L18 = r_[18]; L19 = r_[19]; L20 = r_[20]; L21 = r_[21]; L22 = r_[22]; R = r_[23]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f46(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("discover");
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    MoValue L21 MO_U = MO_NONE_V;
    MoValue L22 MO_U = MO_NONE_V;
    size_t m277 MO_U = 0, k277 MO_U = 0;
    MoValue V_[24];
    size_t *const M_[] = {&F_, &m277, &k277};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 24, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L3;
    L6 = t0;
    MoValue t1 MO_U = L6.as.xs[5];
    if (t1.as.b) {
        mo_disown_in(L6);
        MoValue t2 MO_U = L6;
        R = t2;
        goto X273;
    }
    MoValue t3 MO_U = L4;
    MoValue t4 MO_U = mo_r_Clock_now((const MoValue[]){t3}, MO_KIND_NONE);
    MoValue t5 MO_U = L5;
    MoValue t6 MO_U = f17();
    MoValue t7 MO_U = mo_arith(MO_OP_ADD, t5, t6, 34);
    MoValue t8 MO_U = mo_bool(mo_compare(MO_GE, t4, t7));
    if (t8.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f46(); mo_walk(&FR_); LOAD_f46(); }
        mo_disown_in(L6);
        MoValue t9 MO_U = L6;
        MoValue t10 MO_U = L1;
        SAVE_f46();
        uint64_t w11 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t12 MO_U = f55(t9, t10, mo_str("the 60 second processing deadline was exceeded", 46));
        FR_.walking = false; if (mo_walks != w11) LOAD_f46();
        R = t12;
        goto X273;
    }
    MoValue t13 MO_U = L2;
    MoValue t14 MO_U = f50(t13);
    MoValue t15 MO_U = mo_bool(!t14.as.b);
    if (t15.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f46(); mo_walk(&FR_); LOAD_f46(); }
        mo_disown_in(L6);
        MoValue t16 MO_U = L6;
        MoValue t17 MO_U = L1;
        SAVE_f46();
        uint64_t w18 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t19 MO_U = f55(t16, t17, mo_str("traversal exceeds depth 24", 26));
        FR_.walking = false; if (mo_walks != w18) LOAD_f46();
        R = t19;
        goto X273;
    }
    MoValue t20 MO_U = MO_NONE_V;
    MoValue t21 MO_U = L1;
    MoValue t22 MO_U = mo_bool(mo_compare(MO_EQ, t21, mo_str(".", 1)));
    if (t22.as.b) {
        MoValue t23 MO_U = L0;
        t20 = t23;
    } else {
        MoValue t24 MO_U = L0;
        MoValue t25 MO_U = L1;
        MoValue t26 MO_U = mo_r_Fs_scoped((const MoValue[]){t24, t25}, MO_KIND_NONE);
        t20 = t26;
    }
    L7 = t20;
    MoValue t27 MO_U = MO_NONE_V;
    MoValue t28 MO_U = L7;
    MoValue t29 MO_U = mo_wait_begin("Fs.list");
    MoValue t30 MO_U = f16();
    MoValue t31 MO_U = t30;
    MoValue t32 MO_U = mo_waited("Fs.list", t29, t31.as.i < 0 ? mo_timed_out_now() : mo_r_Fs_list((const MoValue[]){t28, t31}, MO_KIND_NONE));
    L8 = t32;
    if (!mo_is(L8, 2)) goto F275;
    L9 = L8.as.xs[0];
    L10 = L9;
    MoValue t33 MO_U = L10;
    MoValue t34 MO_U = mo_r_List_sort((const MoValue[]){t33}, MO_KIND_NONE);
    t27 = t34;
    goto E274;
    F275:;
    if (!mo_is(L8, 3)) goto F276;
    L11 = L8.as.xs[0];
    L12 = L11;
    if (mo_walk_due(&FR_)) { SAVE_f46(); mo_walk(&FR_); LOAD_f46(); }
    mo_disown_in(L6);
    MoValue t35 MO_U = L6;
    MoValue t36 MO_U = L1;
    MoValue t37 MO_U = L12;
    MoValue t38 MO_U = f53(t37);
    MoValue t39 MO_U = mo_concat(2, (const MoValue[]){mo_str("cannot list directory: ", 23), t38});
    SAVE_f46();
    uint64_t w40 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t41 MO_U = f54(t35, t36, t39);
    FR_.walking = false; if (mo_walks != w40) LOAD_f46();
    R = t41;
    goto X273;
    t27 = MO_NONE_V;
    goto E274;
    F276:;
    mo_crash(35);
    E274:;
    L13 = t27;
    MoValue t42 MO_U = L13;
    L14 = t42;
    {
        m277 = mo_mark(); k277 = 0;
        for (uint32_t i277 = 0; i277 < L14.aux; i277++) {
            MoValue t43 MO_U = L14.as.xs[i277];
            L15 = t43;
            MoValue t44 MO_U = L4;
            MoValue t45 MO_U = mo_r_Clock_now((const MoValue[]){t44}, MO_KIND_NONE);
            MoValue t46 MO_U = L5;
            MoValue t47 MO_U = f17();
            MoValue t48 MO_U = mo_arith(MO_OP_ADD, t46, t47, 36);
            MoValue t49 MO_U = mo_bool(mo_compare(MO_GE, t45, t48));
            if (t49.as.b) {
                if (mo_walk_due(&FR_)) { SAVE_f46(); mo_walk(&FR_); LOAD_f46(); }
                mo_disown_in(L6);
                MoValue t50 MO_U = L6;
                MoValue t51 MO_U = L1;
                SAVE_f46();
                uint64_t w52 MO_U = mo_walks;
                FR_.walking = true;
                MoValue t53 MO_U = f55(t50, t51, mo_str("the 60 second processing deadline was exceeded", 46));
                FR_.walking = false; if (mo_walks != w52) LOAD_f46();
                R = t53;
                goto X273;
            }
            MoValue t54 MO_U = L6.as.xs[2];
            MoValue t55 MO_U = f51(t54);
            MoValue t56 MO_U = mo_bool(!t55.as.b);
            if (t56.as.b) {
                if (mo_walk_due(&FR_)) { SAVE_f46(); mo_walk(&FR_); LOAD_f46(); }
                mo_disown_in(L6);
                MoValue t57 MO_U = L6;
                MoValue t58 MO_U = L1;
                SAVE_f46();
                uint64_t w59 MO_U = mo_walks;
                FR_.walking = true;
                MoValue t60 MO_U = f55(t57, t58, mo_str("traversal exceeds 50000 entries", 31));
                FR_.walking = false; if (mo_walks != w59) LOAD_f46();
                R = t60;
                goto X273;
            }
            MoValue t61 MO_U = L6.as.xs[2];
            MoValue t62 MO_U = mo_add_u64(t61, mo_i64(INT64_C(1)), 37);
            MoValue t63 MO_U = L6;
            MoValue t64 MO_U = mo_set_field(t63, 2, t62);
            L6 = t64;
            if (mo_walk_due(&FR_)) { SAVE_f46(); mo_walk(&FR_); LOAD_f46(); }
            MoValue t65 MO_U = L1;
            MoValue t66 MO_U = L15;
            SAVE_f46();
            uint64_t w67 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t68 MO_U = f49(t65, t66);
            FR_.walking = false; if (mo_walks != w67) LOAD_f46();
            L16 = t68;
            MoValue t69 MO_U = L16;
            MoValue t70 MO_U = L2;
            MoValue t71 MO_U = mo_add_u64(t70, mo_i64(INT64_C(1)), 38);
            MoValue t72 MO_U = mo_record(45, 2, (const MoValue[]){t69, t71});
            L17 = t72;
            MoValue t73 MO_U = L0;
            MoValue t74 MO_U = L16;
            MoValue t75 MO_U = mo_wait_begin("Fs.kind_of");
            MoValue t76 MO_U = f16();
            MoValue t77 MO_U = t76;
            MoValue t78 MO_U = mo_waited("Fs.kind_of", t75, t77.as.i < 0 ? mo_timed_out_now() : mo_r_Fs_kind_of((const MoValue[]){t73, t74, t77}, MO_KIND_NONE));
            L18 = t78;
            if (!mo_is(L18, 3)) goto F279;
            L19 = L18.as.xs[0];
            L20 = L19;
            if (mo_walk_due(&FR_)) { SAVE_f46(); mo_walk(&FR_); LOAD_f46(); }
            MoValue t79 MO_U = L6;
            MoValue t80 MO_U = L16;
            MoValue t81 MO_U = L20;
            MoValue t82 MO_U = f53(t81);
            MoValue t83 MO_U = mo_concat(2, (const MoValue[]){mo_str("cannot stat entry: ", 19), t82});
            SAVE_f46();
            uint64_t w84 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t85 MO_U = f54(t79, t80, t83);
            FR_.walking = false; if (mo_walks != w84) LOAD_f46();
            L6 = t85;
            goto E278;
            F279:;
            if (!mo_is(L18, 2)) goto F280;
            L21 = L18.as.xs[0];
            L22 = L21;
            if (mo_walk_due(&FR_)) { SAVE_f46(); mo_walk(&FR_); LOAD_f46(); }
            MoValue t86 MO_U = L0;
            MoValue t87 MO_U = L17;
            MoValue t88 MO_U = L6;
            MoValue t89 MO_U = L4;
            MoValue t90 MO_U = L5;
            MoValue t91 MO_U = L22.as.xs[1];
            SAVE_f46();
            uint64_t w92 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t93 MO_U = f47(t86, t87, t88, t89, t90, t91);
            FR_.walking = false; if (mo_walks != w92) LOAD_f46();
            L6 = t93;
            goto E278;
            F280:;
            mo_crash(39);
            E278:;
            MoValue t94 MO_U = L6.as.xs[5];
            if (t94.as.b) {
                goto B277;
            }
            ROOTS_f46(m277, k277);
        }
    }
    B277:;
    MoValue t95 MO_U = L6;
    R = t95;
    X273:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f46
#undef SAVE_f46
#undef LOAD_f46
#define SAVE_f47() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = R; } while (0)
#define LOAD_f47() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; R = V_[8]; } while (0)
MO_U static MoValue f47(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("discovered_entry");
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue V_[9];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 9, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L2;
    L6 = t0;
    MoValue t1 MO_U = L5;
    L7 = t1;
    if (!mo_is(L7, 48)) goto F283;
    MoValue t2 MO_U = L6.as.xs[3];
    MoValue t3 MO_U = mo_add_u64(t2, mo_i64(INT64_C(1)), 40);
    MoValue t4 MO_U = L6;
    MoValue t5 MO_U = mo_set_field(t4, 3, t3);
    L6 = t5;
    goto E282;
    F283:;
    if (!mo_is(L7, 43)) goto F284;
    MoValue t6 MO_U = L1.as.xs[0];
    MoValue t7 MO_U = mo_r_String_ends_with_q((const MoValue[]){t6, mo_str(".jsonl", 6)}, MO_KIND_NONE);
    if (t7.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f47(); mo_walk(&FR_); LOAD_f47(); }
        MoValue t8 MO_U = L6;
        MoValue t9 MO_U = L1.as.xs[0];
        SAVE_f47();
        uint64_t w10 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t11 MO_U = f54(t8, t9, mo_str("a .jsonl candidate is a directory, not a regular file", 53));
        FR_.walking = false; if (mo_walks != w10) LOAD_f47();
        L6 = t11;
    }
    if (mo_walk_due(&FR_)) { SAVE_f47(); mo_walk(&FR_); LOAD_f47(); }
    MoValue t12 MO_U = L0;
    MoValue t13 MO_U = L1.as.xs[0];
    MoValue t14 MO_U = L1.as.xs[1];
    MoValue t15 MO_U = L6;
    MoValue t16 MO_U = L3;
    MoValue t17 MO_U = L4;
    SAVE_f47();
    uint64_t w18 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t19 MO_U = f46(t12, t13, t14, t15, t16, t17);
    FR_.walking = false; if (mo_walks != w18) LOAD_f47();
    L6 = t19;
    goto E282;
    F284:;
    if (!mo_is(L7, 42)) goto F285;
    MoValue t20 MO_U = L1.as.xs[0];
    MoValue t21 MO_U = mo_r_String_ends_with_q((const MoValue[]){t20, mo_str(".jsonl", 6)}, MO_KIND_NONE);
    if (t21.as.b) {
        MoValue t22 MO_U = L6.as.xs[0];
        MoValue t23 MO_U = mo_r_List_size((const MoValue[]){t22}, MO_KIND_NONE);
        MoValue t24 MO_U = f52(t23);
        MoValue t25 MO_U = mo_bool(!t24.as.b);
        if (t25.as.b) {
            if (mo_walk_due(&FR_)) { SAVE_f47(); mo_walk(&FR_); LOAD_f47(); }
            mo_disown_in(L6);
            MoValue t26 MO_U = L6;
            MoValue t27 MO_U = L1.as.xs[0];
            SAVE_f47();
            uint64_t w28 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t29 MO_U = f55(t26, t27, mo_str("discovery exceeds 5000 JSONL files", 34));
            FR_.walking = false; if (mo_walks != w28) LOAD_f47();
            R = t29;
            goto X281;
        }
        MoValue t30 MO_U = L6.as.xs[0];
        MoValue t31 MO_U = L1.as.xs[0];
        MoValue t32 MO_U = mo_r_List_push((const MoValue[]){t30, t31}, MO_KIND_NONE);
        MoValue t33 MO_U = L6;
        MoValue t34 MO_U = mo_set_field(t33, 0, t32);
        L6 = t34;
    }
    goto E282;
    F285:;
    mo_crash(41);
    E282:;
    MoValue t35 MO_U = L6;
    R = t35;
    X281:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f47
#undef LOAD_f47
#define SAVE_a3() do { V_[0] = L0; V_[1] = L1; V_[2] = R; } while (0)
#define LOAD_a3() do { L0 = V_[0]; L1 = V_[1]; R = V_[2]; } while (0)
MO_U static MoValue a3(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("scan_file");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue V_[3];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 3, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    L0 = args[0];
    L1 = args[1];
    (void)cap;
    (void)args;
    if (mo_walk_due(&FR_)) { SAVE_a3(); mo_walk(&FR_); LOAD_a3(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1;
    SAVE_a3();
    uint64_t w2 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t3 MO_U = f21(t0, t1);
    FR_.walking = false; if (mo_walks != w2) LOAD_a3();
    R = t3;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_a3
#undef LOAD_a3
#define SAVE_f48() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = L18; V_[19] = L19; V_[20] = L20; V_[21] = L21; V_[22] = L22; V_[23] = R; } while (0)
#define LOAD_f48() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; L18 = V_[18]; L19 = V_[19]; L20 = V_[20]; L21 = V_[21]; L22 = V_[22]; R = V_[23]; } while (0)
MO_U static MoValue f48(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("scan_file");
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    MoValue L21 MO_U = MO_NONE_V;
    MoValue L22 MO_U = MO_NONE_V;
    MoValue V_[24];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 24, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L2;
    L5 = t0;
    MoValue t1 MO_U = MO_NONE_V;
    MoValue t2 MO_U = L0;
    MoValue t3 MO_U = L1;
    MoValue t4 MO_U = mo_wait_begin("Fs.size");
    MoValue t5 MO_U = f16();
    MoValue t6 MO_U = t5;
    MoValue t7 MO_U = mo_waited("Fs.size", t4, t6.as.i < 0 ? mo_timed_out_now() : mo_r_Fs_size((const MoValue[]){t2, t3, t6}, MO_KIND_NONE));
    L6 = t7;
    if (!mo_is(L6, 2)) goto F288;
    L7 = L6.as.xs[0];
    L8 = L7;
    MoValue t8 MO_U = L8;
    t1 = t8;
    goto E287;
    F288:;
    if (!mo_is(L6, 3)) goto F289;
    L9 = L6.as.xs[0];
    L10 = L9;
    if (mo_walk_due(&FR_)) { SAVE_f48(); mo_walk(&FR_); LOAD_f48(); }
    mo_disown_in(L5);
    MoValue t9 MO_U = L5;
    MoValue t10 MO_U = L1;
    MoValue t11 MO_U = L10;
    MoValue t12 MO_U = f53(t11);
    MoValue t13 MO_U = mo_concat(2, (const MoValue[]){mo_str("cannot admit regular .jsonl input by size: ", 43), t12});
    SAVE_f48();
    uint64_t w14 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t15 MO_U = f56(t9, t10, mo_i64(INT64_C(0)), t13);
    FR_.walking = false; if (mo_walks != w14) LOAD_f48();
    R = t15;
    goto X286;
    t1 = MO_NONE_V;
    goto E287;
    F289:;
    mo_crash(42);
    E287:;
    L11 = t1;
    MoValue t16 MO_U = L11;
    MoValue t17 MO_U = f5();
    MoValue t18 MO_U = mo_bool(t16.as.u > t17.as.u);
    if (t18.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f48(); mo_walk(&FR_); LOAD_f48(); }
        mo_disown_in(L5);
        MoValue t19 MO_U = L5;
        MoValue t20 MO_U = L1;
        SAVE_f48();
        uint64_t w21 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t22 MO_U = f56(t19, t20, mo_i64(INT64_C(0)), mo_str("file exceeds 64 MiB", 19));
        FR_.walking = false; if (mo_walks != w21) LOAD_f48();
        R = t22;
        goto X286;
    }
    MoValue t23 MO_U = L5.as.xs[5];
    MoValue t24 MO_U = L11;
    MoValue t25 MO_U = mo_r_Int_checked_add((const MoValue[]){t23, t24}, 7);
    L12 = t25;
    MoValue t26 MO_U = L12;
    L13 = t26;
    MoValue t27 MO_U = mo_bool(true);
    if (!mo_is(L13, 1)) goto F290;
    goto E291;
    F290:;
    t27 = mo_bool(false);
    E291:;
    MoValue t28 MO_U = mo_bool(true);
    if (!t27.as.b) {
        MoValue t29 MO_U = L12;
        L14 = t29;
        MoValue t30 MO_U = MO_NONE_V;
        if (mo_is(L14, MO_N_SOME)) {
            t30 = L14.as.xs[0];
        } else {
            t30 = mo_i64(INT64_C(0));
        }
        MoValue t31 MO_U = f6();
        MoValue t32 MO_U = mo_bool(t30.as.u > t31.as.u);
        t28 = t32;
    }
    if (t28.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f48(); mo_walk(&FR_); LOAD_f48(); }
        mo_disown_in(L5);
        MoValue t33 MO_U = L5;
        MoValue t34 MO_U = L1;
        SAVE_f48();
        uint64_t w35 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t36 MO_U = f56(t33, t34, mo_i64(INT64_C(0)), mo_str("aggregate admitted input exceeds 1 GiB", 38));
        FR_.walking = false; if (mo_walks != w35) LOAD_f48();
        R = t36;
        goto X286;
    }
    MoValue t37 MO_U = L12;
    L15 = t37;
    MoValue t38 MO_U = MO_NONE_V;
    if (mo_is(L15, MO_N_SOME)) {
        t38 = L15.as.xs[0];
    } else {
        MoValue t39 MO_U = L5.as.xs[5];
        t38 = t39;
    }
    MoValue t40 MO_U = L5;
    MoValue t41 MO_U = mo_set_field(t40, 5, t38);
    L5 = t41;
    if (mo_walk_due(&FR_)) { SAVE_f48(); mo_walk(&FR_); LOAD_f48(); }
    mo_disown_in(L5);
    MoValue t42 MO_U = L5;
    MoValue t43 MO_U = L1;
    MoValue t44 MO_U = L11;
    SAVE_f48();
    uint64_t w45 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t46 MO_U = f20(t42, t43, t44);
    FR_.walking = false; if (mo_walks != w45) LOAD_f48();
    L16 = t46;
    MoValue t47 MO_U = L3;
    MoValue t48 MO_U = mo_r_Clock_now((const MoValue[]){t47}, MO_KIND_NONE);
    MoValue t49 MO_U = L4;
    MoValue t50 MO_U = f17();
    MoValue t51 MO_U = mo_arith(MO_OP_ADD, t49, t50, 43);
    MoValue t52 MO_U = mo_bool(mo_compare(MO_GE, t48, t51));
    if (t52.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f48(); mo_walk(&FR_); LOAD_f48(); }
        mo_disown_in(L5);
        MoValue t53 MO_U = L5;
        MoValue t54 MO_U = L1;
        SAVE_f48();
        uint64_t w55 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t56 MO_U = f56(t53, t54, mo_i64(INT64_C(0)), mo_str("the 60 second processing deadline was exceeded", 46));
        FR_.walking = false; if (mo_walks != w55) LOAD_f48();
        R = t56;
        goto X286;
    }
    MoValue t57 MO_U = L0;
    MoValue t58 MO_U = L1;
    MoValue t59 MO_U = L16;
    MoValue t60 MO_U = mo_closure(a3, 86, 0, NULL);
    MoValue t61 MO_U = mo_wait_begin("Fs.fold_lines");
    MoValue t62 MO_U = f16();
    MoValue t63 MO_U = t62;
    MoValue t64 MO_U = mo_waited("Fs.fold_lines", t61, t63.as.i < 0 ? mo_timed_out_now() : mo_r_Fs_fold_lines((const MoValue[]){t57, t58, t59, t60, t63}, MO_KIND_NONE));
    L17 = t64;
    MoValue t65 MO_U = L17;
    L18 = t65;
    if (!mo_is(L18, 2)) goto F294;
    L19 = L18.as.xs[0];
    L20 = L19;
    MoValue t66 MO_U = L20.as.xs[0];
    L5 = t66;
    MoValue t67 MO_U = L5.as.xs[4];
    MoValue t68 MO_U = mo_add_u64(t67, mo_i64(INT64_C(1)), 44);
    MoValue t69 MO_U = L5;
    MoValue t70 MO_U = mo_set_field(t69, 4, t68);
    L5 = t70;
    goto E293;
    F294:;
    if (!mo_is(L18, 3)) goto F295;
    L21 = L18.as.xs[0];
    L22 = L21;
    if (mo_walk_due(&FR_)) { SAVE_f48(); mo_walk(&FR_); LOAD_f48(); }
    MoValue t71 MO_U = L5;
    MoValue t72 MO_U = L1;
    MoValue t73 MO_U = L22;
    MoValue t74 MO_U = f53(t73);
    MoValue t75 MO_U = mo_concat(2, (const MoValue[]){mo_str("cannot read admitted .jsonl input: ", 35), t74});
    SAVE_f48();
    uint64_t w76 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t77 MO_U = f56(t71, t72, mo_i64(INT64_C(0)), t75);
    FR_.walking = false; if (mo_walks != w76) LOAD_f48();
    L5 = t77;
    goto E293;
    F295:;
    mo_crash(45);
    E293:;
    MoValue t78 MO_U = L3;
    MoValue t79 MO_U = mo_r_Clock_now((const MoValue[]){t78}, MO_KIND_NONE);
    MoValue t80 MO_U = L4;
    MoValue t81 MO_U = f17();
    MoValue t82 MO_U = mo_arith(MO_OP_ADD, t80, t81, 46);
    MoValue t83 MO_U = mo_bool(mo_compare(MO_GE, t79, t82));
    if (t83.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f48(); mo_walk(&FR_); LOAD_f48(); }
        MoValue t84 MO_U = L5;
        MoValue t85 MO_U = L1;
        SAVE_f48();
        uint64_t w86 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t87 MO_U = f56(t84, t85, mo_i64(INT64_C(0)), mo_str("the 60 second processing deadline was exceeded", 46));
        FR_.walking = false; if (mo_walks != w86) LOAD_f48();
        L5 = t87;
    }
    MoValue t88 MO_U = L5;
    R = t88;
    X286:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f48
#undef LOAD_f48
MO_U static MoValue f49(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("joined");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_bool(mo_compare(MO_EQ, t0, mo_str(".", 1)));
    if (t1.as.b) {
        MoValue t2 MO_U = L1;
        R = t2;
        goto X296;
    }
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L1;
    MoValue t5 MO_U = mo_concat(3, (const MoValue[]){t3, mo_str("/", 1), t4});
    R = t5;
    X296:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f50(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("depth_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f2();
    MoValue t2 MO_U = mo_bool(t0.as.u <= t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f51(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("entry_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f3();
    MoValue t2 MO_U = mo_bool(t0.as.u < t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f52(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f4();
    MoValue t2 MO_U = mo_bool(t0.as.u < t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f53(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("fs_error");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    L1 = t1;
    if (!mo_is(L1, 4)) goto F302;
    L2 = L1.as.xs[0];
    L3 = L2;
    MoValue t2 MO_U = L3;
    MoValue t3 MO_U = mo_concat(2, (const MoValue[]){mo_str("missing or unsupported entry ", 29), t2});
    t0 = t3;
    goto E301;
    F302:;
    if (!mo_is(L1, 5)) goto F303;
    t0 = mo_str("operation timed out", 19);
    goto E301;
    F303:;
    if (!mo_is(L1, 21)) goto F304;
    t0 = mo_str("entry is not text", 17);
    goto E301;
    F304:;
    mo_crash(47);
    E301:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f54(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("discovery_problem");
    MoValue L3 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L3 = t0;
    MoValue t1 MO_U = L3;
    MoValue t2 MO_U = mo_set_field(t1, 4, mo_bool(true));
    L3 = t2;
    MoValue t3 MO_U = L3.as.xs[1];
    MoValue t4 MO_U = mo_r_List_size((const MoValue[]){t3}, MO_KIND_NONE);
    MoValue t5 MO_U = f13();
    MoValue t6 MO_U = mo_bool(t4.as.u < t5.as.u);
    if (t6.as.b) {
        MoValue t7 MO_U = L3.as.xs[1];
        MoValue t8 MO_U = L1;
        MoValue t9 MO_U = L2;
        MoValue t10 MO_U = mo_record(34, 3, (const MoValue[]){t8, mo_i64(INT64_C(0)), t9});
        mo_disown_in(t10);
        MoValue t11 MO_U = mo_r_List_push((const MoValue[]){t7, t10}, MO_KIND_NONE);
        MoValue t12 MO_U = L3;
        MoValue t13 MO_U = mo_set_field(t12, 1, t11);
        L3 = t13;
    }
    MoValue t14 MO_U = L3;
    R = t14;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f55() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = R; } while (0)
#define LOAD_f55() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; R = V_[4]; } while (0)
MO_U static MoValue f55(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("discovery_stop");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue V_[5];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 5, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    if (mo_walk_due(&FR_)) { SAVE_f55(); mo_walk(&FR_); LOAD_f55(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1;
    MoValue t2 MO_U = L2;
    SAVE_f55();
    uint64_t w3 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t4 MO_U = f54(t0, t1, t2);
    FR_.walking = false; if (mo_walks != w3) LOAD_f55();
    L3 = t4;
    MoValue t5 MO_U = L3;
    MoValue t6 MO_U = mo_set_field(t5, 5, mo_bool(true));
    L3 = t6;
    MoValue t7 MO_U = L3;
    R = t7;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f55
#undef LOAD_f55
MO_U static MoValue f56(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("scan_problem");
    MoValue L4 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L4 = t0;
    MoValue t1 MO_U = L4;
    MoValue t2 MO_U = mo_set_field(t1, 8, mo_bool(true));
    L4 = t2;
    MoValue t3 MO_U = L4.as.xs[1];
    MoValue t4 MO_U = mo_r_List_size((const MoValue[]){t3}, MO_KIND_NONE);
    MoValue t5 MO_U = f13();
    MoValue t6 MO_U = mo_bool(t4.as.u < t5.as.u);
    if (t6.as.b) {
        MoValue t7 MO_U = L4.as.xs[1];
        MoValue t8 MO_U = L1;
        MoValue t9 MO_U = L2;
        MoValue t10 MO_U = L3;
        MoValue t11 MO_U = mo_record(34, 3, (const MoValue[]){t8, t9, t10});
        mo_disown_in(t11);
        MoValue t12 MO_U = mo_r_List_push((const MoValue[]){t7, t11}, MO_KIND_NONE);
        MoValue t13 MO_U = L4;
        MoValue t14 MO_U = mo_set_field(t13, 1, t12);
        L4 = t14;
    }
    MoValue t15 MO_U = L4;
    R = t15;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a4(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("report");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = t0.as.xs[5];
    MoValue t2 MO_U = L0.as.xs[0];
    MoValue t3 MO_U = t2.as.xs[6];
    MoValue t4 MO_U = L0.as.xs[0];
    MoValue t5 MO_U = t4.as.xs[3];
    MoValue t6 MO_U = L0.as.xs[0];
    MoValue t7 MO_U = t6.as.xs[4];
    MoValue t8 MO_U = mo_tuple(4, (const MoValue[]){t1, t3, t5, t7});
    R = t8;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f57() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = R; } while (0)
#define LOAD_f57() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; R = V_[16]; } while (0)
#define ROOTS_f57(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11, L12, L13, L14, L15, R}; mo_compact(m, r_, 17); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; L9 = r_[9]; L10 = r_[10]; L11 = r_[11]; L12 = r_[12]; L13 = r_[13]; L14 = r_[14]; L15 = r_[15]; R = r_[16]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f57(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("report");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    size_t m309 MO_U = 0, k309 MO_U = 0;
    size_t m311 MO_U = 0, k311 MO_U = 0;
    MoValue V_[17];
    size_t *const M_[] = {&F_, &m309, &k309, &m311, &k311};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 17, M_, 5};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    if (mo_walk_due(&FR_)) { SAVE_f57(); mo_walk(&FR_); LOAD_f57(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1;
    MoValue t2 MO_U = L2;
    MoValue t3 MO_U = L3;
    SAVE_f57();
    uint64_t w4 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t5 MO_U = f58(t0, t1, t2, t3);
    FR_.walking = false; if (mo_walks != w4) LOAD_f57();
    L4 = t5;
    if (mo_walk_due(&FR_)) { SAVE_f57(); mo_walk(&FR_); LOAD_f57(); }
    MoValue t6 MO_U = L4;
    MoValue t7 MO_U = t6.as.xs[0];
    MoValue t8 MO_U = t7.as.xs[0];
    MoValue t9 MO_U = mo_r_Map_values((const MoValue[]){t8}, MO_KIND_NONE);
    MoValue t10 MO_U = L4.as.xs[1];
    SAVE_f57();
    uint64_t w11 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t12 MO_U = f61(t9, t10);
    FR_.walking = false; if (mo_walks != w11) LOAD_f57();
    L5 = t12;
    MoValue t13 MO_U = L4.as.xs[0];
    L6 = t13;
    MoValue t14 MO_U = mo_record(47, 2, (const MoValue[]){mo_str("", 0), mo_bool(false)});
    L7 = t14;
    L8 = mo_bool(false);
    MoValue t15 MO_U = L5;
    L9 = t15;
    {
        m309 = mo_mark(); k309 = 0;
        for (uint32_t i309 = 0; i309 < L9.aux; i309++) {
            MoValue t16 MO_U = L9.as.xs[i309];
            L10 = t16;
            MoValue t17 MO_U = L2;
            MoValue t18 MO_U = mo_r_Clock_now((const MoValue[]){t17}, MO_KIND_NONE);
            MoValue t19 MO_U = L3;
            MoValue t20 MO_U = f17();
            MoValue t21 MO_U = mo_arith(MO_OP_ADD, t19, t20, 48);
            MoValue t22 MO_U = mo_bool(mo_compare(MO_GE, t18, t21));
            if (t22.as.b) {
                if (mo_walk_due(&FR_)) { SAVE_f57(); mo_walk(&FR_); LOAD_f57(); }
                MoValue t23 MO_U = L6;
                SAVE_f57();
                uint64_t w24 MO_U = mo_walks;
                FR_.walking = true;
                MoValue t25 MO_U = f77(t23, mo_str("<search>", 8), mo_i64(INT64_C(0)), mo_str("the 60 second processing deadline was exceeded", 46));
                FR_.walking = false; if (mo_walks != w24) LOAD_f57();
                L6 = t25;
                L8 = mo_bool(true);
                goto B309;
            }
            if (mo_walk_due(&FR_)) { SAVE_f57(); mo_walk(&FR_); LOAD_f57(); }
            MoValue t26 MO_U = L7;
            mo_disown_in(L10);
            MoValue t27 MO_U = L10;
            MoValue t28 MO_U = f62(t27);
            SAVE_f57();
            uint64_t w29 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t30 MO_U = f68(t26, t28);
            FR_.walking = false; if (mo_walks != w29) LOAD_f57();
            L7 = t30;
            MoValue t31 MO_U = L7.as.xs[1];
            if (t31.as.b) {
                goto B309;
            }
            MoValue t32 MO_U = L10.as.xs[3];
            MoValue t33 MO_U = mo_closure(a4, 87, 0, NULL);
            MoValue t34 MO_U = mo_r_List_sort_by((const MoValue[]){t32, t33}, MO_KIND_NONE);
            L11 = t34;
            {
                m311 = mo_mark(); k311 = 0;
                for (uint32_t i311 = 0; i311 < L11.aux; i311++) {
                    MoValue t35 MO_U = L11.as.xs[i311];
                    L12 = t35;
                    MoValue t36 MO_U = L2;
                    MoValue t37 MO_U = mo_r_Clock_now((const MoValue[]){t36}, MO_KIND_NONE);
                    MoValue t38 MO_U = L3;
                    MoValue t39 MO_U = f17();
                    MoValue t40 MO_U = mo_arith(MO_OP_ADD, t38, t39, 49);
                    MoValue t41 MO_U = mo_bool(mo_compare(MO_GE, t37, t40));
                    if (t41.as.b) {
                        if (mo_walk_due(&FR_)) { SAVE_f57(); mo_walk(&FR_); LOAD_f57(); }
                        MoValue t42 MO_U = L6;
                        SAVE_f57();
                        uint64_t w43 MO_U = mo_walks;
                        FR_.walking = true;
                        MoValue t44 MO_U = f77(t42, mo_str("<search>", 8), mo_i64(INT64_C(0)), mo_str("the 60 second processing deadline was exceeded", 46));
                        FR_.walking = false; if (mo_walks != w43) LOAD_f57();
                        L6 = t44;
                        L8 = mo_bool(true);
                        goto B311;
                    }
                    if (mo_walk_due(&FR_)) { SAVE_f57(); mo_walk(&FR_); LOAD_f57(); }
                    MoValue t45 MO_U = L7;
                    MoValue t46 MO_U = L12;
                    SAVE_f57();
                    uint64_t w47 MO_U = mo_walks;
                    FR_.walking = true;
                    MoValue t48 MO_U = f63(t45, t46);
                    FR_.walking = false; if (mo_walks != w47) LOAD_f57();
                    L7 = t48;
                    MoValue t49 MO_U = L7.as.xs[1];
                    if (t49.as.b) {
                        goto B311;
                    }
                    ROOTS_f57(m311, k311);
                }
            }
            B311:;
            MoValue t50 MO_U = L8;
            MoValue t51 MO_U = mo_bool(true);
            if (!t50.as.b) {
                MoValue t52 MO_U = L7.as.xs[1];
                t51 = t52;
            }
            if (t51.as.b) {
                goto B309;
            }
            ROOTS_f57(m309, k309);
        }
    }
    B309:;
    MoValue t53 MO_U = MO_NONE_V;
    MoValue t54 MO_U = L4.as.xs[1];
    MoValue t55 MO_U = mo_r_List_size((const MoValue[]){t54}, MO_KIND_NONE);
    MoValue t56 MO_U = mo_bool(t55.as.u == mo_i64(INT64_C(0)).as.u);
    if (t56.as.b) {
        t53 = mo_str("No matches.\012", 12);
    } else {
        MoValue t57 MO_U = L4.as.xs[1];
        MoValue t58 MO_U = mo_r_List_size((const MoValue[]){t57}, MO_KIND_NONE);
        MoValue t59 MO_U = mo_concat(2, (const MoValue[]){t58, mo_str(" matching messages.\012", 20)});
        t53 = t59;
    }
    L13 = t53;
    if (mo_walk_due(&FR_)) { SAVE_f57(); mo_walk(&FR_); LOAD_f57(); }
    MoValue t60 MO_U = L7;
    MoValue t61 MO_U = L13;
    SAVE_f57();
    uint64_t w62 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t63 MO_U = f68(t60, t61);
    FR_.walking = false; if (mo_walks != w62) LOAD_f57();
    L7 = t63;
    MoValue t64 MO_U = L7.as.xs[1];
    if (t64.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f57(); mo_walk(&FR_); LOAD_f57(); }
        MoValue t65 MO_U = L6;
        SAVE_f57();
        uint64_t w66 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t67 MO_U = f77(t65, mo_str("<output>", 8), mo_i64(INT64_C(0)), mo_str("rendered output exceeds 8 MiB", 29));
        FR_.walking = false; if (mo_walks != w66) LOAD_f57();
        L6 = t67;
    }
    MoValue t68 MO_U = f15();
    MoValue t69 MO_U = L7.as.xs[0];
    MoValue t70 MO_U = mo_r_String_byte_size((const MoValue[]){t69}, MO_KIND_NONE);
    MoValue t71 MO_U = mo_r_Int_saturating_sub((const MoValue[]){t68, t70}, 7);
    L14 = t71;
    if (mo_walk_due(&FR_)) { SAVE_f57(); mo_walk(&FR_); LOAD_f57(); }
    mo_disown_in(L6);
    MoValue t72 MO_U = L6;
    MoValue t73 MO_U = L14;
    SAVE_f57();
    uint64_t w74 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t75 MO_U = f65(t72, t73);
    FR_.walking = false; if (mo_walks != w74) LOAD_f57();
    L15 = t75;
    MoValue t76 MO_U = L7.as.xs[0];
    MoValue t77 MO_U = L15.as.xs[0];
    MoValue t78 MO_U = L4.as.xs[1];
    MoValue t79 MO_U = mo_r_List_size((const MoValue[]){t78}, MO_KIND_NONE);
    MoValue t80 MO_U = L6.as.xs[8];
    MoValue t81 MO_U = mo_bool(true);
    if (!t80.as.b) {
        MoValue t82 MO_U = L15.as.xs[1];
        t81 = t82;
    }
    MoValue t83 MO_U = mo_record(39, 4, (const MoValue[]){t76, t77, t79, t81});
    R = t83;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f57
#undef SAVE_f57
#undef LOAD_f57
MO_U static MoValue a5(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("searched");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    R = t0;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a6(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("searched");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = mo_variant(54, 0, NULL);
    MoValue t2 MO_U = mo_bool(mo_compare(MO_EQ, t0, t1));
    MoValue t3 MO_U = mo_bool(true);
    if (!t2.as.b) {
        MoValue t4 MO_U = cap[0].as.xs[3];
        MoValue t5 MO_U = mo_bool(false);
        if (t4.as.b) {
            MoValue t6 MO_U = L0.as.xs[0];
            MoValue t7 MO_U = mo_variant(55, 0, NULL);
            MoValue t8 MO_U = mo_bool(mo_compare(MO_EQ, t6, t7));
            t5 = t8;
        }
        t3 = t5;
    }
    R = t3;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a7(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("searched");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f60(t0);
    MoValue t2 MO_U = f71(t1);
    MoValue t3 MO_U = cap[0];
    MoValue t4 MO_U = mo_r_String_contains_q((const MoValue[]){t2, t3}, MO_KIND_NONE);
    R = t4;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f58() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = R; } while (0)
#define LOAD_f58() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; R = V_[12]; } while (0)
#define ROOTS_f58(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11, R}; mo_compact(m, r_, 13); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; L9 = r_[9]; L10 = r_[10]; L11 = r_[11]; R = r_[12]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f58(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("searched");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    size_t m314 MO_U = 0, k314 MO_U = 0;
    MoValue V_[13];
    size_t *const M_[] = {&F_, &m314, &k314};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 13, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    mo_disown_in(L0);
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_record(46, 2, (const MoValue[]){t0, t1});
    L4 = t2;
    if (mo_walk_due(&FR_)) { SAVE_f58(); mo_walk(&FR_); LOAD_f58(); }
    MoValue t3 MO_U = L1.as.xs[0];
    SAVE_f58();
    uint64_t w4 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t5 MO_U = f71(t3);
    FR_.walking = false; if (mo_walks != w4) LOAD_f58();
    L5 = t5;
    if (mo_walk_due(&FR_)) { SAVE_f58(); mo_walk(&FR_); LOAD_f58(); }
    MoValue t6 MO_U = L1.as.xs[0];
    SAVE_f58();
    uint64_t w7 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t8 MO_U = f72(t6);
    FR_.walking = false; if (mo_walks != w7) LOAD_f58();
    L6 = t8;
    MoValue t9 MO_U = L0;
    MoValue t10 MO_U = t9.as.xs[0];
    MoValue t11 MO_U = mo_r_Map_values((const MoValue[]){t10}, MO_KIND_NONE);
    MoValue t12 MO_U = mo_closure(a5, 88, 0, NULL);
    MoValue t13 MO_U = mo_r_List_sort_by((const MoValue[]){t11, t12}, MO_KIND_NONE);
    L7 = t13;
    {
        m314 = mo_mark(); k314 = 0;
        for (uint32_t i314 = 0; i314 < L7.aux; i314++) {
            MoValue t14 MO_U = L7.as.xs[i314];
            L8 = t14;
            MoValue t15 MO_U = L2;
            MoValue t16 MO_U = mo_r_Clock_now((const MoValue[]){t15}, MO_KIND_NONE);
            MoValue t17 MO_U = L3;
            MoValue t18 MO_U = f17();
            MoValue t19 MO_U = mo_arith(MO_OP_ADD, t17, t18, 50);
            MoValue t20 MO_U = mo_bool(mo_compare(MO_GE, t16, t19));
            if (t20.as.b) {
                if (mo_walk_due(&FR_)) { SAVE_f58(); mo_walk(&FR_); LOAD_f58(); }
                MoValue t21 MO_U = L4.as.xs[0];
                SAVE_f58();
                uint64_t w22 MO_U = mo_walks;
                FR_.walking = true;
                MoValue t23 MO_U = f77(t21, mo_str("<search>", 8), mo_i64(INT64_C(0)), mo_str("the 60 second processing deadline was exceeded", 46));
                FR_.walking = false; if (mo_walks != w22) LOAD_f58();
                MoValue t24 MO_U = L4;
                MoValue t25 MO_U = mo_set_field(t24, 0, t23);
                L4 = t25;
                goto B314;
            }
            MoValue t26 MO_U = L8.as.xs[8];
            mo_disown_in(L1);
            MoValue t27 MO_U = mo_closure(a6, 89, 1, (const MoValue[]){L1});
            MoValue t28 MO_U = mo_r_List_filter((const MoValue[]){t26, t27}, MO_KIND_NONE);
            L9 = t28;
            MoValue t29 MO_U = MO_NONE_V;
            MoValue t30 MO_U = L1.as.xs[2];
            L10 = t30;
            if (!mo_is(L10, 56)) goto F317;
            MoValue t31 MO_U = L9;
            mo_disown_in(L5);
            MoValue t32 MO_U = mo_closure(a7, 90, 1, (const MoValue[]){L5});
            MoValue t33 MO_U = mo_r_List_filter((const MoValue[]){t31, t32}, MO_KIND_NONE);
            t29 = t33;
            goto E316;
            F317:;
            if (!mo_is(L10, 57)) goto F319;
            MoValue t34 MO_U = MO_NONE_V;
            MoValue t35 MO_U = L6;
            MoValue t36 MO_U = L9;
            MoValue t37 MO_U = f59(t35, t36);
            if (t37.as.b) {
                MoValue t38 MO_U = L9;
                t34 = t38;
            } else {
                MoValue t39 MO_U = mo_list_of(0, NULL);
                t34 = t39;
            }
            t29 = t34;
            goto E316;
            F319:;
            mo_crash(51);
            E316:;
            L11 = t29;
            MoValue t40 MO_U = L11;
            MoValue t41 MO_U = mo_r_List_size((const MoValue[]){t40}, MO_KIND_NONE);
            MoValue t42 MO_U = mo_bool(t41.as.u > mo_i64(INT64_C(0)).as.u);
            if (t42.as.b) {
                MoValue t43 MO_U = L4.as.xs[1];
                MoValue t44 MO_U = mo_r_List_size((const MoValue[]){t43}, MO_KIND_NONE);
                MoValue t45 MO_U = f70(t44);
                MoValue t46 MO_U = mo_bool(!t45.as.b);
                if (t46.as.b) {
                    if (mo_walk_due(&FR_)) { SAVE_f58(); mo_walk(&FR_); LOAD_f58(); }
                    MoValue t47 MO_U = L4.as.xs[0];
                    MoValue t48 MO_U = L8.as.xs[5];
                    MoValue t49 MO_U = L8.as.xs[6];
                    SAVE_f58();
                    uint64_t w50 MO_U = mo_walks;
                    FR_.walking = true;
                    MoValue t51 MO_U = f77(t47, t48, t49, mo_str("search exceeds 10000 matching logical messages", 46));
                    FR_.walking = false; if (mo_walks != w50) LOAD_f58();
                    MoValue t52 MO_U = L4;
                    MoValue t53 MO_U = mo_set_field(t52, 0, t51);
                    L4 = t53;
                    goto B314;
                }
                MoValue t54 MO_U = L4.as.xs[1];
                MoValue t55 MO_U = L8;
                MoValue t56 MO_U = L11;
                MoValue t57 MO_U = mo_record(37, 2, (const MoValue[]){t55, t56});
                mo_disown_in(t57);
                MoValue t58 MO_U = mo_r_List_push((const MoValue[]){t54, t57}, MO_KIND_NONE);
                MoValue t59 MO_U = L4;
                MoValue t60 MO_U = mo_set_field(t59, 1, t58);
                L4 = t60;
            }
            ROOTS_f58(m314, k314);
        }
    }
    B314:;
    MoValue t61 MO_U = L4;
    R = t61;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f58
#undef SAVE_f58
#undef LOAD_f58
MO_U static MoValue a9(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("all_words_present\?");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f60(t0);
    MoValue t2 MO_U = f71(t1);
    MoValue t3 MO_U = cap[0];
    MoValue t4 MO_U = mo_r_String_contains_q((const MoValue[]){t2, t3}, MO_KIND_NONE);
    R = t4;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a8(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("all_words_present\?");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = cap[0];
    mo_disown_in(L0);
    MoValue t1 MO_U = mo_closure(a9, 92, 1, (const MoValue[]){L0});
    MoValue t2 MO_U = mo_r_List_any_q((const MoValue[]){t0, t1}, MO_KIND_NONE);
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f59(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("all_words_present\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    mo_disown_in(L1);
    MoValue t1 MO_U = mo_closure(a8, 91, 1, (const MoValue[]){L1});
    MoValue t2 MO_U = mo_r_List_all_q((const MoValue[]){t0, t1}, MO_KIND_NONE);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f60(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("searchable");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0.as.xs[0];
    MoValue t2 MO_U = mo_variant(55, 0, NULL);
    MoValue t3 MO_U = mo_bool(mo_compare(MO_EQ, t1, t2));
    if (t3.as.b) {
        MoValue t4 MO_U = L0.as.xs[1];
        MoValue t5 MO_U = L0.as.xs[2];
        MoValue t6 MO_U = mo_concat(3, (const MoValue[]){t4, mo_str("\012", 1), t5});
        t0 = t6;
    } else {
        MoValue t7 MO_U = L0.as.xs[2];
        t0 = t7;
    }
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a10(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    L1 = args[1];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1.as.xs[1];
    MoValue t2 MO_U = L1.as.xs[2];
    MoValue t3 MO_U = mo_r_Map_set((const MoValue[]){t0, t1, t2}, MO_KIND_UNIQUE);
    R = t3;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a11(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    L0 = args[0];
    L1 = args[1];
    (void)cap;
    (void)args;
    mo_disown_in(L0);
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1.as.xs[1];
    MoValue t2 MO_U = L0;
    MoValue t3 MO_U = L1.as.xs[1];
    MoValue t4 MO_U = mo_r_Map_get((const MoValue[]){t2, t3}, MO_KIND_NONE);
    L2 = t4;
    MoValue t5 MO_U = MO_NONE_V;
    if (mo_is(L2, MO_N_SOME)) {
        t5 = L2.as.xs[0];
    } else {
        MoValue t6 MO_U = mo_variant(1, 0, NULL);
        t5 = t6;
    }
    MoValue t7 MO_U = L1.as.xs[7];
    MoValue t8 MO_U = f76(t5, t7);
    MoValue t9 MO_U = mo_r_Map_set((const MoValue[]){t0, t1, t8}, MO_KIND_NONE);
    R = t9;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a13(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    mo_disown_in(cap[0]);
    MoValue t1 MO_U = cap[0];
    mo_disown_in(t1);
    MoValue t2 MO_U = mo_r_List_push((const MoValue[]){t0, t1}, MO_KIND_NONE);
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a12(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    L1 = args[1];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1.as.xs[0];
    MoValue t2 MO_U = t1.as.xs[1];
    MoValue t3 MO_U = mo_list_of(0, NULL);
    mo_disown_in(L1);
    MoValue t4 MO_U = mo_closure(a13, 96, 1, (const MoValue[]){L1});
    MoValue t5 MO_U = mo_r_Map_update((const MoValue[]){t0, t2, t3, t4}, MO_KIND_UNIQUE);
    R = t5;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a14(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = cap[0];
    MoValue t2 MO_U = L0.as.xs[0];
    MoValue t3 MO_U = mo_r_Map_get((const MoValue[]){t1, t2}, MO_KIND_NONE);
    L1 = t3;
    MoValue t4 MO_U = MO_NONE_V;
    if (mo_is(L1, MO_N_SOME)) {
        t4 = L1.as.xs[0];
    } else {
        MoValue t5 MO_U = L0.as.xs[0];
        t4 = t5;
    }
    MoValue t6 MO_U = cap[1];
    MoValue t7 MO_U = L0.as.xs[0];
    MoValue t8 MO_U = mo_r_Map_get((const MoValue[]){t6, t7}, MO_KIND_NONE);
    L2 = t8;
    MoValue t9 MO_U = MO_NONE_V;
    if (mo_is(L2, MO_N_SOME)) {
        t9 = L2.as.xs[0];
    } else {
        MoValue t10 MO_U = mo_variant(1, 0, NULL);
        t9 = t10;
    }
    MoValue t11 MO_U = L0.as.xs[1];
    MoValue t12 MO_U = mo_record(38, 4, (const MoValue[]){t0, t4, t9, t11});
    R = t12;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a15(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[2];
    L1 = t0;
    MoValue t1 MO_U = mo_bool(true);
    if (!mo_is(L1, 0)) goto F331;
    goto E332;
    F331:;
    t1 = mo_bool(false);
    E332:;
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a16(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[1];
    MoValue t1 MO_U = L0.as.xs[0];
    MoValue t2 MO_U = mo_tuple(2, (const MoValue[]){t0, t1});
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a17(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[2];
    L1 = t0;
    MoValue t1 MO_U = MO_NONE_V;
    if (mo_is(L1, MO_N_SOME)) {
        t1 = L1.as.xs[0];
    } else {
        MoValue t2 MO_U = mo_r_Time_from_parts((const MoValue[]){mo_i64(INT64_C(1970)), mo_i64(INT64_C(1)), mo_i64(INT64_C(1)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0))}, MO_KIND_NONE);
        t1 = t2;
    }
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a18(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[2];
    L1 = t0;
    MoValue t1 MO_U = mo_bool(true);
    if (!mo_is(L1, 1)) goto F336;
    goto E337;
    F336:;
    t1 = mo_bool(false);
    E337:;
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a19(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[1];
    MoValue t1 MO_U = L0.as.xs[0];
    MoValue t2 MO_U = mo_tuple(2, (const MoValue[]){t0, t1});
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f61(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t2 MO_U = mo_closure(a10, 93, 0, NULL);
    MoValue t3 MO_U = mo_r_List_reduce((const MoValue[]){t0, t1, t2}, MO_KIND_NONE);
    L2 = t3;
    MoValue t4 MO_U = L0;
    MoValue t5 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t6 MO_U = mo_closure(a11, 94, 0, NULL);
    MoValue t7 MO_U = mo_r_List_reduce((const MoValue[]){t4, t5, t6}, MO_KIND_NONE);
    L3 = t7;
    MoValue t8 MO_U = L1;
    MoValue t9 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t10 MO_U = mo_closure(a12, 95, 0, NULL);
    MoValue t11 MO_U = mo_r_List_reduce((const MoValue[]){t8, t9, t10}, MO_KIND_NONE);
    L4 = t11;
    MoValue t12 MO_U = L4;
    MoValue t13 MO_U = mo_r_Map_entries((const MoValue[]){t12}, MO_KIND_NONE);
    mo_disown_in(L2);
    mo_disown_in(L3);
    MoValue t14 MO_U = mo_closure(a14, 97, 2, (const MoValue[]){L2, L3});
    MoValue t15 MO_U = mo_r_List_map((const MoValue[]){t13, t14}, MO_KIND_NONE);
    L5 = t15;
    MoValue t16 MO_U = L5;
    MoValue t17 MO_U = mo_closure(a15, 98, 0, NULL);
    MoValue t18 MO_U = mo_r_List_filter((const MoValue[]){t16, t17}, MO_KIND_NONE);
    MoValue t19 MO_U = mo_closure(a16, 99, 0, NULL);
    MoValue t20 MO_U = mo_r_List_sort_by((const MoValue[]){t18, t19}, MO_KIND_NONE);
    MoValue t21 MO_U = mo_closure(a17, 100, 0, NULL);
    MoValue t22 MO_U = mo_r_List_sort_by_desc((const MoValue[]){t20, t21}, MO_KIND_NONE);
    L6 = t22;
    MoValue t23 MO_U = L5;
    MoValue t24 MO_U = mo_closure(a18, 101, 0, NULL);
    MoValue t25 MO_U = mo_r_List_filter((const MoValue[]){t23, t24}, MO_KIND_NONE);
    MoValue t26 MO_U = mo_closure(a19, 102, 0, NULL);
    MoValue t27 MO_U = mo_r_List_sort_by((const MoValue[]){t25, t26}, MO_KIND_NONE);
    L7 = t27;
    MoValue t28 MO_U = L6;
    MoValue t29 MO_U = L7;
    MoValue t30 MO_U = mo_r_List_concat((const MoValue[]){t28, t29}, MO_KIND_NONE);
    R = t30;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f62(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("session_heading");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0.as.xs[2];
    L1 = t1;
    if (!mo_is(L1, 0)) goto F341;
    L2 = L1.as.xs[0];
    L3 = L2;
    MoValue t2 MO_U = L3;
    MoValue t3 MO_U = mo_r_Time_to_iso8601((const MoValue[]){t2}, MO_KIND_NONE);
    t0 = t3;
    goto E340;
    F341:;
    if (!mo_is(L1, 1)) goto F342;
    t0 = mo_str("timestamp missing", 17);
    goto E340;
    F342:;
    mo_crash(52);
    E340:;
    L4 = t0;
    MoValue t4 MO_U = L0.as.xs[1];
    MoValue t5 MO_U = f74(t4, mo_i64(INT64_C(256)));
    MoValue t6 MO_U = L4;
    MoValue t7 MO_U = mo_concat(5, (const MoValue[]){mo_str("Session ", 8), t5, mo_str(" \342\200\224 latest ", 12), t6, mo_str("\012", 1)});
    R = t7;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f63() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = R; } while (0)
#define LOAD_f63() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; R = V_[9]; } while (0)
#define ROOTS_f63(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, R}; mo_compact(m, r_, 10); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; R = r_[9]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f63(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("render_hit");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    size_t m344 MO_U = 0, k344 MO_U = 0;
    MoValue V_[10];
    size_t *const M_[] = {&F_, &m344, &k344};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 10, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    if (mo_walk_due(&FR_)) { SAVE_f63(); mo_walk(&FR_); LOAD_f63(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1.as.xs[0];
    MoValue t2 MO_U = t1.as.xs[3];
    MoValue t3 MO_U = f74(t2, mo_i64(INT64_C(256)));
    MoValue t4 MO_U = L1.as.xs[0];
    MoValue t5 MO_U = t4.as.xs[4];
    MoValue t6 MO_U = f74(t5, mo_i64(INT64_C(256)));
    MoValue t7 MO_U = mo_concat(5, (const MoValue[]){mo_str("  ", 2), t3, mo_str(" message ", 9), t6, mo_str("\012", 1)});
    SAVE_f63();
    uint64_t w8 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t9 MO_U = f68(t0, t7);
    FR_.walking = false; if (mo_walks != w8) LOAD_f63();
    L2 = t9;
    MoValue t10 MO_U = L1.as.xs[1];
    L3 = t10;
    {
        m344 = mo_mark(); k344 = 0;
        for (uint32_t i344 = 0; i344 < L3.aux; i344++) {
            MoValue t11 MO_U = L3.as.xs[i344];
            L4 = t11;
            MoValue t12 MO_U = L2.as.xs[1];
            if (t12.as.b) {
                goto B344;
            }
            MoValue t13 MO_U = MO_NONE_V;
            MoValue t14 MO_U = L4.as.xs[6];
            L5 = t14;
            if (!mo_is(L5, 0)) goto F346;
            L6 = L5.as.xs[0];
            L7 = L6;
            MoValue t15 MO_U = L7;
            MoValue t16 MO_U = mo_concat(2, (const MoValue[]){mo_str(" apiBlockIndex=", 15), t15});
            t13 = t16;
            goto E345;
            F346:;
            if (!mo_is(L5, 1)) goto F347;
            t13 = mo_str("", 0);
            goto E345;
            F347:;
            mo_crash(53);
            E345:;
            L8 = t13;
            if (mo_walk_due(&FR_)) { SAVE_f63(); mo_walk(&FR_); LOAD_f63(); }
            MoValue t17 MO_U = L2;
            MoValue t18 MO_U = L4.as.xs[3];
            MoValue t19 MO_U = f74(t18, mo_i64(INT64_C(512)));
            MoValue t20 MO_U = L4.as.xs[4];
            MoValue t21 MO_U = L4.as.xs[1];
            MoValue t22 MO_U = f74(t21, mo_i64(INT64_C(256)));
            MoValue t23 MO_U = L4.as.xs[5];
            MoValue t24 MO_U = L8;
            MoValue t25 MO_U = mo_concat(11, (const MoValue[]){mo_str("    ", 4), t19, mo_str(":", 1), t20, mo_str(" ", 1), t22, mo_str(" content[", 9), t23, mo_str("]", 1), t24, mo_str("\012", 1)});
            SAVE_f63();
            uint64_t w26 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t27 MO_U = f68(t17, t25);
            FR_.walking = false; if (mo_walks != w26) LOAD_f63();
            L2 = t27;
            MoValue t28 MO_U = L2.as.xs[1];
            if (t28.as.b) {
                goto B344;
            }
            if (mo_walk_due(&FR_)) { SAVE_f63(); mo_walk(&FR_); LOAD_f63(); }
            MoValue t29 MO_U = L2;
            MoValue t30 MO_U = L4.as.xs[2];
            MoValue t31 MO_U = f64(t30);
            MoValue t32 MO_U = mo_concat(3, (const MoValue[]){mo_str("      ", 6), t31, mo_str("\012", 1)});
            SAVE_f63();
            uint64_t w33 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t34 MO_U = f68(t29, t32);
            FR_.walking = false; if (mo_walks != w33) LOAD_f63();
            L2 = t34;
            ROOTS_f63(m344, k344);
        }
    }
    B344:;
    MoValue t35 MO_U = L2;
    R = t35;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f63
#undef SAVE_f63
#undef LOAD_f63
#define SAVE_f64() do { V_[0] = L0; V_[1] = R; } while (0)
#define LOAD_f64() do { L0 = V_[0]; R = V_[1]; } while (0)
MO_U static MoValue f64(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("bounded_excerpt");
    MoValue V_[2];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 2, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    if (mo_walk_due(&FR_)) { SAVE_f64(); mo_walk(&FR_); LOAD_f64(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f14();
    SAVE_f64();
    uint64_t w2 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t3 MO_U = f74(t0, t1);
    FR_.walking = false; if (mo_walks != w2) LOAD_f64();
    R = t3;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f64
#undef LOAD_f64
#define SAVE_f65() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = R; } while (0)
#define LOAD_f65() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; R = V_[4]; } while (0)
MO_U static MoValue f65(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("diagnostics_text");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue V_[5];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 5, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_record(47, 2, (const MoValue[]){mo_str("", 0), mo_bool(false)});
    L2 = t0;
    MoValue t1 MO_U = L0.as.xs[8];
    if (t1.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f65(); mo_walk(&FR_); LOAD_f65(); }
        MoValue t2 MO_U = L2;
        mo_disown_in(L0);
        MoValue t3 MO_U = L0;
        MoValue t4 MO_U = L1;
        SAVE_f65();
        uint64_t w5 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t6 MO_U = f67(t2, t3, t4);
        FR_.walking = false; if (mo_walks != w5) LOAD_f65();
        L2 = t6;
    }
    MoValue t7 MO_U = L2.as.xs[1];
    MoValue t8 MO_U = mo_bool(!t7.as.b);
    if (t8.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f65(); mo_walk(&FR_); LOAD_f65(); }
        MoValue t9 MO_U = L2;
        MoValue t10 MO_U = L0;
        MoValue t11 MO_U = L1;
        SAVE_f65();
        uint64_t w12 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t13 MO_U = f66(t9, t10, t11);
        FR_.walking = false; if (mo_walks != w12) LOAD_f65();
        L2 = t13;
    }
    MoValue t14 MO_U = L2.as.xs[1];
    if (t14.as.b) {
        L3 = mo_str("moscope: incomplete: diagnostics exceed the 8 MiB rendered-output limit\012", 72);
        MoValue t15 MO_U = L2.as.xs[0];
        MoValue t16 MO_U = mo_r_String_byte_size((const MoValue[]){t15}, MO_KIND_NONE);
        MoValue t17 MO_U = L3;
        MoValue t18 MO_U = mo_r_String_byte_size((const MoValue[]){t17}, MO_KIND_NONE);
        MoValue t19 MO_U = mo_r_Int_saturating_add((const MoValue[]){t16, t18}, 7);
        MoValue t20 MO_U = L1;
        MoValue t21 MO_U = mo_bool(t19.as.u <= t20.as.u);
        if (t21.as.b) {
            MoValue t22 MO_U = L2.as.xs[0];
            MoValue t23 MO_U = L3;
            MoValue t24 MO_U = mo_concat(2, (const MoValue[]){t22, t23});
            MoValue t25 MO_U = L2;
            MoValue t26 MO_U = mo_set_field(t25, 0, t24);
            L2 = t26;
        }
    }
    MoValue t27 MO_U = L2;
    R = t27;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f65
#undef LOAD_f65
MO_U static MoValue a20(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("notices_text");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    R = t0;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f66() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = R; } while (0)
#define LOAD_f66() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; R = V_[6]; } while (0)
#define ROOTS_f66(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, R}; mo_compact(m, r_, 7); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; R = r_[6]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f66(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("notices_text");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    size_t m352 MO_U = 0, k352 MO_U = 0;
    MoValue V_[7];
    size_t *const M_[] = {&F_, &m352, &k352};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 7, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L3 = t0;
    MoValue t1 MO_U = L1.as.xs[3];
    MoValue t2 MO_U = mo_bool(t1.as.u > mo_i64(INT64_C(0)).as.u);
    if (t2.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f66(); mo_walk(&FR_); LOAD_f66(); }
        MoValue t3 MO_U = L3;
        MoValue t4 MO_U = L1.as.xs[3];
        MoValue t5 MO_U = mo_concat(3, (const MoValue[]){mo_str("moscope: diagnostic: skipped ", 29), t4, mo_str(" discovered symlinks\012", 21)});
        MoValue t6 MO_U = L2;
        SAVE_f66();
        uint64_t w7 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t8 MO_U = f69(t3, t5, t6);
        FR_.walking = false; if (mo_walks != w7) LOAD_f66();
        L3 = t8;
    }
    MoValue t9 MO_U = L3.as.xs[1];
    if (t9.as.b) {
        mo_disown_in(L3);
        MoValue t10 MO_U = L3;
        R = t10;
        goto X350;
    }
    MoValue t11 MO_U = L1;
    MoValue t12 MO_U = t11.as.xs[2];
    MoValue t13 MO_U = mo_r_Map_entries((const MoValue[]){t12}, MO_KIND_NONE);
    MoValue t14 MO_U = mo_closure(a20, 103, 0, NULL);
    MoValue t15 MO_U = mo_r_List_sort_by((const MoValue[]){t13, t14}, MO_KIND_NONE);
    L4 = t15;
    {
        m352 = mo_mark(); k352 = 0;
        for (uint32_t i352 = 0; i352 < L4.aux; i352++) {
            MoValue t16 MO_U = L4.as.xs[i352];
            L5 = t16;
            if (mo_walk_due(&FR_)) { SAVE_f66(); mo_walk(&FR_); LOAD_f66(); }
            MoValue t17 MO_U = L3;
            MoValue t18 MO_U = L5.as.xs[1];
            MoValue t19 MO_U = L5.as.xs[0];
            MoValue t20 MO_U = f74(t19, mo_i64(INT64_C(256)));
            MoValue t21 MO_U = mo_concat(5, (const MoValue[]){mo_str("moscope: diagnostic: ignored ", 29), t18, mo_str(" records of kind ", 17), t20, mo_str("\012", 1)});
            MoValue t22 MO_U = L2;
            SAVE_f66();
            uint64_t w23 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t24 MO_U = f69(t17, t21, t22);
            FR_.walking = false; if (mo_walks != w23) LOAD_f66();
            L3 = t24;
            MoValue t25 MO_U = L3.as.xs[1];
            if (t25.as.b) {
                goto B352;
            }
            ROOTS_f66(m352, k352);
        }
    }
    B352:;
    MoValue t26 MO_U = L3;
    R = t26;
    X350:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f66
#undef SAVE_f66
#undef LOAD_f66
MO_U static MoValue a21(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("incomplete_text");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = mo_bool(mo_compare(MO_EQ, t0, mo_str("<output>", 8)));
    MoValue t2 MO_U = mo_bool(false);
    if (t1.as.b) {
        MoValue t3 MO_U = L0.as.xs[2];
        MoValue t4 MO_U = mo_bool(mo_compare(MO_EQ, t3, mo_str("rendered output exceeds 8 MiB", 29)));
        t2 = t4;
    }
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a22(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("incomplete_text");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = mo_bool(mo_compare(MO_NE, t0, mo_str("<output>", 8)));
    MoValue t2 MO_U = mo_bool(true);
    if (!t1.as.b) {
        MoValue t3 MO_U = L0.as.xs[2];
        MoValue t4 MO_U = mo_bool(mo_compare(MO_NE, t3, mo_str("rendered output exceeds 8 MiB", 29)));
        t2 = t4;
    }
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f67() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = R; } while (0)
#define LOAD_f67() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; R = V_[10]; } while (0)
#define ROOTS_f67(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, R}; mo_compact(m, r_, 11); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; L9 = r_[9]; R = r_[10]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f67(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("incomplete_text");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    size_t m356 MO_U = 0, k356 MO_U = 0;
    MoValue V_[11];
    size_t *const M_[] = {&F_, &m356, &k356};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 11, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L3 = t0;
    MoValue t1 MO_U = L1.as.xs[1];
    MoValue t2 MO_U = mo_closure(a21, 104, 0, NULL);
    MoValue t3 MO_U = mo_r_List_filter((const MoValue[]){t1, t2}, MO_KIND_NONE);
    L4 = t3;
    MoValue t4 MO_U = L1.as.xs[1];
    MoValue t5 MO_U = mo_closure(a22, 105, 0, NULL);
    MoValue t6 MO_U = mo_r_List_filter((const MoValue[]){t4, t5}, MO_KIND_NONE);
    L5 = t6;
    MoValue t7 MO_U = L4;
    MoValue t8 MO_U = L5;
    MoValue t9 MO_U = mo_r_List_concat((const MoValue[]){t7, t8}, MO_KIND_NONE);
    L6 = t9;
    {
        m356 = mo_mark(); k356 = 0;
        for (uint32_t i356 = 0; i356 < L6.aux; i356++) {
            MoValue t10 MO_U = L6.as.xs[i356];
            L7 = t10;
            if (mo_walk_due(&FR_)) { SAVE_f67(); mo_walk(&FR_); LOAD_f67(); }
            MoValue t11 MO_U = L7.as.xs[0];
            SAVE_f67();
            uint64_t w12 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t13 MO_U = f74(t11, mo_i64(INT64_C(512)));
            FR_.walking = false; if (mo_walks != w12) LOAD_f67();
            L8 = t13;
            MoValue t14 MO_U = MO_NONE_V;
            MoValue t15 MO_U = L7.as.xs[1];
            MoValue t16 MO_U = mo_bool(t15.as.u == mo_i64(INT64_C(0)).as.u);
            if (t16.as.b) {
                MoValue t17 MO_U = L8;
                t14 = t17;
            } else {
                MoValue t18 MO_U = L8;
                MoValue t19 MO_U = L7.as.xs[1];
                MoValue t20 MO_U = mo_concat(3, (const MoValue[]){t18, mo_str(":", 1), t19});
                t14 = t20;
            }
            L9 = t14;
            if (mo_walk_due(&FR_)) { SAVE_f67(); mo_walk(&FR_); LOAD_f67(); }
            MoValue t21 MO_U = L3;
            MoValue t22 MO_U = L9;
            MoValue t23 MO_U = L7.as.xs[2];
            MoValue t24 MO_U = f74(t23, mo_i64(INT64_C(512)));
            MoValue t25 MO_U = mo_concat(5, (const MoValue[]){mo_str("moscope: incomplete: ", 21), t22, mo_str(": ", 2), t24, mo_str("\012", 1)});
            MoValue t26 MO_U = L2;
            SAVE_f67();
            uint64_t w27 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t28 MO_U = f69(t21, t25, t26);
            FR_.walking = false; if (mo_walks != w27) LOAD_f67();
            L3 = t28;
            MoValue t29 MO_U = L3.as.xs[1];
            if (t29.as.b) {
                goto B356;
            }
            ROOTS_f67(m356, k356);
        }
    }
    B356:;
    MoValue t30 MO_U = L3.as.xs[1];
    MoValue t31 MO_U = mo_bool(!t30.as.b);
    MoValue t32 MO_U = mo_bool(false);
    if (t31.as.b) {
        MoValue t33 MO_U = L1.as.xs[1];
        MoValue t34 MO_U = mo_r_List_size((const MoValue[]){t33}, MO_KIND_NONE);
        MoValue t35 MO_U = f13();
        MoValue t36 MO_U = mo_bool(t34.as.u >= t35.as.u);
        t32 = t36;
    }
    if (t32.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f67(); mo_walk(&FR_); LOAD_f67(); }
        MoValue t37 MO_U = L3;
        MoValue t38 MO_U = L2;
        SAVE_f67();
        uint64_t w39 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t40 MO_U = f69(t37, mo_str("moscope: incomplete: diagnostic retention limit reached\012", 56), t38);
        FR_.walking = false; if (mo_walks != w39) LOAD_f67();
        L3 = t40;
    }
    MoValue t41 MO_U = L3;
    R = t41;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f67
#undef SAVE_f67
#undef LOAD_f67
#define SAVE_f68() do { V_[0] = L0; V_[1] = L1; V_[2] = R; } while (0)
#define LOAD_f68() do { L0 = V_[0]; L1 = V_[1]; R = V_[2]; } while (0)
MO_U static MoValue f68(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("append");
    MoValue V_[3];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 3, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    if (mo_walk_due(&FR_)) { SAVE_f68(); mo_walk(&FR_); LOAD_f68(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1;
    MoValue t2 MO_U = f15();
    MoValue t3 MO_U = mo_r_Int_saturating_sub((const MoValue[]){t2, mo_i64(INT64_C(512))}, 7);
    SAVE_f68();
    uint64_t w4 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t5 MO_U = f69(t0, t1, t3);
    FR_.walking = false; if (mo_walks != w4) LOAD_f68();
    R = t5;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f68
#undef LOAD_f68
MO_U static MoValue f69(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("append_limit");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0.as.xs[1];
    if (t0.as.b) {
        mo_disown_in(L0);
        MoValue t1 MO_U = L0;
        R = t1;
        goto X358;
    }
    MoValue t2 MO_U = L0.as.xs[0];
    MoValue t3 MO_U = mo_r_String_byte_size((const MoValue[]){t2}, MO_KIND_NONE);
    MoValue t4 MO_U = L1;
    MoValue t5 MO_U = mo_r_String_byte_size((const MoValue[]){t4}, MO_KIND_NONE);
    MoValue t6 MO_U = mo_r_Int_saturating_add((const MoValue[]){t3, t5}, 7);
    MoValue t7 MO_U = L2;
    MoValue t8 MO_U = mo_bool(t6.as.u > t7.as.u);
    if (t8.as.b) {
        MoValue t9 MO_U = L0.as.xs[0];
        MoValue t10 MO_U = mo_record(47, 2, (const MoValue[]){t9, mo_bool(true)});
        R = t10;
        goto X358;
    }
    MoValue t11 MO_U = L0.as.xs[0];
    MoValue t12 MO_U = L1;
    MoValue t13 MO_U = mo_concat(2, (const MoValue[]){t11, t12});
    MoValue t14 MO_U = mo_record(47, 2, (const MoValue[]){t13, mo_bool(false)});
    R = t14;
    X358:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f70(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("result_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f12();
    MoValue t2 MO_U = mo_bool(t0.as.u < t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a23(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("ascii_lower");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_bool(t1.as.u >= mo_i64(INT64_C(65)).as.u);
    MoValue t3 MO_U = mo_bool(false);
    if (t2.as.b) {
        MoValue t4 MO_U = L0;
        MoValue t5 MO_U = mo_bool(t4.as.u <= mo_i64(INT64_C(90)).as.u);
        t3 = t5;
    }
    if (t3.as.b) {
        MoValue t6 MO_U = L0;
        MoValue t7 MO_U = mo_add_u8(t6, mo_i64(INT64_C(32)), 54);
        t0 = t7;
    } else {
        MoValue t8 MO_U = L0;
        t0 = t8;
    }
    R = t0;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f71(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("ascii_lower");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_String_bytes((const MoValue[]){t0}, MO_KIND_NONE);
    MoValue t2 MO_U = mo_closure(a23, 106, 0, NULL);
    MoValue t3 MO_U = mo_r_List_map((const MoValue[]){t1, t2}, 4);
    L1 = t3;
    MoValue t4 MO_U = L1;
    MoValue t5 MO_U = mo_r_String_from_bytes((const MoValue[]){t4}, MO_KIND_NONE);
    L2 = t5;
    MoValue t6 MO_U = MO_NONE_V;
    if (mo_is(L2, MO_N_SOME)) {
        t6 = L2.as.xs[0];
    } else {
        t6 = mo_str("", 0);
    }
    R = t6;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a24(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_terms");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_bool(t1.as.u == mo_i64(INT64_C(9)).as.u);
    MoValue t3 MO_U = mo_bool(true);
    if (!t2.as.b) {
        MoValue t4 MO_U = L0;
        MoValue t5 MO_U = mo_bool(t4.as.u == mo_i64(INT64_C(10)).as.u);
        t3 = t5;
    }
    MoValue t6 MO_U = mo_bool(true);
    if (!t3.as.b) {
        MoValue t7 MO_U = L0;
        MoValue t8 MO_U = mo_bool(t7.as.u == mo_i64(INT64_C(11)).as.u);
        t6 = t8;
    }
    MoValue t9 MO_U = mo_bool(true);
    if (!t6.as.b) {
        MoValue t10 MO_U = L0;
        MoValue t11 MO_U = mo_bool(t10.as.u == mo_i64(INT64_C(12)).as.u);
        t9 = t11;
    }
    MoValue t12 MO_U = mo_bool(true);
    if (!t9.as.b) {
        MoValue t13 MO_U = L0;
        MoValue t14 MO_U = mo_bool(t13.as.u == mo_i64(INT64_C(13)).as.u);
        t12 = t14;
    }
    if (t12.as.b) {
        t0 = mo_i64(INT64_C(32));
    } else {
        MoValue t15 MO_U = L0;
        t0 = t15;
    }
    R = t0;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a25(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_terms");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_bool(mo_compare(MO_NE, t0, mo_str("", 0)));
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_a26() do { V_[0] = L0; V_[1] = R; } while (0)
#define LOAD_a26() do { L0 = V_[0]; R = V_[1]; } while (0)
MO_U static MoValue a26(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_terms");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue V_[2];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 2, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    L0 = args[0];
    (void)cap;
    (void)args;
    if (mo_walk_due(&FR_)) { SAVE_a26(); mo_walk(&FR_); LOAD_a26(); }
    MoValue t0 MO_U = L0;
    SAVE_a26();
    uint64_t w1 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t2 MO_U = f71(t0);
    FR_.walking = false; if (mo_walks != w1) LOAD_a26();
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_a26
#undef LOAD_a26
MO_U static MoValue f72(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_terms");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_String_bytes((const MoValue[]){t0}, MO_KIND_NONE);
    MoValue t2 MO_U = mo_closure(a24, 107, 0, NULL);
    MoValue t3 MO_U = mo_r_List_map((const MoValue[]){t1, t2}, 4);
    L1 = t3;
    MoValue t4 MO_U = L1;
    MoValue t5 MO_U = mo_r_String_from_bytes((const MoValue[]){t4}, MO_KIND_NONE);
    L2 = t5;
    MoValue t6 MO_U = MO_NONE_V;
    if (mo_is(L2, MO_N_SOME)) {
        t6 = L2.as.xs[0];
    } else {
        t6 = mo_str("", 0);
    }
    L3 = t6;
    MoValue t7 MO_U = L3;
    MoValue t8 MO_U = mo_r_String_split((const MoValue[]){t7, mo_str(" ", 1)}, MO_KIND_NONE);
    MoValue t9 MO_U = mo_closure(a25, 108, 0, NULL);
    MoValue t10 MO_U = mo_r_List_filter((const MoValue[]){t8, t9}, MO_KIND_NONE);
    MoValue t11 MO_U = mo_closure(a26, 109, 0, NULL);
    MoValue t12 MO_U = mo_r_List_map((const MoValue[]){t10, t11}, MO_KIND_NONE);
    R = t12;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a27(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("safe");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_bool(t1.as.u >= mo_i64(INT64_C(32)).as.u);
    MoValue t3 MO_U = mo_bool(false);
    if (t2.as.b) {
        MoValue t4 MO_U = L0;
        MoValue t5 MO_U = mo_bool(t4.as.u <= mo_i64(INT64_C(126)).as.u);
        t3 = t5;
    }
    MoValue t6 MO_U = mo_bool(false);
    if (t3.as.b) {
        MoValue t7 MO_U = L0;
        MoValue t8 MO_U = mo_bool(t7.as.u != mo_i64(INT64_C(92)).as.u);
        t6 = t8;
    }
    if (t6.as.b) {
        MoValue t9 MO_U = L0;
        MoValue t10 MO_U = mo_list_of(1, (const MoValue[]){t9});
        MoValue t11 MO_U = mo_r_String_from_bytes((const MoValue[]){t10}, MO_KIND_NONE);
        L1 = t11;
        MoValue t12 MO_U = MO_NONE_V;
        if (mo_is(L1, MO_N_SOME)) {
            t12 = L1.as.xs[0];
        } else {
            t12 = mo_str("", 0);
        }
        t0 = t12;
    } else {
        MoValue t13 MO_U = MO_NONE_V;
        MoValue t14 MO_U = L0;
        MoValue t15 MO_U = mo_bool(t14.as.u == mo_i64(INT64_C(92)).as.u);
        if (t15.as.b) {
            t13 = mo_str("\\\\", 2);
        } else {
            MoValue t16 MO_U = L0;
            MoValue t17 MO_U = f75(t16);
            MoValue t18 MO_U = mo_concat(2, (const MoValue[]){mo_str("\\x", 2), t17});
            t13 = t18;
        }
        t0 = t13;
    }
    R = t0;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f73(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("safe");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_String_bytes((const MoValue[]){t0}, MO_KIND_NONE);
    MoValue t2 MO_U = mo_closure(a27, 110, 0, NULL);
    MoValue t3 MO_U = mo_r_List_map((const MoValue[]){t1, t2}, 4);
    MoValue t4 MO_U = mo_r_String_join((const MoValue[]){t3, mo_str("", 0)}, MO_KIND_NONE);
    R = t4;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f74() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = R; } while (0)
#define LOAD_f74() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; R = V_[4]; } while (0)
MO_U static MoValue f74(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("safe_prefix");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue V_[5];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 5, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_r_String_size((const MoValue[]){t1}, MO_KIND_NONE);
    MoValue t3 MO_U = L1;
    MoValue t4 MO_U = mo_r_min_of((const MoValue[]){t2, t3}, MO_KIND_NONE);
    MoValue t5 MO_U = mo_r_String_slice((const MoValue[]){t0, mo_i64(INT64_C(0)), t4}, MO_KIND_NONE);
    L2 = t5;
    if (mo_walk_due(&FR_)) { SAVE_f74(); mo_walk(&FR_); LOAD_f74(); }
    MoValue t6 MO_U = L2;
    SAVE_f74();
    uint64_t w7 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t8 MO_U = f73(t6);
    FR_.walking = false; if (mo_walks != w7) LOAD_f74();
    L3 = t8;
    MoValue t9 MO_U = MO_NONE_V;
    MoValue t10 MO_U = L0;
    MoValue t11 MO_U = mo_r_String_size((const MoValue[]){t10}, MO_KIND_NONE);
    MoValue t12 MO_U = L1;
    MoValue t13 MO_U = mo_bool(t11.as.u > t12.as.u);
    if (t13.as.b) {
        MoValue t14 MO_U = L3;
        MoValue t15 MO_U = mo_concat(2, (const MoValue[]){t14, mo_str("...", 3)});
        t9 = t15;
    } else {
        MoValue t16 MO_U = L3;
        t9 = t16;
    }
    R = t9;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f74
#undef LOAD_f74
MO_U static MoValue f75(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("hex");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    L1 = mo_str("0123456789ABCDEF", 16);
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_div_u8(t0, mo_i64(INT64_C(16)), 55);
    MoValue t2 MO_U = mo_r_Int_to_u64((const MoValue[]){t1}, 4);
    L2 = t2;
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = mo_rem_u8(t3, mo_i64(INT64_C(16)), 56);
    MoValue t5 MO_U = mo_r_Int_to_u64((const MoValue[]){t4}, 4);
    L3 = t5;
    MoValue t6 MO_U = L1;
    MoValue t7 MO_U = L2;
    MoValue t8 MO_U = L2;
    MoValue t9 MO_U = mo_add_u64(t8, mo_i64(INT64_C(1)), 57);
    MoValue t10 MO_U = mo_r_String_slice((const MoValue[]){t6, t7, t9}, MO_KIND_NONE);
    MoValue t11 MO_U = L1;
    MoValue t12 MO_U = L3;
    MoValue t13 MO_U = L3;
    MoValue t14 MO_U = mo_add_u64(t13, mo_i64(INT64_C(1)), 58);
    MoValue t15 MO_U = mo_r_String_slice((const MoValue[]){t11, t12, t14}, MO_KIND_NONE);
    MoValue t16 MO_U = mo_concat(2, (const MoValue[]){t10, t15});
    R = t16;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f76(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("later");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = L1;
    MoValue t3 MO_U = mo_tuple(2, (const MoValue[]){t1, t2});
    L2 = t3;
    L3 = L2.as.xs[0];
    if (!mo_is(L3, 0)) goto F372;
    L4 = L3.as.xs[0];
    L5 = L4;
    L6 = L2.as.xs[1];
    if (!mo_is(L6, 0)) goto F372;
    L7 = L6.as.xs[0];
    L8 = L7;
    MoValue t4 MO_U = L5;
    MoValue t5 MO_U = L8;
    MoValue t6 MO_U = mo_r_max_of((const MoValue[]){t4, t5}, MO_KIND_NONE);
    MoValue t7 MO_U = mo_variant(0, 1, (const MoValue[]){t6});
    t0 = t7;
    goto E371;
    F372:;
    L9 = L2.as.xs[0];
    if (!mo_is(L9, 0)) goto F373;
    L10 = L9.as.xs[0];
    L11 = L10;
    L12 = L2.as.xs[1];
    if (!mo_is(L12, 1)) goto F373;
    MoValue t8 MO_U = L11;
    MoValue t9 MO_U = mo_variant(0, 1, (const MoValue[]){t8});
    t0 = t9;
    goto E371;
    F373:;
    L13 = L2.as.xs[0];
    if (!mo_is(L13, 1)) goto F374;
    L14 = L2.as.xs[1];
    if (!mo_is(L14, 0)) goto F374;
    L15 = L14.as.xs[0];
    L16 = L15;
    MoValue t10 MO_U = L16;
    MoValue t11 MO_U = mo_variant(0, 1, (const MoValue[]){t10});
    t0 = t11;
    goto E371;
    F374:;
    L17 = L2.as.xs[0];
    if (!mo_is(L17, 1)) goto F375;
    L18 = L2.as.xs[1];
    if (!mo_is(L18, 1)) goto F375;
    MoValue t12 MO_U = mo_variant(1, 0, NULL);
    t0 = t12;
    goto E371;
    F375:;
    mo_crash(59);
    E371:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f77(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("problem");
    MoValue L4 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L4 = t0;
    MoValue t1 MO_U = L4;
    MoValue t2 MO_U = mo_set_field(t1, 8, mo_bool(true));
    L4 = t2;
    MoValue t3 MO_U = L4.as.xs[1];
    MoValue t4 MO_U = mo_r_List_size((const MoValue[]){t3}, MO_KIND_NONE);
    MoValue t5 MO_U = f13();
    MoValue t6 MO_U = mo_bool(t4.as.u < t5.as.u);
    if (t6.as.b) {
        MoValue t7 MO_U = L4.as.xs[1];
        MoValue t8 MO_U = L1;
        MoValue t9 MO_U = L2;
        MoValue t10 MO_U = L3;
        MoValue t11 MO_U = mo_record(34, 3, (const MoValue[]){t8, t9, t10});
        mo_disown_in(t11);
        MoValue t12 MO_U = mo_r_List_push((const MoValue[]){t7, t11}, MO_KIND_NONE);
        MoValue t13 MO_U = L4;
        MoValue t14 MO_U = mo_set_field(t13, 1, t12);
        L4 = t14;
    }
    MoValue t15 MO_U = L4;
    R = t15;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f78(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("usage");
    if (mo_contracts) {
    }
    R = mo_str("usage: moscope search <query> <directory> [--all-words] [--include-tools]", 73);
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f79() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = R; } while (0)
#define LOAD_f79() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; R = V_[12]; } while (0)
#define ROOTS_f79(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11, R}; mo_compact(m, r_, 13); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; L9 = r_[9]; L10 = r_[10]; L11 = r_[11]; R = r_[12]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f79(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("options");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    size_t m379 MO_U = 0, k379 MO_U = 0;
    MoValue V_[13];
    size_t *const M_[] = {&F_, &m379, &k379};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 13, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_List_first((const MoValue[]){t0}, MO_KIND_NONE);
    MoValue t2 MO_U = mo_variant(0, 1, (const MoValue[]){mo_str("search", 6)});
    MoValue t3 MO_U = mo_bool(mo_compare(MO_NE, t1, t2));
    if (t3.as.b) {
        MoValue t4 MO_U = mo_variant(58, 1, (const MoValue[]){mo_str("the first argument must be search", 33)});
        MoValue t5 MO_U = mo_variant(3, 1, (const MoValue[]){t4});
        R = t5;
        goto X378;
    }
    MoValue t6 MO_U = mo_list_of(0, NULL);
    L1 = t6;
    L2 = mo_bool(false);
    L3 = mo_bool(false);
    MoValue t7 MO_U = L0;
    MoValue t8 MO_U = mo_r_List_drop((const MoValue[]){t7, mo_i64(INT64_C(1))}, MO_KIND_NONE);
    L4 = t8;
    {
        m379 = mo_mark(); k379 = 0;
        for (uint32_t i379 = 0; i379 < L4.aux; i379++) {
            MoValue t9 MO_U = L4.as.xs[i379];
            L5 = t9;
            MoValue t10 MO_U = L5;
            MoValue t11 MO_U = mo_bool(mo_compare(MO_EQ, t10, mo_str("--all-words", 11)));
            if (t11.as.b) {
                MoValue t12 MO_U = L2;
                if (t12.as.b) {
                    MoValue t13 MO_U = mo_variant(58, 1, (const MoValue[]){mo_str("duplicate --all-words", 21)});
                    MoValue t14 MO_U = mo_variant(3, 1, (const MoValue[]){t13});
                    R = t14;
                    goto X378;
                }
                L2 = mo_bool(true);
            } else {
                MoValue t15 MO_U = L5;
                MoValue t16 MO_U = mo_bool(mo_compare(MO_EQ, t15, mo_str("--include-tools", 15)));
                if (t16.as.b) {
                    MoValue t17 MO_U = L3;
                    if (t17.as.b) {
                        MoValue t18 MO_U = mo_variant(58, 1, (const MoValue[]){mo_str("duplicate --include-tools", 25)});
                        MoValue t19 MO_U = mo_variant(3, 1, (const MoValue[]){t18});
                        R = t19;
                        goto X378;
                    }
                    L3 = mo_bool(true);
                } else {
                    MoValue t20 MO_U = L5;
                    MoValue t21 MO_U = mo_r_String_starts_with_q((const MoValue[]){t20, mo_str("-", 1)}, MO_KIND_NONE);
                    if (t21.as.b) {
                        MoValue t22 MO_U = L5;
                        MoValue t23 MO_U = f80(t22);
                        MoValue t24 MO_U = mo_variant(58, 1, (const MoValue[]){t23});
                        MoValue t25 MO_U = mo_variant(3, 1, (const MoValue[]){t24});
                        R = t25;
                        goto X378;
                    }
                    MoValue t26 MO_U = L1;
                    MoValue t27 MO_U = L5;
                    MoValue t28 MO_U = mo_r_List_push((const MoValue[]){t26, t27}, MO_KIND_NONE);
                    L1 = t28;
                }
            }
            ROOTS_f79(m379, k379);
        }
    }
    MoValue t29 MO_U = L1;
    MoValue t30 MO_U = mo_r_List_size((const MoValue[]){t29}, MO_KIND_NONE);
    MoValue t31 MO_U = mo_bool(t30.as.u != mo_i64(INT64_C(2)).as.u);
    if (t31.as.b) {
        MoValue t32 MO_U = mo_variant(58, 1, (const MoValue[]){mo_str("search needs exactly one query and one directory", 48)});
        MoValue t33 MO_U = mo_variant(3, 1, (const MoValue[]){t32});
        R = t33;
        goto X378;
    }
    MoValue t34 MO_U = L1;
    MoValue t35 MO_U = mo_r_List_get((const MoValue[]){t34, mo_i64(INT64_C(0))}, MO_KIND_NONE);
    L6 = t35;
    MoValue t36 MO_U = MO_NONE_V;
    if (mo_is(L6, MO_N_SOME)) {
        t36 = L6.as.xs[0];
    } else {
        t36 = mo_str("", 0);
    }
    L7 = t36;
    MoValue t37 MO_U = L1;
    MoValue t38 MO_U = mo_r_List_get((const MoValue[]){t37, mo_i64(INT64_C(1))}, MO_KIND_NONE);
    L8 = t38;
    MoValue t39 MO_U = MO_NONE_V;
    if (mo_is(L8, MO_N_SOME)) {
        t39 = L8.as.xs[0];
    } else {
        t39 = mo_str("", 0);
    }
    L9 = t39;
    MoValue t40 MO_U = L7;
    MoValue t41 MO_U = mo_r_String_byte_size((const MoValue[]){t40}, MO_KIND_NONE);
    MoValue t42 MO_U = f0();
    MoValue t43 MO_U = mo_bool(t41.as.u > t42.as.u);
    if (t43.as.b) {
        MoValue t44 MO_U = mo_variant(58, 1, (const MoValue[]){mo_str("query exceeds 4096 bytes", 24)});
        MoValue t45 MO_U = mo_variant(3, 1, (const MoValue[]){t44});
        R = t45;
        goto X378;
    }
    if (mo_walk_due(&FR_)) { SAVE_f79(); mo_walk(&FR_); LOAD_f79(); }
    MoValue t46 MO_U = L7;
    SAVE_f79();
    uint64_t w47 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t48 MO_U = f72(t46);
    FR_.walking = false; if (mo_walks != w47) LOAD_f79();
    L10 = t48;
    MoValue t49 MO_U = L10;
    MoValue t50 MO_U = mo_r_List_size((const MoValue[]){t49}, MO_KIND_NONE);
    MoValue t51 MO_U = mo_bool(t50.as.u == mo_i64(INT64_C(0)).as.u);
    if (t51.as.b) {
        MoValue t52 MO_U = mo_variant(58, 1, (const MoValue[]){mo_str("query is empty or ASCII whitespace only", 39)});
        MoValue t53 MO_U = mo_variant(3, 1, (const MoValue[]){t52});
        R = t53;
        goto X378;
    }
    MoValue t54 MO_U = L2;
    MoValue t55 MO_U = mo_bool(false);
    if (t54.as.b) {
        MoValue t56 MO_U = L10;
        MoValue t57 MO_U = mo_r_List_size((const MoValue[]){t56}, MO_KIND_NONE);
        MoValue t58 MO_U = f1();
        MoValue t59 MO_U = mo_bool(t57.as.u > t58.as.u);
        t55 = t59;
    }
    if (t55.as.b) {
        MoValue t60 MO_U = mo_variant(58, 1, (const MoValue[]){mo_str("--all-words query exceeds 64 terms", 34)});
        MoValue t61 MO_U = mo_variant(3, 1, (const MoValue[]){t60});
        R = t61;
        goto X378;
    }
    MoValue t62 MO_U = L9;
    MoValue t63 MO_U = mo_bool(mo_compare(MO_EQ, t62, mo_str("", 0)));
    if (t63.as.b) {
        MoValue t64 MO_U = mo_variant(58, 1, (const MoValue[]){mo_str("directory is empty", 18)});
        MoValue t65 MO_U = mo_variant(3, 1, (const MoValue[]){t64});
        R = t65;
        goto X378;
    }
    MoValue t66 MO_U = MO_NONE_V;
    MoValue t67 MO_U = L2;
    if (t67.as.b) {
        MoValue t68 MO_U = mo_variant(57, 0, NULL);
        t66 = t68;
    } else {
        MoValue t69 MO_U = mo_variant(56, 0, NULL);
        t66 = t69;
    }
    L11 = t66;
    MoValue t70 MO_U = L7;
    MoValue t71 MO_U = L9;
    MoValue t72 MO_U = L11;
    MoValue t73 MO_U = L3;
    MoValue t74 MO_U = mo_record(29, 4, (const MoValue[]){t70, t71, t72, t73});
    MoValue t75 MO_U = mo_variant(2, 1, (const MoValue[]){t74});
    R = t75;
    X378:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f79
#undef SAVE_f79
#undef LOAD_f79
MO_U static MoValue f80(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("unsupported");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_r_String_size((const MoValue[]){t1}, MO_KIND_NONE);
    MoValue t3 MO_U = mo_r_min_of((const MoValue[]){t2, mo_i64(INT64_C(256))}, MO_KIND_NONE);
    MoValue t4 MO_U = mo_r_String_slice((const MoValue[]){t0, mo_i64(INT64_C(0)), t3}, MO_KIND_NONE);
    L1 = t4;
    MoValue t5 MO_U = MO_NONE_V;
    MoValue t6 MO_U = L0;
    MoValue t7 MO_U = mo_r_String_size((const MoValue[]){t6}, MO_KIND_NONE);
    MoValue t8 MO_U = mo_bool(t7.as.u > mo_i64(INT64_C(256)).as.u);
    if (t8.as.b) {
        t5 = mo_str("...", 3);
    } else {
        t5 = mo_str("", 0);
    }
    L2 = t5;
    MoValue t9 MO_U = L1;
    MoValue t10 MO_U = f73(t9);
    MoValue t11 MO_U = L2;
    MoValue t12 MO_U = mo_concat(3, (const MoValue[]){mo_str("unsupported option ", 19), t10, t11});
    R = t12;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f81() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = R; } while (0)
#define LOAD_f81() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; R = V_[5]; } while (0)
MO_U static MoValue f81(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("analyze");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue V_[6];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 6, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L1;
    MoValue t1 MO_U = mo_r_Clock_now((const MoValue[]){t0}, MO_KIND_NONE);
    L3 = t1;
    MoValue t2 MO_U = L0;
    MoValue t3 MO_U = L2.as.xs[1];
    MoValue t4 MO_U = mo_r_Fs_scoped((const MoValue[]){t2, t3}, MO_KIND_NONE);
    MoValue t5 MO_U = mo_r_Fs_read_only((const MoValue[]){t4}, MO_KIND_NONE);
    L4 = t5;
    if (mo_walk_due(&FR_)) { SAVE_f81(); mo_walk(&FR_); LOAD_f81(); }
    MoValue t6 MO_U = L4;
    MoValue t7 MO_U = L1;
    MoValue t8 MO_U = L3;
    MoValue t9 MO_U = f45(t6, t7, t8);
    MoValue t10 MO_U = L2;
    MoValue t11 MO_U = L1;
    MoValue t12 MO_U = L3;
    SAVE_f81();
    uint64_t w13 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t14 MO_U = f57(t9, t10, t11, t12);
    FR_.walking = false; if (mo_walks != w13) LOAD_f81();
    R = t14;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f81
#undef LOAD_f81
#define SAVE_f82() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = R; } while (0)
#define LOAD_f82() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; R = V_[8]; } while (0)
MO_U static MoValue f82(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("main");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue V_[9];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 9, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_r_Platform_args((const MoValue[]){t1}, MO_KIND_NONE);
    MoValue t3 MO_U = f79(t2);
    L1 = t3;
    if (!mo_is(L1, 3)) goto F384;
    L2 = L1.as.xs[0];
    if (!mo_is(L2, 58)) goto F384;
    L3 = L2.as.xs[0];
    L4 = L3;
    MoValue t4 MO_U = L0;
    MoValue t5 MO_U = mo_r_Platform_stderr((const MoValue[]){t4}, MO_KIND_NONE);
    MoValue t6 MO_U = L4;
    MoValue t7 MO_U = f78();
    MoValue t8 MO_U = mo_concat(4, (const MoValue[]){mo_str("moscope: ", 9), t6, mo_str("; ", 2), t7});
    MoValue t9 MO_U = mo_r_Out_write_line((const MoValue[]){t5, t8}, MO_KIND_NONE);
    MoValue t10 MO_U = L0;
    MoValue t11 MO_U = mo_r_Platform_exit((const MoValue[]){t10, mo_i64(INT64_C(2))}, MO_KIND_NONE);
    t0 = t11;
    goto E383;
    F384:;
    if (!mo_is(L1, 2)) goto F385;
    L5 = L1.as.xs[0];
    L6 = L5;
    if (mo_walk_due(&FR_)) { SAVE_f82(); mo_walk(&FR_); LOAD_f82(); }
    MoValue t12 MO_U = L0;
    MoValue t13 MO_U = mo_r_Platform_fs((const MoValue[]){t12}, MO_KIND_NONE);
    MoValue t14 MO_U = L0;
    MoValue t15 MO_U = mo_r_Platform_clock((const MoValue[]){t14}, MO_KIND_NONE);
    MoValue t16 MO_U = L6;
    SAVE_f82();
    uint64_t w17 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t18 MO_U = f81(t13, t15, t16);
    FR_.walking = false; if (mo_walks != w17) LOAD_f82();
    L7 = t18;
    MoValue t19 MO_U = L0;
    MoValue t20 MO_U = mo_r_Platform_stdout((const MoValue[]){t19}, MO_KIND_NONE);
    MoValue t21 MO_U = L7.as.xs[0];
    MoValue t22 MO_U = mo_r_Out_write((const MoValue[]){t20, t21}, MO_KIND_NONE);
    MoValue t23 MO_U = L7.as.xs[1];
    MoValue t24 MO_U = mo_bool(mo_compare(MO_NE, t23, mo_str("", 0)));
    if (t24.as.b) {
        MoValue t25 MO_U = L0;
        MoValue t26 MO_U = mo_r_Platform_stderr((const MoValue[]){t25}, MO_KIND_NONE);
        MoValue t27 MO_U = L7.as.xs[1];
        MoValue t28 MO_U = mo_r_Out_write((const MoValue[]){t26, t27}, MO_KIND_NONE);
    }
    MoValue t29 MO_U = MO_NONE_V;
    MoValue t30 MO_U = L7.as.xs[3];
    if (t30.as.b) {
        MoValue t31 MO_U = L0;
        MoValue t32 MO_U = mo_r_Platform_exit((const MoValue[]){t31, mo_i64(INT64_C(2))}, MO_KIND_NONE);
        t29 = t32;
    } else {
        MoValue t33 MO_U = MO_NONE_V;
        MoValue t34 MO_U = L7.as.xs[2];
        MoValue t35 MO_U = mo_bool(t34.as.u == mo_i64(INT64_C(0)).as.u);
        if (t35.as.b) {
            MoValue t36 MO_U = L0;
            MoValue t37 MO_U = mo_r_Platform_exit((const MoValue[]){t36, mo_i64(INT64_C(1))}, MO_KIND_NONE);
        }
        t29 = t33;
    }
    t0 = t29;
    goto E383;
    F385:;
    mo_crash(60);
    E383:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f82
#undef LOAD_f82
MO_U static MoValue test0(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("flags combine in either order and duplicate or unsupported arguments are rejected");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue t0 MO_U = mo_list_of(5, (const MoValue[]){mo_str("search", 6), mo_str("needle", 6), mo_str("sessions", 8), mo_str("--all-words", 11), mo_str("--include-tools", 15)});
    MoValue t1 MO_U = f79(t0);
    L0 = t1;
    MoValue t2 MO_U = mo_bool(true);
    if (!mo_is(L0, 2)) goto F387;
    L1 = L0.as.xs[0];
    L2 = L1;
    goto E388;
    F387:;
    t2 = mo_bool(false);
    E388:;
    if (!t2.as.b) mo_crash(61);
    MoValue t3 MO_U = L2.as.xs[2];
    MoValue t4 MO_U = mo_variant(57, 0, NULL);
    MoValue t5 MO_U = mo_bool(mo_compare(MO_EQ, t3, t4));
    MoValue t6 MO_U = mo_bool(false);
    if (t5.as.b) {
        MoValue t7 MO_U = L2.as.xs[3];
        t6 = t7;
    }
    if (!t6.as.b) mo_crash(62);
    MoValue t8 MO_U = mo_list_of(5, (const MoValue[]){mo_str("search", 6), mo_str("needle", 6), mo_str("sessions", 8), mo_str("--include-tools", 15), mo_str("--all-words", 11)});
    MoValue t9 MO_U = f79(t8);
    L3 = t9;
    MoValue t10 MO_U = mo_bool(true);
    if (!mo_is(L3, 2)) goto F389;
    goto E390;
    F389:;
    t10 = mo_bool(false);
    E390:;
    if (!t10.as.b) mo_crash(63);
    MoValue t11 MO_U = mo_list_of(5, (const MoValue[]){mo_str("search", 6), mo_str("needle", 6), mo_str("sessions", 8), mo_str("--all-words", 11), mo_str("--all-words", 11)});
    MoValue t12 MO_U = f79(t11);
    L4 = t12;
    MoValue t13 MO_U = mo_bool(true);
    if (!mo_is(L4, 3)) goto F391;
    L5 = L4.as.xs[0];
    if (!mo_is(L5, 58)) goto F391;
    goto E392;
    F391:;
    t13 = mo_bool(false);
    E392:;
    if (!t13.as.b) mo_crash(64);
    MoValue t14 MO_U = mo_list_of(4, (const MoValue[]){mo_str("search", 6), mo_str("needle", 6), mo_str("sessions", 8), mo_str("--regex", 7)});
    MoValue t15 MO_U = f79(t14);
    L6 = t15;
    MoValue t16 MO_U = mo_bool(true);
    if (!mo_is(L6, 3)) goto F393;
    L7 = L6.as.xs[0];
    if (!mo_is(L7, 58)) goto F393;
    goto E394;
    F393:;
    t16 = mo_bool(false);
    E394:;
    if (!t16.as.b) mo_crash(65);
    MoValue t17 MO_U = mo_list_of(3, (const MoValue[]){mo_str("find", 4), mo_str("needle", 6), mo_str("sessions", 8)});
    MoValue t18 MO_U = f79(t17);
    L8 = t18;
    MoValue t19 MO_U = mo_bool(true);
    if (!mo_is(L8, 3)) goto F395;
    L9 = L8.as.xs[0];
    if (!mo_is(L9, 58)) goto F395;
    goto E396;
    F395:;
    t19 = mo_bool(false);
    E396:;
    if (!t19.as.b) mo_crash(66);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue test1(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("blank and oversized queries and malformed positional counts are usage errors");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue t0 MO_U = mo_list_of(3, (const MoValue[]){mo_str("search", 6), mo_str(" \011\015\012", 4), mo_str("sessions", 8)});
    MoValue t1 MO_U = f79(t0);
    L0 = t1;
    MoValue t2 MO_U = mo_bool(true);
    if (!mo_is(L0, 3)) goto F398;
    L1 = L0.as.xs[0];
    if (!mo_is(L1, 58)) goto F398;
    goto E399;
    F398:;
    t2 = mo_bool(false);
    E399:;
    if (!t2.as.b) mo_crash(67);
    MoValue t3 MO_U = mo_r_String_repeat((const MoValue[]){mo_str("x", 1), mo_i64(INT64_C(4097))}, MO_KIND_NONE);
    MoValue t4 MO_U = mo_list_of(3, (const MoValue[]){mo_str("search", 6), t3, mo_str("sessions", 8)});
    MoValue t5 MO_U = f79(t4);
    L2 = t5;
    MoValue t6 MO_U = mo_bool(true);
    if (!mo_is(L2, 3)) goto F400;
    L3 = L2.as.xs[0];
    if (!mo_is(L3, 58)) goto F400;
    goto E401;
    F400:;
    t6 = mo_bool(false);
    E401:;
    if (!t6.as.b) mo_crash(68);
    MoValue t7 MO_U = mo_list_of(2, (const MoValue[]){mo_str("search", 6), mo_str("needle", 6)});
    MoValue t8 MO_U = f79(t7);
    L4 = t8;
    MoValue t9 MO_U = mo_bool(true);
    if (!mo_is(L4, 3)) goto F402;
    L5 = L4.as.xs[0];
    if (!mo_is(L5, 58)) goto F402;
    goto E403;
    F402:;
    t9 = mo_bool(false);
    E403:;
    if (!t9.as.b) mo_crash(69);
    MoValue t10 MO_U = mo_list_of(4, (const MoValue[]){mo_str("search", 6), mo_str("needle", 6), mo_str("one", 3), mo_str("two", 3)});
    MoValue t11 MO_U = f79(t10);
    L6 = t11;
    MoValue t12 MO_U = mo_bool(true);
    if (!mo_is(L6, 3)) goto F404;
    L7 = L6.as.xs[0];
    if (!mo_is(L7, 58)) goto F404;
    goto E405;
    F404:;
    t12 = mo_bool(false);
    E405:;
    if (!t12.as.b) mo_crash(70);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue test2(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("all six ASCII separators are blank and query and term boundaries are exact");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue t0 MO_U = mo_list_of(3, (const MoValue[]){mo_str("search", 6), mo_str(" \011\012\013\014\015", 6), mo_str("sessions", 8)});
    MoValue t1 MO_U = f79(t0);
    L0 = t1;
    MoValue t2 MO_U = mo_bool(true);
    if (!mo_is(L0, 3)) goto F407;
    L1 = L0.as.xs[0];
    if (!mo_is(L1, 58)) goto F407;
    goto E408;
    F407:;
    t2 = mo_bool(false);
    E408:;
    if (!t2.as.b) mo_crash(71);
    MoValue t3 MO_U = mo_r_String_repeat((const MoValue[]){mo_str("x", 1), mo_i64(INT64_C(4096))}, MO_KIND_NONE);
    MoValue t4 MO_U = mo_list_of(3, (const MoValue[]){mo_str("search", 6), t3, mo_str("sessions", 8)});
    MoValue t5 MO_U = f79(t4);
    L2 = t5;
    MoValue t6 MO_U = mo_bool(true);
    if (!mo_is(L2, 2)) goto F409;
    goto E410;
    F409:;
    t6 = mo_bool(false);
    E410:;
    if (!t6.as.b) mo_crash(72);
    MoValue t7 MO_U = mo_r_String_repeat((const MoValue[]){mo_str("x ", 2), mo_i64(INT64_C(64))}, MO_KIND_NONE);
    MoValue t8 MO_U = mo_list_of(4, (const MoValue[]){mo_str("search", 6), t7, mo_str("sessions", 8), mo_str("--all-words", 11)});
    MoValue t9 MO_U = f79(t8);
    L3 = t9;
    MoValue t10 MO_U = mo_bool(true);
    if (!mo_is(L3, 2)) goto F411;
    goto E412;
    F411:;
    t10 = mo_bool(false);
    E412:;
    if (!t10.as.b) mo_crash(73);
    MoValue t11 MO_U = mo_r_String_repeat((const MoValue[]){mo_str("x ", 2), mo_i64(INT64_C(65))}, MO_KIND_NONE);
    MoValue t12 MO_U = mo_list_of(4, (const MoValue[]){mo_str("search", 6), t11, mo_str("sessions", 8), mo_str("--all-words", 11)});
    MoValue t13 MO_U = f79(t12);
    L4 = t13;
    MoValue t14 MO_U = mo_bool(true);
    if (!mo_is(L4, 3)) goto F413;
    L5 = L4.as.xs[0];
    if (!mo_is(L5, 58)) goto F413;
    goto E414;
    F413:;
    t14 = mo_bool(false);
    E414:;
    if (!t14.as.b) mo_crash(74);
    MoValue t15 MO_U = mo_r_String_repeat((const MoValue[]){mo_str("x ", 2), mo_i64(INT64_C(65))}, MO_KIND_NONE);
    MoValue t16 MO_U = mo_list_of(3, (const MoValue[]){mo_str("search", 6), t15, mo_str("sessions", 8)});
    MoValue t17 MO_U = f79(t16);
    L6 = t17;
    MoValue t18 MO_U = mo_bool(true);
    if (!mo_is(L6, 2)) goto F415;
    goto E416;
    F415:;
    t18 = mo_bool(false);
    E416:;
    if (!t18.as.b) mo_crash(75);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue test3(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("flags are allowed around positionals while every missing duplicate and option shape rejects");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue t0 MO_U = mo_list_of(5, (const MoValue[]){mo_str("search", 6), mo_str("--all-words", 11), mo_str("needle", 6), mo_str("--include-tools", 15), mo_str("sessions", 8)});
    MoValue t1 MO_U = f79(t0);
    L0 = t1;
    MoValue t2 MO_U = mo_bool(true);
    if (!mo_is(L0, 2)) goto F418;
    goto E419;
    F418:;
    t2 = mo_bool(false);
    E419:;
    if (!t2.as.b) mo_crash(76);
    MoValue t3 MO_U = mo_list_of(5, (const MoValue[]){mo_str("search", 6), mo_str("--include-tools", 15), mo_str("needle", 6), mo_str("sessions", 8), mo_str("--all-words", 11)});
    MoValue t4 MO_U = f79(t3);
    L1 = t4;
    MoValue t5 MO_U = mo_bool(true);
    if (!mo_is(L1, 2)) goto F420;
    goto E421;
    F420:;
    t5 = mo_bool(false);
    E421:;
    if (!t5.as.b) mo_crash(77);
    MoValue t6 MO_U = mo_list_of(0, NULL);
    MoValue t7 MO_U = f79(t6);
    L2 = t7;
    MoValue t8 MO_U = mo_bool(true);
    if (!mo_is(L2, 3)) goto F422;
    L3 = L2.as.xs[0];
    if (!mo_is(L3, 58)) goto F422;
    goto E423;
    F422:;
    t8 = mo_bool(false);
    E423:;
    if (!t8.as.b) mo_crash(78);
    MoValue t9 MO_U = mo_list_of(3, (const MoValue[]){mo_str("find", 4), mo_str("needle", 6), mo_str("sessions", 8)});
    MoValue t10 MO_U = f79(t9);
    L4 = t10;
    MoValue t11 MO_U = mo_bool(true);
    if (!mo_is(L4, 3)) goto F424;
    L5 = L4.as.xs[0];
    if (!mo_is(L5, 58)) goto F424;
    goto E425;
    F424:;
    t11 = mo_bool(false);
    E425:;
    if (!t11.as.b) mo_crash(79);
    MoValue t12 MO_U = mo_list_of(5, (const MoValue[]){mo_str("search", 6), mo_str("needle", 6), mo_str("sessions", 8), mo_str("--include-tools", 15), mo_str("--include-tools", 15)});
    MoValue t13 MO_U = f79(t12);
    L6 = t13;
    MoValue t14 MO_U = mo_bool(true);
    if (!mo_is(L6, 3)) goto F426;
    L7 = L6.as.xs[0];
    if (!mo_is(L7, 58)) goto F426;
    goto E427;
    F426:;
    t14 = mo_bool(false);
    E427:;
    if (!t14.as.b) mo_crash(80);
    MoValue t15 MO_U = mo_list_of(4, (const MoValue[]){mo_str("search", 6), mo_str("needle", 6), mo_str("sessions", 8), mo_str("--bad\007", 6)});
    MoValue t16 MO_U = f79(t15);
    L8 = t16;
    MoValue t17 MO_U = mo_bool(true);
    if (!mo_is(L8, 3)) goto F428;
    L9 = L8.as.xs[0];
    if (!mo_is(L9, 58)) goto F428;
    goto E429;
    F428:;
    t17 = mo_bool(false);
    E429:;
    if (!t17.as.b) mo_crash(81);
    MoValue t18 MO_U = mo_list_of(3, (const MoValue[]){mo_str("search", 6), mo_str("needle", 6), mo_str("", 0)});
    MoValue t19 MO_U = f79(t18);
    L10 = t19;
    MoValue t20 MO_U = mo_bool(true);
    if (!mo_is(L10, 3)) goto F430;
    L11 = L10.as.xs[0];
    if (!mo_is(L11, 58)) goto F430;
    goto E431;
    F430:;
    t20 = mo_bool(false);
    E431:;
    if (!t20.as.b) mo_crash(82);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}

int main(void) {
    return mo_run_tests();
}
