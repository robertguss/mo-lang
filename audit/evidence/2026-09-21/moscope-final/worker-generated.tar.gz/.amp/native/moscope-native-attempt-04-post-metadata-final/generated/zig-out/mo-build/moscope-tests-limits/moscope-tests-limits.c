/* Written by mo build (toolchain/src/emit_c.zig); links toolchain/runtime/mo_rt.c. */
#include "mo_rt.h"

MO_U static MoValue f0(void);
MO_U static MoValue f1(void);
MO_U static MoValue f2(void);
MO_U static MoValue f3(void);
MO_U static MoValue f4(void);
MO_U static MoValue f5(void);
MO_U static MoValue f6(void);
MO_U static MoValue f7(void);
MO_U static MoValue f8(void);
MO_U static MoValue f9(void);
MO_U static MoValue f10(void);
MO_U static MoValue f11(void);
MO_U static MoValue f12(void);
MO_U static MoValue f13(void);
MO_U static MoValue f14(void);
MO_U static MoValue f15(void);
MO_U static MoValue f16(void);
MO_U static MoValue f17(void);
MO_U static MoValue test0(void);

static const MoField decl_fields_0[] = {{NULL, 0}};
static const MoRefineFn decl_refines_0[] = {NULL};
static const MoField decl_fields_1[] = {{NULL, 0}};
static const MoRefineFn decl_refines_1[] = {NULL};
static const MoField decl_fields_2[] = {{NULL, 0}};
static const MoRefineFn decl_refines_2[] = {NULL};
static const MoField decl_fields_3[] = {{NULL, 0}};
static const MoRefineFn decl_refines_3[] = {NULL};
static const MoField decl_fields_4[] = {{NULL, 0}};
static const MoRefineFn decl_refines_4[] = {NULL};
static const MoField decl_fields_5[] = {{NULL, 0}};
static const MoRefineFn decl_refines_5[] = {NULL};
static const MoField decl_fields_6[] = {{NULL, 0}};
static const MoRefineFn decl_refines_6[] = {NULL};
static const MoField decl_fields_7[] = {{NULL, 0}};
static const MoRefineFn decl_refines_7[] = {NULL};
static const MoField decl_fields_8[] = {{NULL, 0}};
static const MoRefineFn decl_refines_8[] = {NULL};
static const MoField decl_fields_9[] = {{NULL, 0}};
static const MoRefineFn decl_refines_9[] = {NULL};
static const MoField decl_fields_10[] = {{NULL, 0}};
static const MoRefineFn decl_refines_10[] = {NULL};
static const MoField decl_fields_11[] = {{NULL, 0}};
static const MoRefineFn decl_refines_11[] = {NULL};
static const MoField decl_fields_12[] = {{NULL, 0}};
static const MoRefineFn decl_refines_12[] = {NULL};
static const MoField decl_fields_13[] = {{NULL, 0}};
static const MoRefineFn decl_refines_13[] = {NULL};
static const MoField decl_fields_14[] = {{NULL, 0}};
static const MoRefineFn decl_refines_14[] = {NULL};
static const MoField decl_fields_15[] = {{NULL, 0}};
static const MoRefineFn decl_refines_15[] = {NULL};
static const MoField decl_fields_16[] = {{NULL, 0}};
static const MoRefineFn decl_refines_16[] = {NULL};
static const MoField decl_fields_17[] = {{"id", 0}, {"captured_at", 2}, {"captured_amount", 3}, {"refunded", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_17[] = {NULL};
static const MoField decl_fields_18[] = {{"id", 0}, {"amount", 3}, {NULL, 0}};
static const MoRefineFn decl_refines_18[] = {NULL};
static const MoField decl_fields_19[] = {{"refund", 6}, {NULL, 0}};
static const MoRefineFn decl_refines_19[] = {NULL};
static const MoField decl_fields_20[] = {{"request", 7}, {"reason", 8}, {NULL, 0}};
static const MoRefineFn decl_refines_20[] = {NULL};
static const MoField decl_fields_21[] = {{"method", 1}, {"path", 1}, {"query", 9}, {"headers", 10}, {"body", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_21[] = {NULL};
static const MoField decl_fields_22[] = {{"status", 11}, {"headers", 12}, {"body", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_22[] = {NULL};
static const MoField decl_fields_23[] = {{"id", 4}, {"name", 1}, {"alive", 5}, {"mailbox", 4}, {"bound", 4}, {"waiting_in", 13}, {"restarts", 4}, {"region_bytes", 4}, {"paused", 5}, {"scheduler", 4}, {NULL, 0}};
static const MoRefineFn decl_refines_23[] = {NULL};
static const MoField decl_fields_24[] = {{"kind", 1}, {"target", 4}, {"name", 1}, {"in_flight", 4}, {"paused", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_24[] = {NULL};
static const MoField decl_fields_25[] = {{"name", 1}, {"kind", 14}, {"links", 4}, {"setuid", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_25[] = {NULL};
static const MoField decl_fields_26[] = {{"exit", 15}, {"stdout", 16}, {"stderr", 18}, {"truncated", 5}, {"took", 19}, {NULL, 0}};
static const MoRefineFn decl_refines_26[] = {NULL};
static const MoField decl_fields_27[] = {{"resident_bytes", 4}, {"region_bytes", 4}, {"region_resident_bytes", 4}, {"packed_bytes", 4}, {"event_bytes", 4}, {"largest", 20}, {NULL, 0}};
static const MoRefineFn decl_refines_27[] = {NULL};
static const MoField variant_fields_0[] = {{"path", 1}, {NULL, 0}};
static const MoField variant_fields_1[] = {{NULL, 0}};
static const MoField variant_fields_2[] = {{NULL, 0}};
static const MoField variant_fields_3[] = {{NULL, 0}};
static const MoField variant_fields_4[] = {{NULL, 0}};
static const MoField variant_fields_5[] = {{NULL, 0}};
static const MoField variant_fields_6[] = {{"fields", 22}, {NULL, 0}};
static const MoField variant_fields_7[] = {{"items", 24}, {NULL, 0}};
static const MoField variant_fields_8[] = {{"text", 1}, {NULL, 0}};
static const MoField variant_fields_9[] = {{"value", 25}, {NULL, 0}};
static const MoField variant_fields_10[] = {{"value", 5}, {NULL, 0}};
static const MoField variant_fields_11[] = {{NULL, 0}};
static const MoField variant_fields_12[] = {{"at", 4}, {NULL, 0}};
static const MoField variant_fields_13[] = {{NULL, 0}};
static const MoField variant_fields_14[] = {{NULL, 0}};
static const MoField variant_fields_15[] = {{NULL, 0}};
static const MoField variant_fields_16[] = {{NULL, 0}};
static const MoField variant_fields_17[] = {{NULL, 0}};
static const MoField variant_fields_18[] = {{NULL, 0}};
static const MoField variant_fields_19[] = {{NULL, 0}};
static const MoField variant_fields_20[] = {{NULL, 0}};
static const MoField variant_fields_21[] = {{NULL, 0}};
static const MoField variant_fields_22[] = {{NULL, 0}};
static const MoField variant_fields_23[] = {{NULL, 0}};
static const MoField variant_fields_24[] = {{NULL, 0}};
static const MoField variant_fields_25[] = {{NULL, 0}};
static const MoField variant_fields_26[] = {{"why", 1}, {NULL, 0}};
static const MoField variant_fields_27[] = {{NULL, 0}};
static const MoField variant_fields_28[] = {{NULL, 0}};
static const MoField variant_fields_29[] = {{NULL, 0}};
static const MoField variant_fields_30[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"taking", 1}, {"took_us", 4}, {"waited_us", 4}, {"longest", 1}, {NULL, 0}};
static const MoField variant_fields_31[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"scheduler", 4}, {NULL, 0}};
static const MoField variant_fields_32[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_33[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"restarts", 4}, {NULL, 0}};
static const MoField variant_fields_34[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"seed", 4}, {"clause", 1}, {"taking", 1}, {"snapshot", 1}, {NULL, 0}};
static const MoField variant_fields_35[] = {{"at", 2}, {"sender", 26}, {"sender_name", 1}, {"target", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_36[] = {{"at", 2}, {"pid", 27}, {"name", 1}, {"call", 1}, {NULL, 0}};
static const MoField variant_fields_37[] = {{"at", 2}, {"source", 1}, {"target", 4}, {"name", 1}, {"in_flight", 4}, {NULL, 0}};
static const MoField variant_fields_38[] = {{"at", 2}, {"source", 1}, {"target", 4}, {"name", 1}, {"in_flight", 4}, {NULL, 0}};
static const MoField variant_fields_39[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"taking", 1}, {NULL, 0}};
static const MoField variant_fields_40[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_41[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_42[] = {{"at", 2}, {"sender", 28}, {"sender_name", 1}, {"target", 4}, {"name", 1}, {"taking", 1}, {"why", 1}, {NULL, 0}};
static const MoField variant_fields_43[] = {{NULL, 0}};
static const MoField variant_fields_44[] = {{NULL, 0}};
static const MoField variant_fields_45[] = {{NULL, 0}};
static const MoField variant_fields_46[] = {{NULL, 0}};
static const MoField variant_fields_47[] = {{NULL, 0}};
static const MoField variant_fields_48[] = {{NULL, 0}};
static const MoField variant_fields_49[] = {{NULL, 0}};
static const MoField variant_fields_50[] = {{NULL, 0}};
static const MoField variant_fields_51[] = {{"text", 1}, {NULL, 0}};
static const MoField variant_fields_52[] = {{NULL, 0}};
static const MoField variant_fields_53[] = {{"code", 17}, {NULL, 0}};
static const MoField variant_fields_54[] = {{"signal", 17}, {NULL, 0}};
static const MoField variant_fields_55[] = {{NULL, 0}};
static const MoField variant_fields_56[] = {{NULL, 0}};
static const MoField variant_fields_57[] = {{NULL, 0}};
static const MoField variant_fields_58[] = {{"why", 1}, {NULL, 0}};
const MoDecl mo_decls[] = {
    {"ChargeId", 2, 0, decl_fields_0, 0, 0, 0, decl_refines_0, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Money", 2, 0, decl_fields_1, 0, 0, 0, decl_refines_1, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"CardNumber", 2, 0, decl_fields_2, 0, 0, 0, decl_refines_2, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"FsError", 8, 0, decl_fields_3, 0, 3, 0, decl_refines_3, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"AskError", 8, 0, decl_fields_4, 3, 2, 0, decl_refines_4, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"LedgerError", 8, 0, decl_fields_5, 5, 1, 0, decl_refines_5, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Json", 8, 0, decl_fields_6, 6, 6, 0, decl_refines_6, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"JsonError", 8, 0, decl_fields_7, 12, 1, 0, decl_refines_7, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"NetError", 8, 0, decl_fields_8, 13, 5, 0, decl_refines_8, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"HttpError", 8, 0, decl_fields_9, 18, 7, 0, decl_refines_9, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RuntimeError", 8, 0, decl_fields_10, 25, 5, 0, decl_refines_10, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Event", 8, 0, decl_fields_11, 30, 13, 0, decl_refines_11, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"EntryKind", 8, 0, decl_fields_12, 43, 3, 0, decl_refines_12, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"TlsError", 8, 0, decl_fields_13, 46, 5, 0, decl_refines_13, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Arg", 8, 0, decl_fields_14, 51, 2, 0, decl_refines_14, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Exit", 8, 0, decl_fields_15, 53, 2, 0, decl_refines_15, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ExecError", 8, 0, decl_fields_16, 55, 4, 0, decl_refines_16, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Charge", 0, 4, decl_fields_17, 0, 0, 0, decl_refines_17, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundRequest", 0, 2, decl_fields_18, 0, 0, 0, decl_refines_18, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundCompleted", 0, 1, decl_fields_19, 0, 0, 0, decl_refines_19, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundFailed", 0, 2, decl_fields_20, 0, 0, 0, decl_refines_20, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Request", 0, 5, decl_fields_21, 0, 0, 0, decl_refines_21, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Response", 0, 3, decl_fields_22, 0, 0, 0, decl_refines_22, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ProcessInfo", 0, 10, decl_fields_23, 0, 0, 0, decl_refines_23, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"SourceInfo", 0, 5, decl_fields_24, 0, 0, 0, decl_refines_24, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Entry", 0, 4, decl_fields_25, 0, 0, 0, decl_refines_25, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Done", 0, 5, decl_fields_26, 0, 0, 0, decl_refines_26, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"MemoryInfo", 0, 6, decl_fields_27, 0, 0, 0, decl_refines_27, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {NULL, 0, 0, NULL, 0, 0, 0, NULL, false, 0, 0, 0}
};
const MoVariantDef mo_variants[] = {
    {4, 1, variant_fields_0},
    {5, 0, variant_fields_1},
    {21, 0, variant_fields_2},
    {5, 0, variant_fields_3},
    {13, 0, variant_fields_4},
    {5, 0, variant_fields_5},
    {7, 1, variant_fields_6},
    {8, 1, variant_fields_7},
    {9, 1, variant_fields_8},
    {10, 1, variant_fields_9},
    {11, 1, variant_fields_10},
    {12, 0, variant_fields_11},
    {6, 1, variant_fields_12},
    {5, 0, variant_fields_13},
    {14, 0, variant_fields_14},
    {15, 0, variant_fields_15},
    {16, 0, variant_fields_16},
    {17, 0, variant_fields_17},
    {5, 0, variant_fields_18},
    {14, 0, variant_fields_19},
    {15, 0, variant_fields_20},
    {17, 0, variant_fields_21},
    {18, 0, variant_fields_22},
    {19, 0, variant_fields_23},
    {20, 0, variant_fields_24},
    {26, 0, variant_fields_25},
    {27, 1, variant_fields_26},
    {28, 0, variant_fields_27},
    {29, 0, variant_fields_28},
    {5, 0, variant_fields_29},
    {30, 7, variant_fields_30},
    {31, 4, variant_fields_31},
    {32, 3, variant_fields_32},
    {33, 4, variant_fields_33},
    {34, 7, variant_fields_34},
    {35, 5, variant_fields_35},
    {36, 4, variant_fields_36},
    {37, 5, variant_fields_37},
    {38, 5, variant_fields_38},
    {39, 4, variant_fields_39},
    {40, 3, variant_fields_40},
    {41, 3, variant_fields_41},
    {44, 7, variant_fields_42},
    {42, 0, variant_fields_43},
    {43, 0, variant_fields_44},
    {48, 0, variant_fields_45},
    {45, 0, variant_fields_46},
    {46, 0, variant_fields_47},
    {5, 0, variant_fields_48},
    {15, 0, variant_fields_49},
    {47, 0, variant_fields_50},
    {49, 1, variant_fields_51},
    {50, 0, variant_fields_52},
    {51, 1, variant_fields_53},
    {52, 1, variant_fields_54},
    {4, 0, variant_fields_55},
    {14, 0, variant_fields_56},
    {5, 0, variant_fields_57},
    {53, 1, variant_fields_58},
    {0, 0, NULL}
};
const uint32_t mo_nvariants = 59;
const MoType mo_types[] = {
    {17, "ChargeId", UINT32_MAX, false, 0, 1, NULL},
    {4, "String", UINT32_MAX, false, 0, 0, NULL},
    {5, "Time", UINT32_MAX, false, 0, 0, NULL},
    {17, "Money", UINT32_MAX, false, 1, 4, NULL},
    {7, "UInt64", UINT32_MAX, false, 7, 0, NULL},
    {3, "Bool", UINT32_MAX, false, 0, 0, NULL},
    {24, "a type not yet known", UINT32_MAX, false, 0, 0, NULL},
    {16, "RefundRequest", UINT32_MAX, false, 18, 0, NULL},
    {24, "a type not yet known", UINT32_MAX, false, 0, 0, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {7, "UInt16", UINT32_MAX, false, 5, 0, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {10, "Option(String)", UINT32_MAX, false, 1, 0, NULL},
    {16, "EntryKind", UINT32_MAX, false, 12, 0, NULL},
    {16, "Exit", UINT32_MAX, false, 15, 0, NULL},
    {9, "List(UInt8)", UINT32_MAX, false, 17, 0, NULL},
    {7, "UInt8", UINT32_MAX, false, 4, 0, NULL},
    {9, "List(UInt8)", UINT32_MAX, false, 17, 0, NULL},
    {6, "Duration", UINT32_MAX, false, 0, 0, NULL},
    {9, "List(ProcessInfo)", UINT32_MAX, false, 21, 0, NULL},
    {16, "ProcessInfo", UINT32_MAX, false, 23, 0, NULL},
    {12, "Map(String, Json)", UINT32_MAX, false, 1, 23, NULL},
    {16, "Json", UINT32_MAX, false, 6, 0, NULL},
    {9, "List(Json)", UINT32_MAX, false, 23, 0, NULL},
    {8, "Float64", UINT32_MAX, false, 64, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {0, NULL, UINT32_MAX, false, 0, 0, NULL}
};
const uint32_t mo_nrecorded = 0;
const char *const mo_names[] = {"Some", "None", "Ok", "Error", "Missing", "Timeout", "Syntax", "Object", "Array", "String", "Number", "Bool", "Null", "Down", "Refused", "Closed", "LineTooLong", "Busy", "Malformed", "TooLarge", "Unsupported", "NotText", "Accepted", "Line", "Chunk", "Idle", "NoProcess", "Unparsed", "ReadOnly", "MailboxFull", "Updated", "Started", "Ended", "Restarted", "Crashed", "Overflowed", "TimedOut", "SourcePaused", "SourceResumed", "Sent", "Paused", "Resumed", "File", "Folder", "Dropped", "BadPem", "Handshake", "Untrusted", "Link", "Fixed", "Hole", "Exited", "Signalled", "Failed", NULL};
const uint32_t mo_nnames = 54;
const MoClause mo_clauses[] = {
    {5, false, "assert query_bytes() == 4_096 and terms() == 64 and depth() == 24", "the documented limits are the production constants", "/home/user/workspace/repo/examples/programs/moscope/limits.mo:79:3"},
    {5, false, "assert entries() == 50_000 and files() == 5_000", "the documented limits are the production constants", "/home/user/workspace/repo/examples/programs/moscope/limits.mo:80:3"},
    {5, false, "assert file_bytes() == 67_108_864 and total_bytes() == 1_073_741_824", "the documented limits are the production constants", "/home/user/workspace/repo/examples/programs/moscope/limits.mo:81:3"},
    {5, false, "assert line_bytes() == 1_048_576 and file_records() == 200_000 and records() == 1_000_000", "the documented limits are the production constants", "/home/user/workspace/repo/examples/programs/moscope/limits.mo:82:3"},
    {5, false, "assert messages() == 100_000 and blocks() == 500_000 and results() == 10_000", "the documented limits are the production constants", "/home/user/workspace/repo/examples/programs/moscope/limits.mo:83:3"},
    {5, false, "assert diagnostics() == 10_000 and excerpt() == 240 and output_bytes() == 8_388_608", "the documented limits are the production constants", "/home/user/workspace/repo/examples/programs/moscope/limits.mo:84:3"},
    {5, false, "assert call_time() == 10.seconds and process_time() == 60.seconds", "the documented limits are the production constants", "/home/user/workspace/repo/examples/programs/moscope/limits.mo:85:3"},
    {0, false, NULL, NULL, NULL}
};
const MoTest mo_tests[] = {
    {MO_TEST, "the documented limits are the production constants", test0},
    {0, NULL, NULL}
};
const uint32_t mo_ntests = 1;
const MoNever mo_nevers[] = {
    {NULL, 0, 0, NULL}
};
const uint32_t mo_nnevers = 0;
const MoProcess mo_processes[] = {
    {NULL, 0, 0, NULL, NULL, 0, NULL, false}
};
const uint32_t mo_nprocesses = 0;
const MoSupervisor mo_supervisors[] = {
    {NULL, 0, NULL}
};
const uint32_t mo_nsupervisors = 0;
const uint32_t mo_charge_decl = 17;
const uint32_t mo_request_decl = 21;
const uint32_t mo_response_decl = 22;
const uint32_t mo_process_info_decl = 23;
const uint32_t mo_source_info_decl = 24;
const uint32_t mo_memory_info_decl = 27;
const uint32_t mo_entry_decl = 25;
const uint32_t mo_done_decl = 26;
const bool mo_surface_built = false;
const uint32_t mo_surface_process = UINT32_MAX;
const bool mo_contracts_built = true;

MO_U static MoValue f0(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(4096));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f1(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("terms");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(64));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f2(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("depth");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(24));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f3(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("entries");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(50000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f4(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("files");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(5000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f5(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(67108864));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f6(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("total_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1073741824));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f7(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("line_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1048576));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f8(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_records");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(200000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f9(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("records");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1000000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f10(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("messages");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(100000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f11(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("blocks");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(500000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f12(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("results");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(10000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f13(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("diagnostics");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(10000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f14(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("excerpt");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(240));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f15(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("output_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(8388608));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f16(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("call_time");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Int_seconds((const MoValue[]){mo_i64(INT64_C(10))}, 3);
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f17(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("process_time");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Int_seconds((const MoValue[]){mo_i64(INT64_C(60))}, 3);
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue test0(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("the documented limits are the production constants");
    MoValue t0 MO_U = f0();
    MoValue t1 MO_U = mo_bool(t0.as.u == mo_i64(INT64_C(4096)).as.u);
    MoValue t2 MO_U = mo_bool(false);
    if (t1.as.b) {
        MoValue t3 MO_U = f1();
        MoValue t4 MO_U = mo_bool(t3.as.u == mo_i64(INT64_C(64)).as.u);
        t2 = t4;
    }
    MoValue t5 MO_U = mo_bool(false);
    if (t2.as.b) {
        MoValue t6 MO_U = f2();
        MoValue t7 MO_U = mo_bool(t6.as.u == mo_i64(INT64_C(24)).as.u);
        t5 = t7;
    }
    if (!t5.as.b) mo_crash(0);
    MoValue t8 MO_U = f3();
    MoValue t9 MO_U = mo_bool(t8.as.u == mo_i64(INT64_C(50000)).as.u);
    MoValue t10 MO_U = mo_bool(false);
    if (t9.as.b) {
        MoValue t11 MO_U = f4();
        MoValue t12 MO_U = mo_bool(t11.as.u == mo_i64(INT64_C(5000)).as.u);
        t10 = t12;
    }
    if (!t10.as.b) mo_crash(1);
    MoValue t13 MO_U = f5();
    MoValue t14 MO_U = mo_bool(t13.as.u == mo_i64(INT64_C(67108864)).as.u);
    MoValue t15 MO_U = mo_bool(false);
    if (t14.as.b) {
        MoValue t16 MO_U = f6();
        MoValue t17 MO_U = mo_bool(t16.as.u == mo_i64(INT64_C(1073741824)).as.u);
        t15 = t17;
    }
    if (!t15.as.b) mo_crash(2);
    MoValue t18 MO_U = f7();
    MoValue t19 MO_U = mo_bool(t18.as.u == mo_i64(INT64_C(1048576)).as.u);
    MoValue t20 MO_U = mo_bool(false);
    if (t19.as.b) {
        MoValue t21 MO_U = f8();
        MoValue t22 MO_U = mo_bool(t21.as.u == mo_i64(INT64_C(200000)).as.u);
        t20 = t22;
    }
    MoValue t23 MO_U = mo_bool(false);
    if (t20.as.b) {
        MoValue t24 MO_U = f9();
        MoValue t25 MO_U = mo_bool(t24.as.u == mo_i64(INT64_C(1000000)).as.u);
        t23 = t25;
    }
    if (!t23.as.b) mo_crash(3);
    MoValue t26 MO_U = f10();
    MoValue t27 MO_U = mo_bool(t26.as.u == mo_i64(INT64_C(100000)).as.u);
    MoValue t28 MO_U = mo_bool(false);
    if (t27.as.b) {
        MoValue t29 MO_U = f11();
        MoValue t30 MO_U = mo_bool(t29.as.u == mo_i64(INT64_C(500000)).as.u);
        t28 = t30;
    }
    MoValue t31 MO_U = mo_bool(false);
    if (t28.as.b) {
        MoValue t32 MO_U = f12();
        MoValue t33 MO_U = mo_bool(t32.as.u == mo_i64(INT64_C(10000)).as.u);
        t31 = t33;
    }
    if (!t31.as.b) mo_crash(4);
    MoValue t34 MO_U = f13();
    MoValue t35 MO_U = mo_bool(t34.as.u == mo_i64(INT64_C(10000)).as.u);
    MoValue t36 MO_U = mo_bool(false);
    if (t35.as.b) {
        MoValue t37 MO_U = f14();
        MoValue t38 MO_U = mo_bool(t37.as.u == mo_i64(INT64_C(240)).as.u);
        t36 = t38;
    }
    MoValue t39 MO_U = mo_bool(false);
    if (t36.as.b) {
        MoValue t40 MO_U = f15();
        MoValue t41 MO_U = mo_bool(t40.as.u == mo_i64(INT64_C(8388608)).as.u);
        t39 = t41;
    }
    if (!t39.as.b) mo_crash(5);
    MoValue t42 MO_U = f16();
    MoValue t43 MO_U = mo_r_Int_seconds((const MoValue[]){mo_i64(INT64_C(10))}, 3);
    MoValue t44 MO_U = mo_bool(mo_compare(MO_EQ, t42, t43));
    MoValue t45 MO_U = mo_bool(false);
    if (t44.as.b) {
        MoValue t46 MO_U = f17();
        MoValue t47 MO_U = mo_r_Int_seconds((const MoValue[]){mo_i64(INT64_C(60))}, 3);
        MoValue t48 MO_U = mo_bool(mo_compare(MO_EQ, t46, t47));
        t45 = t48;
    }
    if (!t45.as.b) mo_crash(6);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}

int main(void) {
    return mo_run_tests();
}
