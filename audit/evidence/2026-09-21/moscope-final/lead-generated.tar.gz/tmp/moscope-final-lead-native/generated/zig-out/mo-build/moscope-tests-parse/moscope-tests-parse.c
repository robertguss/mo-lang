/* Written by mo build (toolchain/src/emit_c.zig); links toolchain/runtime/mo_rt.c. */
#include "mo_rt.h"

MO_U static MoValue f0(void);
MO_U static MoValue f1(void);
MO_U static MoValue f2(void);
MO_U static MoValue f3(void);
MO_U static MoValue f4(void);
MO_U static MoValue f5(void);
MO_U static MoValue f6(void);
MO_U static MoValue f7(void);
MO_U static MoValue f8(void);
MO_U static MoValue f9(void);
MO_U static MoValue f10(void);
MO_U static MoValue f11(void);
MO_U static MoValue f12(void);
MO_U static MoValue f13(void);
MO_U static MoValue f14(void);
MO_U static MoValue f15(void);
MO_U static MoValue f16(void);
MO_U static MoValue f17(void);
MO_U static MoValue f18(void);
MO_U static MoValue f19(void);
MO_U static MoValue f20(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f21(MoValue L0, MoValue L1);
MO_U static MoValue f22(MoValue L0, MoValue L1);
MO_U static MoValue f23(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f24(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4);
MO_U static MoValue f25(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f26(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f27(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f28(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue a0(const MoValue *cap, const MoValue *args);
MO_U static MoValue f29(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f30(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4);
MO_U static MoValue f31(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5);
MO_U static MoValue f32(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5);
MO_U static MoValue f33(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5);
MO_U static MoValue f34(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5);
MO_U static MoValue f35(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f36(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue f37(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4);
MO_U static MoValue f38(MoValue L0, MoValue L1);
MO_U static MoValue f39(MoValue L0);
MO_U static MoValue f40(MoValue L0);
MO_U static MoValue f41(MoValue L0);
MO_U static MoValue f42(MoValue L0, MoValue L1);
MO_U static MoValue a1(const MoValue *cap, const MoValue *args);
MO_U static MoValue a2(const MoValue *cap, const MoValue *args);
MO_U static MoValue f43(MoValue L0, MoValue L1);
MO_U static MoValue f44(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue test0(void);
MO_U static MoValue test1(void);
MO_U static MoValue test2(void);
MO_U static MoValue a3(const MoValue *cap, const MoValue *args);
MO_U static MoValue a4(const MoValue *cap, const MoValue *args);
MO_U static MoValue test3(void);
MO_U static MoValue test4(void);

static const MoField decl_fields_0[] = {{NULL, 0}};
static const MoRefineFn decl_refines_0[] = {NULL};
static const MoField decl_fields_1[] = {{NULL, 0}};
static const MoRefineFn decl_refines_1[] = {NULL};
static const MoField decl_fields_2[] = {{NULL, 0}};
static const MoRefineFn decl_refines_2[] = {NULL};
static const MoField decl_fields_3[] = {{NULL, 0}};
static const MoRefineFn decl_refines_3[] = {NULL};
static const MoField decl_fields_4[] = {{NULL, 0}};
static const MoRefineFn decl_refines_4[] = {NULL};
static const MoField decl_fields_5[] = {{NULL, 0}};
static const MoRefineFn decl_refines_5[] = {NULL};
static const MoField decl_fields_6[] = {{NULL, 0}};
static const MoRefineFn decl_refines_6[] = {NULL};
static const MoField decl_fields_7[] = {{NULL, 0}};
static const MoRefineFn decl_refines_7[] = {NULL};
static const MoField decl_fields_8[] = {{NULL, 0}};
static const MoRefineFn decl_refines_8[] = {NULL};
static const MoField decl_fields_9[] = {{NULL, 0}};
static const MoRefineFn decl_refines_9[] = {NULL};
static const MoField decl_fields_10[] = {{NULL, 0}};
static const MoRefineFn decl_refines_10[] = {NULL};
static const MoField decl_fields_11[] = {{NULL, 0}};
static const MoRefineFn decl_refines_11[] = {NULL};
static const MoField decl_fields_12[] = {{NULL, 0}};
static const MoRefineFn decl_refines_12[] = {NULL};
static const MoField decl_fields_13[] = {{NULL, 0}};
static const MoRefineFn decl_refines_13[] = {NULL};
static const MoField decl_fields_14[] = {{NULL, 0}};
static const MoRefineFn decl_refines_14[] = {NULL};
static const MoField decl_fields_15[] = {{NULL, 0}};
static const MoRefineFn decl_refines_15[] = {NULL};
static const MoField decl_fields_16[] = {{NULL, 0}};
static const MoRefineFn decl_refines_16[] = {NULL};
static const MoField decl_fields_17[] = {{"id", 3}, {"captured_at", 4}, {"captured_amount", 5}, {"refunded", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_17[] = {NULL};
static const MoField decl_fields_18[] = {{"id", 3}, {"amount", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_18[] = {NULL};
static const MoField decl_fields_19[] = {{"refund", 8}, {NULL, 0}};
static const MoRefineFn decl_refines_19[] = {NULL};
static const MoField decl_fields_20[] = {{"request", 9}, {"reason", 10}, {NULL, 0}};
static const MoRefineFn decl_refines_20[] = {NULL};
static const MoField decl_fields_21[] = {{"method", 1}, {"path", 1}, {"query", 11}, {"headers", 12}, {"body", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_21[] = {NULL};
static const MoField decl_fields_22[] = {{"status", 13}, {"headers", 14}, {"body", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_22[] = {NULL};
static const MoField decl_fields_23[] = {{"id", 6}, {"name", 1}, {"alive", 7}, {"mailbox", 6}, {"bound", 6}, {"waiting_in", 15}, {"restarts", 6}, {"region_bytes", 6}, {"paused", 7}, {"scheduler", 6}, {NULL, 0}};
static const MoRefineFn decl_refines_23[] = {NULL};
static const MoField decl_fields_24[] = {{"kind", 1}, {"target", 6}, {"name", 1}, {"in_flight", 6}, {"paused", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_24[] = {NULL};
static const MoField decl_fields_25[] = {{"name", 1}, {"kind", 16}, {"links", 6}, {"setuid", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_25[] = {NULL};
static const MoField decl_fields_26[] = {{"exit", 17}, {"stdout", 18}, {"stderr", 20}, {"truncated", 7}, {"took", 21}, {NULL, 0}};
static const MoRefineFn decl_refines_26[] = {NULL};
static const MoField decl_fields_27[] = {{"resident_bytes", 6}, {"region_bytes", 6}, {"region_resident_bytes", 6}, {"packed_bytes", 6}, {"event_bytes", 6}, {"largest", 22}, {NULL, 0}};
static const MoRefineFn decl_refines_27[] = {NULL};
static const MoField decl_fields_28[] = {{NULL, 0}};
static const MoRefineFn decl_refines_28[] = {NULL};
static const MoField decl_fields_29[] = {{"query", 1}, {"dir", 1}, {"mode", 24}, {"include_tools", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_29[] = {NULL};
static const MoField decl_fields_30[] = {{NULL, 0}};
static const MoRefineFn decl_refines_30[] = {NULL};
static const MoField decl_fields_31[] = {{"kind", 25}, {"label", 1}, {"text", 1}, {"path", 1}, {"line", 6}, {"local_index", 6}, {"api_index", 26}, {NULL, 0}};
static const MoRefineFn decl_refines_31[] = {NULL};
static const MoField decl_fields_32[] = {{"key", 1}, {"session_key", 1}, {"session_label", 1}, {"role", 1}, {"id", 1}, {"path", 1}, {"first_line", 6}, {"conversation_at", 27}, {"blocks", 28}, {NULL, 0}};
static const MoRefineFn decl_refines_32[] = {NULL};
static const MoField decl_fields_33[] = {{"payload", 2}, {"line", 6}, {NULL, 0}};
static const MoRefineFn decl_refines_33[] = {NULL};
static const MoField decl_fields_34[] = {{"path", 1}, {"line", 6}, {"detail", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_34[] = {NULL};
static const MoField decl_fields_35[] = {{"messages", 30}, {"issues", 32}, {"unknown_kinds", 34}, {"skipped_links", 6}, {"files_read", 6}, {"admitted_bytes", 6}, {"records", 6}, {"retained_blocks", 6}, {"incomplete", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_35[] = {NULL};
static const MoField decl_fields_36[] = {{"files", 35}, {"issues", 36}, {"entries", 6}, {"skipped_links", 6}, {"incomplete", 7}, {"stopped", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_36[] = {NULL};
static const MoField decl_fields_37[] = {{"entry", 31}, {"blocks", 37}, {NULL, 0}};
static const MoRefineFn decl_refines_37[] = {NULL};
static const MoField decl_fields_38[] = {{"key", 1}, {"label", 1}, {"latest", 38}, {"hits", 39}, {NULL, 0}};
static const MoRefineFn decl_refines_38[] = {NULL};
static const MoField decl_fields_39[] = {{"text", 1}, {"diagnostics", 1}, {"matches", 6}, {"incomplete", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_39[] = {NULL};
static const MoField decl_fields_40[] = {{"scan", 41}, {"seen", 42}, {"path", 1}, {"lines", 6}, {"file_records", 6}, {"bytes", 6}, {"admitted", 6}, {"replacement_seen", 7}, {"stopped", 7}, {NULL, 0}};
static const MoRefineFn decl_refines_40[] = {NULL};
static const MoField decl_fields_41[] = {{"scan", 41}, {"blocks", 44}, {NULL, 0}};
static const MoRefineFn decl_refines_41[] = {NULL};
static const MoField decl_fields_42[] = {{"path", 1}, {"line", 6}, {"kind", 1}, {"session", 1}, {"at", 45}, {NULL, 0}};
static const MoRefineFn decl_refines_42[] = {NULL};
static const MoField decl_fields_43[] = {{"kind", 1}, {"value", 1}, {"label", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_43[] = {NULL};
static const MoField decl_fields_44[] = {{"path", 1}, {"line", 6}, {"local", 6}, {"api", 46}, {"id", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_44[] = {NULL};
static const MoField variant_fields_0[] = {{"path", 1}, {NULL, 0}};
static const MoField variant_fields_1[] = {{NULL, 0}};
static const MoField variant_fields_2[] = {{NULL, 0}};
static const MoField variant_fields_3[] = {{NULL, 0}};
static const MoField variant_fields_4[] = {{NULL, 0}};
static const MoField variant_fields_5[] = {{NULL, 0}};
static const MoField variant_fields_6[] = {{"fields", 47}, {NULL, 0}};
static const MoField variant_fields_7[] = {{"items", 48}, {NULL, 0}};
static const MoField variant_fields_8[] = {{"text", 1}, {NULL, 0}};
static const MoField variant_fields_9[] = {{"value", 49}, {NULL, 0}};
static const MoField variant_fields_10[] = {{"value", 7}, {NULL, 0}};
static const MoField variant_fields_11[] = {{NULL, 0}};
static const MoField variant_fields_12[] = {{"at", 6}, {NULL, 0}};
static const MoField variant_fields_13[] = {{NULL, 0}};
static const MoField variant_fields_14[] = {{NULL, 0}};
static const MoField variant_fields_15[] = {{NULL, 0}};
static const MoField variant_fields_16[] = {{NULL, 0}};
static const MoField variant_fields_17[] = {{NULL, 0}};
static const MoField variant_fields_18[] = {{NULL, 0}};
static const MoField variant_fields_19[] = {{NULL, 0}};
static const MoField variant_fields_20[] = {{NULL, 0}};
static const MoField variant_fields_21[] = {{NULL, 0}};
static const MoField variant_fields_22[] = {{NULL, 0}};
static const MoField variant_fields_23[] = {{NULL, 0}};
static const MoField variant_fields_24[] = {{NULL, 0}};
static const MoField variant_fields_25[] = {{NULL, 0}};
static const MoField variant_fields_26[] = {{"why", 1}, {NULL, 0}};
static const MoField variant_fields_27[] = {{NULL, 0}};
static const MoField variant_fields_28[] = {{NULL, 0}};
static const MoField variant_fields_29[] = {{NULL, 0}};
static const MoField variant_fields_30[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {"taking", 1}, {"took_us", 6}, {"waited_us", 6}, {"longest", 1}, {NULL, 0}};
static const MoField variant_fields_31[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {"scheduler", 6}, {NULL, 0}};
static const MoField variant_fields_32[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_33[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {"restarts", 6}, {NULL, 0}};
static const MoField variant_fields_34[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {"seed", 6}, {"clause", 1}, {"taking", 1}, {"snapshot", 1}, {NULL, 0}};
static const MoField variant_fields_35[] = {{"at", 4}, {"sender", 50}, {"sender_name", 1}, {"target", 6}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_36[] = {{"at", 4}, {"pid", 51}, {"name", 1}, {"call", 1}, {NULL, 0}};
static const MoField variant_fields_37[] = {{"at", 4}, {"source", 1}, {"target", 6}, {"name", 1}, {"in_flight", 6}, {NULL, 0}};
static const MoField variant_fields_38[] = {{"at", 4}, {"source", 1}, {"target", 6}, {"name", 1}, {"in_flight", 6}, {NULL, 0}};
static const MoField variant_fields_39[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {"taking", 1}, {NULL, 0}};
static const MoField variant_fields_40[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_41[] = {{"at", 4}, {"pid", 6}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_42[] = {{"at", 4}, {"sender", 52}, {"sender_name", 1}, {"target", 6}, {"name", 1}, {"taking", 1}, {"why", 1}, {NULL, 0}};
static const MoField variant_fields_43[] = {{NULL, 0}};
static const MoField variant_fields_44[] = {{NULL, 0}};
static const MoField variant_fields_45[] = {{NULL, 0}};
static const MoField variant_fields_46[] = {{NULL, 0}};
static const MoField variant_fields_47[] = {{NULL, 0}};
static const MoField variant_fields_48[] = {{NULL, 0}};
static const MoField variant_fields_49[] = {{NULL, 0}};
static const MoField variant_fields_50[] = {{NULL, 0}};
static const MoField variant_fields_51[] = {{"text", 1}, {NULL, 0}};
static const MoField variant_fields_52[] = {{NULL, 0}};
static const MoField variant_fields_53[] = {{"code", 19}, {NULL, 0}};
static const MoField variant_fields_54[] = {{"signal", 19}, {NULL, 0}};
static const MoField variant_fields_55[] = {{NULL, 0}};
static const MoField variant_fields_56[] = {{NULL, 0}};
static const MoField variant_fields_57[] = {{NULL, 0}};
static const MoField variant_fields_58[] = {{"why", 1}, {NULL, 0}};
static const MoField variant_fields_59[] = {{NULL, 0}};
static const MoField variant_fields_60[] = {{NULL, 0}};
static const MoField variant_fields_61[] = {{NULL, 0}};
static const MoField variant_fields_62[] = {{NULL, 0}};
const MoDecl mo_decls[] = {
    {"ChargeId", 2, 0, decl_fields_0, 0, 0, 0, decl_refines_0, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Money", 2, 0, decl_fields_1, 0, 0, 0, decl_refines_1, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"CardNumber", 2, 0, decl_fields_2, 0, 0, 0, decl_refines_2, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"FsError", 8, 0, decl_fields_3, 0, 3, 0, decl_refines_3, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"AskError", 8, 0, decl_fields_4, 3, 2, 0, decl_refines_4, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"LedgerError", 8, 0, decl_fields_5, 5, 1, 0, decl_refines_5, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Json", 8, 0, decl_fields_6, 6, 6, 0, decl_refines_6, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"JsonError", 8, 0, decl_fields_7, 12, 1, 0, decl_refines_7, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"NetError", 8, 0, decl_fields_8, 13, 5, 0, decl_refines_8, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"HttpError", 8, 0, decl_fields_9, 18, 7, 0, decl_refines_9, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RuntimeError", 8, 0, decl_fields_10, 25, 5, 0, decl_refines_10, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Event", 8, 0, decl_fields_11, 30, 13, 0, decl_refines_11, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"EntryKind", 8, 0, decl_fields_12, 43, 3, 0, decl_refines_12, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"TlsError", 8, 0, decl_fields_13, 46, 5, 0, decl_refines_13, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Arg", 8, 0, decl_fields_14, 51, 2, 0, decl_refines_14, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Exit", 8, 0, decl_fields_15, 53, 2, 0, decl_refines_15, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ExecError", 8, 0, decl_fields_16, 55, 4, 0, decl_refines_16, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Charge", 0, 4, decl_fields_17, 0, 0, 0, decl_refines_17, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundRequest", 0, 2, decl_fields_18, 0, 0, 0, decl_refines_18, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundCompleted", 0, 1, decl_fields_19, 0, 0, 0, decl_refines_19, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundFailed", 0, 2, decl_fields_20, 0, 0, 0, decl_refines_20, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Request", 0, 5, decl_fields_21, 0, 0, 0, decl_refines_21, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Response", 0, 3, decl_fields_22, 0, 0, 0, decl_refines_22, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ProcessInfo", 0, 10, decl_fields_23, 0, 0, 0, decl_refines_23, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"SourceInfo", 0, 5, decl_fields_24, 0, 0, 0, decl_refines_24, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Entry", 0, 4, decl_fields_25, 0, 0, 0, decl_refines_25, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Done", 0, 5, decl_fields_26, 0, 0, 0, decl_refines_26, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"MemoryInfo", 0, 6, decl_fields_27, 0, 0, 0, decl_refines_27, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Mode", 1, 0, decl_fields_28, 59, 2, 0, decl_refines_28, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Options", 0, 4, decl_fields_29, 0, 0, 0, decl_refines_29, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"BlockKind", 1, 0, decl_fields_30, 61, 2, 0, decl_refines_30, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Block", 0, 7, decl_fields_31, 0, 0, 0, decl_refines_31, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Message", 0, 9, decl_fields_32, 0, 0, 0, decl_refines_32, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Seen", 0, 2, decl_fields_33, 0, 0, 0, decl_refines_33, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Issue", 0, 3, decl_fields_34, 0, 0, 0, decl_refines_34, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Scan", 0, 9, decl_fields_35, 0, 0, 0, decl_refines_35, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Discovery", 0, 6, decl_fields_36, 0, 0, 0, decl_refines_36, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Hit", 0, 2, decl_fields_37, 0, 0, 0, decl_refines_37, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Session", 0, 4, decl_fields_38, 0, 0, 0, decl_refines_38, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Report", 0, 4, decl_fields_39, 0, 0, 0, decl_refines_39, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"FileFold", 0, 9, decl_fields_40, 0, 0, 0, decl_refines_40, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ParsedBlocks", 0, 2, decl_fields_41, 0, 0, 0, decl_refines_41, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ConversationInput", 0, 5, decl_fields_42, 0, 0, 0, decl_refines_42, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Identity", 0, 3, decl_fields_43, 0, 0, 0, decl_refines_43, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ResultPlace", 0, 5, decl_fields_44, 0, 0, 0, decl_refines_44, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {NULL, 0, 0, NULL, 0, 0, 0, NULL, false, 0, 0, 0}
};
const MoVariantDef mo_variants[] = {
    {4, 1, variant_fields_0},
    {5, 0, variant_fields_1},
    {21, 0, variant_fields_2},
    {5, 0, variant_fields_3},
    {13, 0, variant_fields_4},
    {5, 0, variant_fields_5},
    {7, 1, variant_fields_6},
    {8, 1, variant_fields_7},
    {9, 1, variant_fields_8},
    {10, 1, variant_fields_9},
    {11, 1, variant_fields_10},
    {12, 0, variant_fields_11},
    {6, 1, variant_fields_12},
    {5, 0, variant_fields_13},
    {14, 0, variant_fields_14},
    {15, 0, variant_fields_15},
    {16, 0, variant_fields_16},
    {17, 0, variant_fields_17},
    {5, 0, variant_fields_18},
    {14, 0, variant_fields_19},
    {15, 0, variant_fields_20},
    {17, 0, variant_fields_21},
    {18, 0, variant_fields_22},
    {19, 0, variant_fields_23},
    {20, 0, variant_fields_24},
    {26, 0, variant_fields_25},
    {27, 1, variant_fields_26},
    {28, 0, variant_fields_27},
    {29, 0, variant_fields_28},
    {5, 0, variant_fields_29},
    {30, 7, variant_fields_30},
    {31, 4, variant_fields_31},
    {32, 3, variant_fields_32},
    {33, 4, variant_fields_33},
    {34, 7, variant_fields_34},
    {35, 5, variant_fields_35},
    {36, 4, variant_fields_36},
    {37, 5, variant_fields_37},
    {38, 5, variant_fields_38},
    {39, 4, variant_fields_39},
    {40, 3, variant_fields_40},
    {41, 3, variant_fields_41},
    {44, 7, variant_fields_42},
    {42, 0, variant_fields_43},
    {43, 0, variant_fields_44},
    {48, 0, variant_fields_45},
    {45, 0, variant_fields_46},
    {46, 0, variant_fields_47},
    {5, 0, variant_fields_48},
    {15, 0, variant_fields_49},
    {47, 0, variant_fields_50},
    {49, 1, variant_fields_51},
    {50, 0, variant_fields_52},
    {51, 1, variant_fields_53},
    {52, 1, variant_fields_54},
    {4, 0, variant_fields_55},
    {14, 0, variant_fields_56},
    {5, 0, variant_fields_57},
    {53, 1, variant_fields_58},
    {56, 0, variant_fields_59},
    {57, 0, variant_fields_60},
    {54, 0, variant_fields_61},
    {55, 0, variant_fields_62},
    {0, 0, NULL}
};
const uint32_t mo_nvariants = 63;
static const uint32_t type_items_0[] = {1, 1, 1, 1, 1, 0};
const MoType mo_types[] = {
    {14, "(String, String, String, String, String)", UINT32_MAX, false, 0, 5, type_items_0},
    {4, "String", UINT32_MAX, false, 0, 0, NULL},
    {16, "Json", UINT32_MAX, false, 6, 0, NULL},
    {17, "ChargeId", UINT32_MAX, false, 0, 1, NULL},
    {5, "Time", UINT32_MAX, false, 0, 0, NULL},
    {17, "Money", UINT32_MAX, false, 1, 6, NULL},
    {7, "UInt64", UINT32_MAX, false, 7, 0, NULL},
    {3, "Bool", UINT32_MAX, false, 0, 0, NULL},
    {24, "a type not yet known", UINT32_MAX, false, 0, 0, NULL},
    {16, "RefundRequest", UINT32_MAX, false, 18, 0, NULL},
    {24, "a type not yet known", UINT32_MAX, false, 0, 0, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {7, "UInt16", UINT32_MAX, false, 5, 0, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {10, "Option(String)", UINT32_MAX, false, 1, 0, NULL},
    {16, "EntryKind", UINT32_MAX, false, 12, 0, NULL},
    {16, "Exit", UINT32_MAX, false, 15, 0, NULL},
    {9, "List(UInt8)", UINT32_MAX, false, 19, 0, NULL},
    {7, "UInt8", UINT32_MAX, false, 4, 0, NULL},
    {9, "List(UInt8)", UINT32_MAX, false, 19, 0, NULL},
    {6, "Duration", UINT32_MAX, false, 0, 0, NULL},
    {9, "List(ProcessInfo)", UINT32_MAX, false, 23, 0, NULL},
    {16, "ProcessInfo", UINT32_MAX, false, 23, 0, NULL},
    {16, "Mode", UINT32_MAX, false, 28, 0, NULL},
    {16, "BlockKind", UINT32_MAX, false, 30, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 6, 0, NULL},
    {10, "Option(Time)", UINT32_MAX, false, 4, 0, NULL},
    {9, "List(Block)", UINT32_MAX, false, 29, 0, NULL},
    {16, "Block", UINT32_MAX, false, 31, 0, NULL},
    {12, "Map(String, Message)", UINT32_MAX, false, 1, 31, NULL},
    {16, "Message", UINT32_MAX, false, 32, 0, NULL},
    {9, "List(Issue)", UINT32_MAX, false, 33, 0, NULL},
    {16, "Issue", UINT32_MAX, false, 34, 0, NULL},
    {12, "Map(String, UInt64)", UINT32_MAX, false, 1, 6, NULL},
    {9, "List(String)", UINT32_MAX, false, 1, 0, NULL},
    {9, "List(Issue)", UINT32_MAX, false, 33, 0, NULL},
    {9, "List(Block)", UINT32_MAX, false, 29, 0, NULL},
    {10, "Option(Time)", UINT32_MAX, false, 4, 0, NULL},
    {9, "List(Hit)", UINT32_MAX, false, 40, 0, NULL},
    {16, "Hit", UINT32_MAX, false, 37, 0, NULL},
    {16, "Scan", UINT32_MAX, false, 35, 0, NULL},
    {12, "Map(String, Seen)", UINT32_MAX, false, 1, 43, NULL},
    {16, "Seen", UINT32_MAX, false, 33, 0, NULL},
    {9, "List(Block)", UINT32_MAX, false, 29, 0, NULL},
    {10, "Option(Time)", UINT32_MAX, false, 4, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 6, 0, NULL},
    {12, "Map(String, Json)", UINT32_MAX, false, 1, 2, NULL},
    {9, "List(Json)", UINT32_MAX, false, 2, 0, NULL},
    {8, "Float64", UINT32_MAX, false, 64, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 6, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 6, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 6, 0, NULL},
    {0, NULL, UINT32_MAX, false, 0, 0, NULL}
};
const uint32_t mo_nrecorded = 0;
const char *const mo_names[] = {"Some", "None", "Ok", "Error", "Missing", "Timeout", "Syntax", "Object", "Array", "String", "Number", "Bool", "Null", "Down", "Refused", "Closed", "LineTooLong", "Busy", "Malformed", "TooLarge", "Unsupported", "NotText", "Accepted", "Line", "Chunk", "Idle", "NoProcess", "Unparsed", "ReadOnly", "MailboxFull", "Updated", "Started", "Ended", "Restarted", "Crashed", "Overflowed", "TimedOut", "SourcePaused", "SourceResumed", "Sent", "Paused", "Resumed", "File", "Folder", "Dropped", "BadPem", "Handshake", "Untrusted", "Link", "Fixed", "Hole", "Exited", "Signalled", "Failed", "Conversation", "Tool", "Phrase", "AllWords", NULL};
const uint32_t mo_nnames = 58;
const MoClause mo_clauses[] = {
    {6, false, "next.lines += 1", "folded_line", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:57:3"},
    {6, false, "line.byte_size + 1)", "folded_line", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:58:42"},
    {6, false, "next.file_records += 1", "folded_line", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:89:3"},
    {6, false, "next.scan.records += 1", "folded_line", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:90:3"},
    {10, false, "case Json.decode(line)", "folded_line", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:97:3"},
    {10, false, "case payload", "accepted_uuid", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:113:12"},
    {10, false, "case next.seen.get(uuid)", "accepted_uuid", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:121:7"},
    {10, false, "case fields.get(\"uuid\")", "accepted_uuid", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:118:3"},
    {10, false, "case payload", "decoded_record", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:139:12"},
    {10, false, "case fields.get(\"type\")", "decoded_record", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:144:10"},
    {10, false, "case fields.get(\"sessionId\")", "session_of", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:179:3"},
    {10, false, "case Time.parse(text)", "timestamp_of", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:191:7"},
    {10, false, "case fields.get(\"timestamp\")", "timestamp_of", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:189:3"},
    {10, false, "case fields.get(\"message\")", "message_record", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:202:20"},
    {10, false, "case message_fields.get(\"role\")", "message_record", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:207:10"},
    {10, false, "case message_fields.get(\"content\")", "message_record", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:216:12"},
    {10, false, "case fields.get(\"id\")", "identity_of", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:229:3"},
    {6, false, "next.retained_blocks += kept.size", "retain_message", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:263:3"},
    {10, false, "case existing", "retain_message", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:265:3"},
    {10, false, "case value", "block_of", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:293:12"},
    {10, false, "case fields.get(\"type\")", "block_of", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:300:10"},
    {10, false, "case fields.get(\"text\")", "block_of", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:311:7"},
    {10, false, "case kind", "block_of", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:309:3"},
    {10, false, "case fields.get(\"name\")", "tool_use", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:336:10"},
    {10, false, "case fields.get(\"input\")", "tool_use", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:343:11"},
    {10, false, "case fields.get(\"tool_use_id\")", "tool_result", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:356:8"},
    {10, false, "case fields.get(\"content\")", "tool_result", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:364:3"},
    {10, false, "case value", "result_part", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:390:12"},
    {10, false, "case fields.get(\"text\")", "result_part", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:399:7"},
    {10, false, "case fields.get(\"type\")", "result_part", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:397:3"},
    {10, false, "case value.to_i64", "api_index", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:428:7"},
    {10, false, "case fields.get(\"apiBlockIndex\")", "api_index", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:425:3"},
    {10, false, "case (a, b)", "later", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:459:3"},
    {5, false, "assert two.scan.messages.size == 1 and !two.scan.incomplete and two.scan.records == 2", "decoded UUID equality ignores object order and JSON spelling", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:497:3"},
    {5, false, "assert kept.scan.messages.size == 2 and kept.scan.incomplete and kept.scan.records == 3", "file-local UUID state resets and malformed middle input retains neighboring messages", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:506:3"},
    {5, false, "assert other.scan.messages.size == 3", "file-local UUID state resets and malformed middle input retains neighboring messages", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:508:3"},
    {5, false, "assert marked.scan.messages.size == 1 and marked.scan.incomplete", "replacement characters and conflicting payloads preserve first results but are incomplete", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:517:3"},
    {5, false, "assert marked.scan.unknown_kinds.get(\"progress\") == Some(1)", "replacement characters and conflicting payloads preserve first results but are incomplete", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:518:3"},
    {5, false, "assert per_file_refused.stopped and per_file_refused.file_records == 200_000", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:526:3"},
    {5, false, "assert per_file_refused.scan.records == 0 and per_file_refused.scan.messages.size == 0", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:527:3"},
    {5, false, "assert per_file_refused.scan.issues.any\?(fn(issue)", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:528:3"},
    {5, false, "assert !admitted.stopped and admitted.file_records == 200_000", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:534:3"},
    {5, false, "assert admitted.scan.records == 1 and admitted.scan.messages.size == 1", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:535:3"},
    {5, false, "assert total_refused.stopped and total_refused.file_records == 0", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:539:3"},
    {5, false, "assert total_refused.scan.records == 1_000_000 and total_refused.scan.messages.size == 0", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:540:3"},
    {5, false, "assert total_refused.scan.issues.any\?(fn(issue)", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:541:3"},
    {5, false, "assert !total_admitted.stopped and total_admitted.file_records == 1", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:547:3"},
    {5, false, "assert total_admitted.scan.records == 1_000_000 and total_admitted.scan.messages.size == 1", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:548:3"},
    {5, false, "assert capped.incomplete and capped.retained_blocks == 500_000", "production per-file total-record and retained-block counters refuse the next value", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:552:3"},
    {5, false, "assert file_record_admitted\?(199_999) and !file_record_admitted\?(200_000)", "production record and message admission predicates differ at each boundary", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:556:3"},
    {5, false, "assert record_admitted\?(999_999) and !record_admitted\?(1_000_000)", "production record and message admission predicates differ at each boundary", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:557:3"},
    {5, false, "assert message_admitted\?(99_999) and !message_admitted\?(100_000)", "production record and message admission predicates differ at each boundary", "/tmp/mo-lead-moscope-full/examples/programs/moscope/parse.mo:558:3"},
    {0, false, NULL, NULL, NULL}
};
const MoTest mo_tests[] = {
    {MO_TEST, "decoded UUID equality ignores object order and JSON spelling", test0},
    {MO_TEST, "file-local UUID state resets and malformed middle input retains neighboring messages", test1},
    {MO_TEST, "replacement characters and conflicting payloads preserve first results but are incomplete", test2},
    {MO_TEST, "production per-file total-record and retained-block counters refuse the next value", test3},
    {MO_TEST, "production record and message admission predicates differ at each boundary", test4},
    {0, NULL, NULL}
};
const uint32_t mo_ntests = 5;
const MoNever mo_nevers[] = {
    {NULL, 0, 0, NULL}
};
const uint32_t mo_nnevers = 0;
const MoProcess mo_processes[] = {
    {NULL, 0, 0, NULL, NULL, 0, NULL, false}
};
const uint32_t mo_nprocesses = 0;
const MoSupervisor mo_supervisors[] = {
    {NULL, 0, NULL}
};
const uint32_t mo_nsupervisors = 0;
const uint32_t mo_charge_decl = 17;
const uint32_t mo_request_decl = 21;
const uint32_t mo_response_decl = 22;
const uint32_t mo_process_info_decl = 23;
const uint32_t mo_source_info_decl = 24;
const uint32_t mo_memory_info_decl = 27;
const uint32_t mo_entry_decl = 25;
const uint32_t mo_done_decl = 26;
const bool mo_surface_built = false;
const uint32_t mo_surface_process = UINT32_MAX;
const bool mo_contracts_built = true;

MO_U static MoValue f0(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(4096));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f1(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("terms");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(64));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f2(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("depth");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(24));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f3(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("entries");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(50000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f4(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("files");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(5000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f5(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(67108864));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f6(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("total_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1073741824));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f7(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("line_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1048576));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f8(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_records");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(200000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f9(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("records");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1000000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f10(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("messages");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(100000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f11(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("blocks");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(500000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f12(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("results");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(10000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f13(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("diagnostics");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(10000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f14(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("excerpt");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(240));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f15(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("output_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(8388608));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f16(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("call_time");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Int_seconds((const MoValue[]){mo_i64(INT64_C(10))}, 3);
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f17(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("process_time");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Int_seconds((const MoValue[]){mo_i64(INT64_C(60))}, 3);
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f18(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("empty_scan");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t3 MO_U = mo_record(35, 9, (const MoValue[]){t0, t1, t2, mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_bool(false)});
    R = t3;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f19(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("empty_discovery");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_list_of(0, NULL);
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_record(36, 6, (const MoValue[]){t0, t1, mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_bool(false), mo_bool(false)});
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f20(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("start_file");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t2 MO_U = L1;
    MoValue t3 MO_U = L2;
    MoValue t4 MO_U = mo_record(40, 9, (const MoValue[]){t0, t1, t2, mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), t3, mo_bool(false), mo_bool(false)});
    R = t4;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f21() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = R; } while (0)
#define LOAD_f21() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; R = V_[8]; } while (0)
MO_U static MoValue f21(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("folded_line");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue V_[9];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 9, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L2 = t0;
    MoValue t1 MO_U = L2.as.xs[3];
    MoValue t2 MO_U = mo_add_u64(t1, mo_i64(INT64_C(1)), 0);
    MoValue t3 MO_U = L2;
    MoValue t4 MO_U = mo_set_field(t3, 3, t2);
    L2 = t4;
    MoValue t5 MO_U = L2.as.xs[5];
    MoValue t6 MO_U = L1;
    MoValue t7 MO_U = mo_r_String_byte_size((const MoValue[]){t6}, MO_KIND_NONE);
    MoValue t8 MO_U = mo_add_u64(t7, mo_i64(INT64_C(1)), 1);
    MoValue t9 MO_U = mo_r_Int_saturating_add((const MoValue[]){t5, t8}, 7);
    MoValue t10 MO_U = L2;
    MoValue t11 MO_U = mo_set_field(t10, 5, t9);
    L2 = t11;
    MoValue t12 MO_U = L1;
    MoValue t13 MO_U = mo_r_String_contains_q((const MoValue[]){t12, mo_str("\357\277\275", 3)}, MO_KIND_NONE);
    L3 = t13;
    MoValue t14 MO_U = L2.as.xs[7];
    MoValue t15 MO_U = mo_bool(true);
    if (!t14.as.b) {
        MoValue t16 MO_U = L3;
        t15 = t16;
    }
    MoValue t17 MO_U = L2;
    MoValue t18 MO_U = mo_set_field(t17, 7, t15);
    L2 = t18;
    MoValue t19 MO_U = L2.as.xs[8];
    if (t19.as.b) {
        mo_disown_in(L2);
        MoValue t20 MO_U = L2;
        R = t20;
        goto X22;
    }
    MoValue t21 MO_U = L1;
    MoValue t22 MO_U = mo_r_String_byte_size((const MoValue[]){t21}, MO_KIND_NONE);
    MoValue t23 MO_U = f7();
    MoValue t24 MO_U = mo_bool(t22.as.u > t23.as.u);
    if (t24.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t25 MO_U = L2.as.xs[0];
        MoValue t26 MO_U = L2.as.xs[2];
        MoValue t27 MO_U = L2.as.xs[3];
        SAVE_f21();
        uint64_t w28 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t29 MO_U = f44(t25, t26, t27, mo_str("a JSONL line exceeds 1 MiB", 26));
        FR_.walking = false; if (mo_walks != w28) LOAD_f21();
        MoValue t30 MO_U = L2;
        MoValue t31 MO_U = mo_set_field(t30, 0, t29);
        L2 = t31;
        MoValue t32 MO_U = L2;
        MoValue t33 MO_U = mo_set_field(t32, 8, mo_bool(true));
        L2 = t33;
        mo_disown_in(L2);
        MoValue t34 MO_U = L2;
        R = t34;
        goto X22;
    }
    MoValue t35 MO_U = L2.as.xs[7];
    MoValue t36 MO_U = mo_bool(!t35.as.b);
    MoValue t37 MO_U = mo_bool(false);
    if (t36.as.b) {
        MoValue t38 MO_U = L2.as.xs[5];
        MoValue t39 MO_U = L2.as.xs[6];
        MoValue t40 MO_U = mo_r_Int_saturating_add((const MoValue[]){t39, mo_i64(INT64_C(1))}, 7);
        MoValue t41 MO_U = mo_bool(t38.as.u > t40.as.u);
        t37 = t41;
    }
    if (t37.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t42 MO_U = L2.as.xs[0];
        MoValue t43 MO_U = L2.as.xs[2];
        MoValue t44 MO_U = L2.as.xs[3];
        SAVE_f21();
        uint64_t w45 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t46 MO_U = f44(t42, t43, t44, mo_str("the file grew after size admission; results use only the admitted prefix", 72));
        FR_.walking = false; if (mo_walks != w45) LOAD_f21();
        MoValue t47 MO_U = L2;
        MoValue t48 MO_U = mo_set_field(t47, 0, t46);
        L2 = t48;
        MoValue t49 MO_U = L2;
        MoValue t50 MO_U = mo_set_field(t49, 8, mo_bool(true));
        L2 = t50;
        mo_disown_in(L2);
        MoValue t51 MO_U = L2;
        R = t51;
        goto X22;
    }
    MoValue t52 MO_U = L2.as.xs[4];
    MoValue t53 MO_U = f39(t52);
    MoValue t54 MO_U = mo_bool(!t53.as.b);
    if (t54.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t55 MO_U = L2.as.xs[0];
        MoValue t56 MO_U = L2.as.xs[2];
        MoValue t57 MO_U = L2.as.xs[3];
        SAVE_f21();
        uint64_t w58 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t59 MO_U = f44(t55, t56, t57, mo_str("the file exceeds 200000 records", 31));
        FR_.walking = false; if (mo_walks != w58) LOAD_f21();
        MoValue t60 MO_U = L2;
        MoValue t61 MO_U = mo_set_field(t60, 0, t59);
        L2 = t61;
        MoValue t62 MO_U = L2;
        MoValue t63 MO_U = mo_set_field(t62, 8, mo_bool(true));
        L2 = t63;
        mo_disown_in(L2);
        MoValue t64 MO_U = L2;
        R = t64;
        goto X22;
    }
    MoValue t65 MO_U = L2.as.xs[0];
    MoValue t66 MO_U = t65.as.xs[6];
    MoValue t67 MO_U = f40(t66);
    MoValue t68 MO_U = mo_bool(!t67.as.b);
    if (t68.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t69 MO_U = L2.as.xs[0];
        MoValue t70 MO_U = L2.as.xs[2];
        MoValue t71 MO_U = L2.as.xs[3];
        SAVE_f21();
        uint64_t w72 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t73 MO_U = f44(t69, t70, t71, mo_str("the search exceeds 1000000 records", 34));
        FR_.walking = false; if (mo_walks != w72) LOAD_f21();
        MoValue t74 MO_U = L2;
        MoValue t75 MO_U = mo_set_field(t74, 0, t73);
        L2 = t75;
        MoValue t76 MO_U = L2;
        MoValue t77 MO_U = mo_set_field(t76, 8, mo_bool(true));
        L2 = t77;
        mo_disown_in(L2);
        MoValue t78 MO_U = L2;
        R = t78;
        goto X22;
    }
    MoValue t79 MO_U = L2.as.xs[4];
    MoValue t80 MO_U = mo_add_u64(t79, mo_i64(INT64_C(1)), 2);
    MoValue t81 MO_U = L2;
    MoValue t82 MO_U = mo_set_field(t81, 4, t80);
    L2 = t82;
    MoValue t83 MO_U = L2.as.xs[0];
    MoValue t84 MO_U = t83.as.xs[6];
    MoValue t85 MO_U = mo_add_u64(t84, mo_i64(INT64_C(1)), 3);
    MoValue t86 MO_U = L2;
    MoValue t87 MO_U = t86.as.xs[0];
    MoValue t88 MO_U = mo_set_field(t87, 6, t85);
    MoValue t89 MO_U = L2;
    MoValue t90 MO_U = mo_set_field(t89, 0, t88);
    L2 = t90;
    MoValue t91 MO_U = L3;
    if (t91.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t92 MO_U = L2.as.xs[0];
        MoValue t93 MO_U = L2.as.xs[2];
        MoValue t94 MO_U = L2.as.xs[3];
        SAVE_f21();
        uint64_t w95 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t96 MO_U = f44(t92, t93, t94, mo_str("U+FFFD is present; fold_lines cannot distinguish it from replaced invalid UTF-8", 79));
        FR_.walking = false; if (mo_walks != w95) LOAD_f21();
        MoValue t97 MO_U = L2;
        MoValue t98 MO_U = mo_set_field(t97, 0, t96);
        L2 = t98;
    }
    MoValue t99 MO_U = L1;
    MoValue t100 MO_U = mo_r_Json_decode((const MoValue[]){t99}, MO_KIND_NONE);
    L4 = t100;
    if (!mo_is(L4, 2)) goto F24;
    L5 = L4.as.xs[0];
    L6 = L5;
    if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
    mo_disown_in(L2);
    MoValue t101 MO_U = L2;
    MoValue t102 MO_U = L6;
    SAVE_f21();
    uint64_t w103 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t104 MO_U = f22(t101, t102);
    FR_.walking = false; if (mo_walks != w103) LOAD_f21();
    L7 = t104;
    MoValue t105 MO_U = L7.as.xs[0];
    L2 = t105;
    MoValue t106 MO_U = L7.as.xs[1];
    if (t106.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
        MoValue t107 MO_U = L2.as.xs[0];
        MoValue t108 MO_U = L2.as.xs[2];
        MoValue t109 MO_U = L2.as.xs[3];
        MoValue t110 MO_U = L6;
        SAVE_f21();
        uint64_t w111 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t112 MO_U = f23(t107, t108, t109, t110);
        FR_.walking = false; if (mo_walks != w111) LOAD_f21();
        MoValue t113 MO_U = L2;
        MoValue t114 MO_U = mo_set_field(t113, 0, t112);
        L2 = t114;
    }
    goto E23;
    F24:;
    if (!mo_is(L4, 3)) goto F25;
    if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
    MoValue t115 MO_U = L2.as.xs[0];
    MoValue t116 MO_U = L2.as.xs[2];
    MoValue t117 MO_U = L2.as.xs[3];
    SAVE_f21();
    uint64_t w118 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t119 MO_U = f44(t115, t116, t117, mo_str("malformed JSON record", 21));
    FR_.walking = false; if (mo_walks != w118) LOAD_f21();
    MoValue t120 MO_U = L2;
    MoValue t121 MO_U = mo_set_field(t120, 0, t119);
    L2 = t121;
    goto E23;
    F25:;
    mo_crash(4);
    E23:;
    MoValue t122 MO_U = L2;
    R = t122;
    X22:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f21
#undef LOAD_f21
#define SAVE_f22() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = R; } while (0)
#define LOAD_f22() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; R = V_[14]; } while (0)
MO_U static MoValue f22(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("accepted_uuid");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue V_[15];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 15, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L2 = t0;
    MoValue t1 MO_U = MO_NONE_V;
    MoValue t2 MO_U = L1;
    L3 = t2;
    if (!mo_is(L3, 7)) goto F28;
    L4 = L3.as.xs[0];
    L5 = L4;
    MoValue t3 MO_U = L5;
    t1 = t3;
    goto E27;
    F28:;
    if (!mo_is(L3, 9)) goto F31;
    goto E30;
    F31:;
    if (!mo_is(L3, 8)) goto F32;
    goto E30;
    F32:;
    if (!mo_is(L3, 10)) goto F33;
    goto E30;
    F33:;
    if (!mo_is(L3, 11)) goto F34;
    goto E30;
    F34:;
    if (!mo_is(L3, 12)) goto F29;
    E30:;
    mo_disown_in(L2);
    MoValue t4 MO_U = L2;
    MoValue t5 MO_U = mo_tuple(2, (const MoValue[]){t4, mo_bool(true)});
    R = t5;
    goto X26;
    t1 = MO_NONE_V;
    goto E27;
    F29:;
    mo_crash(5);
    E27:;
    L6 = t1;
    MoValue t6 MO_U = MO_NONE_V;
    MoValue t7 MO_U = L6;
    MoValue t8 MO_U = mo_r_Map_get((const MoValue[]){t7, mo_str("uuid", 4)}, MO_KIND_NONE);
    L7 = t8;
    if (!mo_is(L7, 1)) goto F37;
    mo_disown_in(L2);
    MoValue t9 MO_U = L2;
    MoValue t10 MO_U = mo_tuple(2, (const MoValue[]){t9, mo_bool(true)});
    t6 = t10;
    goto E36;
    F37:;
    if (!mo_is(L7, 0)) goto F38;
    L8 = L7.as.xs[0];
    if (!mo_is(L8, 9)) goto F38;
    L9 = L8.as.xs[0];
    L10 = L9;
    MoValue t11 MO_U = MO_NONE_V;
    MoValue t12 MO_U = L2;
    MoValue t13 MO_U = t12.as.xs[1];
    MoValue t14 MO_U = L10;
    MoValue t15 MO_U = mo_r_Map_get((const MoValue[]){t13, t14}, MO_KIND_NONE);
    L11 = t15;
    if (!mo_is(L11, 1)) goto F40;
    MoValue t16 MO_U = L2;
    MoValue t17 MO_U = t16.as.xs[1];
    MoValue t18 MO_U = L10;
    MoValue t19 MO_U = L1;
    MoValue t20 MO_U = L2.as.xs[3];
    MoValue t21 MO_U = mo_record(33, 2, (const MoValue[]){t19, t20});
    mo_disown_in(t21);
    MoValue t22 MO_U = mo_r_Map_set((const MoValue[]){t17, t18, t21}, MO_KIND_UNIQUE);
    MoValue t23 MO_U = L2;
    MoValue t24 MO_U = mo_set_field(t23, 1, t22);
    L2 = t24;
    mo_disown_in(L2);
    MoValue t25 MO_U = L2;
    MoValue t26 MO_U = mo_tuple(2, (const MoValue[]){t25, mo_bool(true)});
    t11 = t26;
    goto E39;
    F40:;
    if (!mo_is(L11, 0)) goto F41;
    L12 = L11.as.xs[0];
    L13 = L12;
    MoValue t27 MO_U = MO_NONE_V;
    MoValue t28 MO_U = L13.as.xs[0];
    MoValue t29 MO_U = L1;
    MoValue t30 MO_U = mo_bool(mo_compare(MO_EQ, t28, t29));
    if (t30.as.b) {
        mo_disown_in(L2);
        MoValue t31 MO_U = L2;
        MoValue t32 MO_U = mo_tuple(2, (const MoValue[]){t31, mo_bool(false)});
        t27 = t32;
    } else {
        if (mo_walk_due(&FR_)) { SAVE_f22(); mo_walk(&FR_); LOAD_f22(); }
        MoValue t33 MO_U = L2.as.xs[0];
        MoValue t34 MO_U = L2.as.xs[2];
        MoValue t35 MO_U = L2.as.xs[3];
        MoValue t36 MO_U = L10;
        MoValue t37 MO_U = L13.as.xs[1];
        MoValue t38 MO_U = mo_concat(4, (const MoValue[]){mo_str("UUID ", 5), t36, mo_str(" conflicts with line ", 21), t37});
        SAVE_f22();
        uint64_t w39 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t40 MO_U = f44(t33, t34, t35, t38);
        FR_.walking = false; if (mo_walks != w39) LOAD_f22();
        MoValue t41 MO_U = L2;
        MoValue t42 MO_U = mo_set_field(t41, 0, t40);
        L2 = t42;
        mo_disown_in(L2);
        MoValue t43 MO_U = L2;
        MoValue t44 MO_U = mo_tuple(2, (const MoValue[]){t43, mo_bool(false)});
        t27 = t44;
    }
    t11 = t27;
    goto E39;
    F41:;
    mo_crash(6);
    E39:;
    t6 = t11;
    goto E36;
    F38:;
    if (!mo_is(L7, 0)) goto F42;
    MoValue t45 MO_U = L2;
    MoValue t46 MO_U = mo_tuple(2, (const MoValue[]){t45, mo_bool(true)});
    t6 = t46;
    goto E36;
    F42:;
    mo_crash(7);
    E36:;
    R = t6;
    X26:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f22
#undef LOAD_f22
#define SAVE_f23() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = L18; V_[19] = L19; V_[20] = R; } while (0)
#define LOAD_f23() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; L18 = V_[18]; L19 = V_[19]; R = V_[20]; } while (0)
MO_U static MoValue f23(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("decoded_record");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue V_[21];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 21, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L3;
    L4 = t1;
    if (!mo_is(L4, 7)) goto F45;
    L5 = L4.as.xs[0];
    L6 = L5;
    MoValue t2 MO_U = L6;
    t0 = t2;
    goto E44;
    F45:;
    if (!mo_is(L4, 9)) goto F48;
    goto E47;
    F48:;
    if (!mo_is(L4, 8)) goto F49;
    goto E47;
    F49:;
    if (!mo_is(L4, 10)) goto F50;
    goto E47;
    F50:;
    if (!mo_is(L4, 11)) goto F51;
    goto E47;
    F51:;
    if (!mo_is(L4, 12)) goto F46;
    E47:;
    if (mo_walk_due(&FR_)) { SAVE_f23(); mo_walk(&FR_); LOAD_f23(); }
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L1;
    MoValue t5 MO_U = L2;
    SAVE_f23();
    uint64_t w6 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t7 MO_U = f44(t3, t4, t5, mo_str("top-level JSON record is not an object", 38));
    FR_.walking = false; if (mo_walks != w6) LOAD_f23();
    R = t7;
    goto X43;
    t0 = MO_NONE_V;
    goto E44;
    F46:;
    mo_crash(8);
    E44:;
    L7 = t0;
    MoValue t8 MO_U = MO_NONE_V;
    MoValue t9 MO_U = L7;
    MoValue t10 MO_U = mo_r_Map_get((const MoValue[]){t9, mo_str("type", 4)}, MO_KIND_NONE);
    L8 = t10;
    if (!mo_is(L8, 0)) goto F54;
    L9 = L8.as.xs[0];
    if (!mo_is(L9, 9)) goto F54;
    L10 = L9.as.xs[0];
    L11 = L10;
    MoValue t11 MO_U = L11;
    t8 = t11;
    goto E53;
    F54:;
    if (!mo_is(L8, 1)) goto F57;
    goto E56;
    F57:;
    if (!mo_is(L8, 0)) goto F58;
    L12 = L8.as.xs[0];
    if (!mo_is(L12, 7)) goto F58;
    goto E56;
    F58:;
    if (!mo_is(L8, 0)) goto F59;
    L13 = L8.as.xs[0];
    if (!mo_is(L13, 8)) goto F59;
    goto E56;
    F59:;
    if (!mo_is(L8, 0)) goto F60;
    L14 = L8.as.xs[0];
    if (!mo_is(L14, 10)) goto F60;
    goto E56;
    F60:;
    if (!mo_is(L8, 0)) goto F61;
    L15 = L8.as.xs[0];
    if (!mo_is(L15, 11)) goto F61;
    goto E56;
    F61:;
    if (!mo_is(L8, 0)) goto F55;
    L16 = L8.as.xs[0];
    if (!mo_is(L16, 12)) goto F55;
    E56:;
    if (mo_walk_due(&FR_)) { SAVE_f23(); mo_walk(&FR_); LOAD_f23(); }
    mo_disown_in(L0);
    MoValue t12 MO_U = L0;
    MoValue t13 MO_U = L1;
    MoValue t14 MO_U = L2;
    SAVE_f23();
    uint64_t w15 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t16 MO_U = f44(t12, t13, t14, mo_str("top-level record type is missing or not a string", 48));
    FR_.walking = false; if (mo_walks != w15) LOAD_f23();
    R = t16;
    goto X43;
    t8 = MO_NONE_V;
    goto E53;
    F55:;
    mo_crash(9);
    E53:;
    L17 = t8;
    MoValue t17 MO_U = L17;
    MoValue t18 MO_U = mo_bool(mo_compare(MO_NE, t17, mo_str("user", 4)));
    MoValue t19 MO_U = mo_bool(false);
    if (t18.as.b) {
        MoValue t20 MO_U = L17;
        MoValue t21 MO_U = mo_bool(mo_compare(MO_NE, t20, mo_str("assistant", 9)));
        t19 = t21;
    }
    if (t19.as.b) {
        MoValue t22 MO_U = L7;
        MoValue t23 MO_U = mo_r_Map_get((const MoValue[]){t22, mo_str("message", 7)}, MO_KIND_NONE);
        L18 = t23;
        MoValue t24 MO_U = mo_bool(true);
        if (!mo_is(L18, 0)) goto F63;
        L19 = L18.as.xs[0];
        if (!mo_is(L19, 7)) goto F63;
        goto E64;
        F63:;
        t24 = mo_bool(false);
        E64:;
        if (t24.as.b) {
            if (mo_walk_due(&FR_)) { SAVE_f23(); mo_walk(&FR_); LOAD_f23(); }
            mo_disown_in(L0);
            MoValue t25 MO_U = L0;
            MoValue t26 MO_U = L1;
            MoValue t27 MO_U = L2;
            MoValue t28 MO_U = L17;
            MoValue t29 MO_U = mo_concat(3, (const MoValue[]){mo_str("unknown type ", 13), t28, mo_str(" has a conversation-shaped message", 34)});
            SAVE_f23();
            uint64_t w30 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t31 MO_U = f44(t25, t26, t27, t29);
            FR_.walking = false; if (mo_walks != w30) LOAD_f23();
            R = t31;
            goto X43;
        }
        if (mo_walk_due(&FR_)) { SAVE_f23(); mo_walk(&FR_); LOAD_f23(); }
        mo_disown_in(L0);
        MoValue t32 MO_U = L0;
        MoValue t33 MO_U = L17;
        SAVE_f23();
        uint64_t w34 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t35 MO_U = f43(t32, t33);
        FR_.walking = false; if (mo_walks != w34) LOAD_f23();
        R = t35;
        goto X43;
    }
    if (mo_walk_due(&FR_)) { SAVE_f23(); mo_walk(&FR_); LOAD_f23(); }
    MoValue t36 MO_U = L0;
    MoValue t37 MO_U = L1;
    MoValue t38 MO_U = L2;
    MoValue t39 MO_U = L17;
    MoValue t40 MO_U = L7;
    SAVE_f23();
    uint64_t w41 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t42 MO_U = f24(t36, t37, t38, t39, t40);
    FR_.walking = false; if (mo_walks != w41) LOAD_f23();
    R = t42;
    X43:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f23
#undef LOAD_f23
#define SAVE_f24() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = R; } while (0)
#define LOAD_f24() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; R = V_[13]; } while (0)
MO_U static MoValue f24(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("conversation");
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue V_[14];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 14, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L5 = t0;
    mo_disown_in(L4);
    MoValue t1 MO_U = L4;
    MoValue t2 MO_U = f38(t1, mo_str("isMeta", 6));
    MoValue t3 MO_U = mo_bool(true);
    if (!t2.as.b) {
        mo_disown_in(L4);
        MoValue t4 MO_U = L4;
        MoValue t5 MO_U = f38(t4, mo_str("isCompactSummary", 16));
        t3 = t5;
    }
    MoValue t6 MO_U = mo_bool(true);
    if (!t3.as.b) {
        mo_disown_in(L4);
        MoValue t7 MO_U = L4;
        MoValue t8 MO_U = f38(t7, mo_str("isApiErrorMessage", 17));
        t6 = t8;
    }
    if (t6.as.b) {
        mo_disown_in(L5);
        MoValue t9 MO_U = L5;
        R = t9;
        goto X65;
    }
    MoValue t10 MO_U = L4;
    MoValue t11 MO_U = mo_r_Map_get((const MoValue[]){t10, mo_str("uuid", 4)}, MO_KIND_NONE);
    L6 = t11;
    MoValue t12 MO_U = mo_bool(true);
    if (!mo_is(L6, 0)) goto F66;
    L7 = L6.as.xs[0];
    L8 = L7;
    goto E67;
    F66:;
    t12 = mo_bool(false);
    E67:;
    if (t12.as.b) {
        MoValue t13 MO_U = L8;
        L9 = t13;
        MoValue t14 MO_U = mo_bool(true);
        if (!mo_is(L9, 9)) goto F68;
        goto E69;
        F68:;
        t14 = mo_bool(false);
        E69:;
        MoValue t15 MO_U = mo_bool(!t14.as.b);
        if (t15.as.b) {
            if (mo_walk_due(&FR_)) { SAVE_f24(); mo_walk(&FR_); LOAD_f24(); }
            MoValue t16 MO_U = L5;
            MoValue t17 MO_U = L1;
            MoValue t18 MO_U = L2;
            SAVE_f24();
            uint64_t w19 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t20 MO_U = f44(t16, t17, t18, mo_str("conversation uuid is not a string", 33));
            FR_.walking = false; if (mo_walks != w19) LOAD_f24();
            L5 = t20;
        }
    }
    if (mo_walk_due(&FR_)) { SAVE_f24(); mo_walk(&FR_); LOAD_f24(); }
    mo_disown_in(L5);
    MoValue t21 MO_U = L5;
    MoValue t22 MO_U = L1;
    MoValue t23 MO_U = L2;
    mo_disown_in(L4);
    MoValue t24 MO_U = L4;
    SAVE_f24();
    uint64_t w25 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t26 MO_U = f25(t21, t22, t23, t24);
    FR_.walking = false; if (mo_walks != w25) LOAD_f24();
    L10 = t26;
    MoValue t27 MO_U = L10.as.xs[0];
    L5 = t27;
    if (mo_walk_due(&FR_)) { SAVE_f24(); mo_walk(&FR_); LOAD_f24(); }
    mo_disown_in(L5);
    MoValue t28 MO_U = L5;
    MoValue t29 MO_U = L1;
    MoValue t30 MO_U = L2;
    mo_disown_in(L4);
    MoValue t31 MO_U = L4;
    SAVE_f24();
    uint64_t w32 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t33 MO_U = f26(t28, t29, t30, t31);
    FR_.walking = false; if (mo_walks != w32) LOAD_f24();
    L11 = t33;
    MoValue t34 MO_U = L11.as.xs[0];
    L5 = t34;
    MoValue t35 MO_U = L1;
    MoValue t36 MO_U = L2;
    MoValue t37 MO_U = L3;
    MoValue t38 MO_U = L10.as.xs[1];
    MoValue t39 MO_U = L11.as.xs[1];
    MoValue t40 MO_U = mo_record(42, 5, (const MoValue[]){t35, t36, t37, t38, t39});
    L12 = t40;
    if (mo_walk_due(&FR_)) { SAVE_f24(); mo_walk(&FR_); LOAD_f24(); }
    MoValue t41 MO_U = L5;
    MoValue t42 MO_U = L12;
    MoValue t43 MO_U = L4;
    SAVE_f24();
    uint64_t w44 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t45 MO_U = f27(t41, t42, t43);
    FR_.walking = false; if (mo_walks != w44) LOAD_f24();
    R = t45;
    X65:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f24
#undef LOAD_f24
MO_U static MoValue f25(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("session_of");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L3;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("sessionId", 9)}, MO_KIND_NONE);
    L4 = t2;
    if (!mo_is(L4, 0)) goto F72;
    L5 = L4.as.xs[0];
    if (!mo_is(L5, 9)) goto F72;
    L6 = L5.as.xs[0];
    L7 = L6;
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L7;
    MoValue t5 MO_U = mo_tuple(2, (const MoValue[]){t3, t4});
    t0 = t5;
    goto E71;
    F72:;
    if (!mo_is(L4, 1)) goto F73;
    mo_disown_in(L0);
    MoValue t6 MO_U = L0;
    MoValue t7 MO_U = mo_tuple(2, (const MoValue[]){t6, mo_str("", 0)});
    t0 = t7;
    goto E71;
    F73:;
    if (!mo_is(L4, 0)) goto F76;
    L8 = L4.as.xs[0];
    if (!mo_is(L8, 7)) goto F76;
    goto E75;
    F76:;
    if (!mo_is(L4, 0)) goto F77;
    L9 = L4.as.xs[0];
    if (!mo_is(L9, 8)) goto F77;
    goto E75;
    F77:;
    if (!mo_is(L4, 0)) goto F78;
    L10 = L4.as.xs[0];
    if (!mo_is(L10, 10)) goto F78;
    goto E75;
    F78:;
    if (!mo_is(L4, 0)) goto F79;
    L11 = L4.as.xs[0];
    if (!mo_is(L11, 11)) goto F79;
    goto E75;
    F79:;
    if (!mo_is(L4, 0)) goto F74;
    L12 = L4.as.xs[0];
    if (!mo_is(L12, 12)) goto F74;
    E75:;
    MoValue t8 MO_U = L0;
    MoValue t9 MO_U = L1;
    MoValue t10 MO_U = L2;
    MoValue t11 MO_U = f44(t8, t9, t10, mo_str("conversation sessionId is not a string", 38));
    MoValue t12 MO_U = mo_tuple(2, (const MoValue[]){t11, mo_str("", 0)});
    t0 = t12;
    goto E71;
    F74:;
    mo_crash(10);
    E71:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f26(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("timestamp_of");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L3;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("timestamp", 9)}, MO_KIND_NONE);
    L4 = t2;
    if (!mo_is(L4, 0)) goto F83;
    L5 = L4.as.xs[0];
    if (!mo_is(L5, 9)) goto F83;
    L6 = L5.as.xs[0];
    L7 = L6;
    MoValue t3 MO_U = MO_NONE_V;
    MoValue t4 MO_U = L7;
    MoValue t5 MO_U = mo_r_Time_parse((const MoValue[]){t4}, MO_KIND_NONE);
    L8 = t5;
    if (!mo_is(L8, 0)) goto F85;
    L9 = L8.as.xs[0];
    L10 = L9;
    mo_disown_in(L0);
    MoValue t6 MO_U = L0;
    MoValue t7 MO_U = L10;
    MoValue t8 MO_U = mo_variant(0, 1, (const MoValue[]){t7});
    MoValue t9 MO_U = mo_tuple(2, (const MoValue[]){t6, t8});
    t3 = t9;
    goto E84;
    F85:;
    if (!mo_is(L8, 1)) goto F86;
    mo_disown_in(L0);
    MoValue t10 MO_U = L0;
    MoValue t11 MO_U = L1;
    MoValue t12 MO_U = L2;
    MoValue t13 MO_U = f44(t10, t11, t12, mo_str("conversation timestamp is not supported RFC 3339", 48));
    MoValue t14 MO_U = mo_variant(1, 0, NULL);
    MoValue t15 MO_U = mo_tuple(2, (const MoValue[]){t13, t14});
    t3 = t15;
    goto E84;
    F86:;
    mo_crash(11);
    E84:;
    t0 = t3;
    goto E82;
    F83:;
    if (!mo_is(L4, 1)) goto F87;
    mo_disown_in(L0);
    MoValue t16 MO_U = L0;
    MoValue t17 MO_U = mo_variant(1, 0, NULL);
    MoValue t18 MO_U = mo_tuple(2, (const MoValue[]){t16, t17});
    t0 = t18;
    goto E82;
    F87:;
    if (!mo_is(L4, 0)) goto F90;
    L11 = L4.as.xs[0];
    if (!mo_is(L11, 7)) goto F90;
    goto E89;
    F90:;
    if (!mo_is(L4, 0)) goto F91;
    L12 = L4.as.xs[0];
    if (!mo_is(L12, 8)) goto F91;
    goto E89;
    F91:;
    if (!mo_is(L4, 0)) goto F92;
    L13 = L4.as.xs[0];
    if (!mo_is(L13, 10)) goto F92;
    goto E89;
    F92:;
    if (!mo_is(L4, 0)) goto F93;
    L14 = L4.as.xs[0];
    if (!mo_is(L14, 11)) goto F93;
    goto E89;
    F93:;
    if (!mo_is(L4, 0)) goto F88;
    L15 = L4.as.xs[0];
    if (!mo_is(L15, 12)) goto F88;
    E89:;
    MoValue t19 MO_U = L0;
    MoValue t20 MO_U = L1;
    MoValue t21 MO_U = L2;
    MoValue t22 MO_U = f44(t19, t20, t21, mo_str("conversation timestamp is not a string", 38));
    MoValue t23 MO_U = mo_variant(1, 0, NULL);
    MoValue t24 MO_U = mo_tuple(2, (const MoValue[]){t22, t23});
    t0 = t24;
    goto E82;
    F88:;
    mo_crash(12);
    E82:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f27() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = L18; V_[19] = L19; V_[20] = L20; V_[21] = L21; V_[22] = L22; V_[23] = L23; V_[24] = L24; V_[25] = L25; V_[26] = L26; V_[27] = L27; V_[28] = L28; V_[29] = L29; V_[30] = L30; V_[31] = L31; V_[32] = L32; V_[33] = L33; V_[34] = L34; V_[35] = L35; V_[36] = R; } while (0)
#define LOAD_f27() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; L18 = V_[18]; L19 = V_[19]; L20 = V_[20]; L21 = V_[21]; L22 = V_[22]; L23 = V_[23]; L24 = V_[24]; L25 = V_[25]; L26 = V_[26]; L27 = V_[27]; L28 = V_[28]; L29 = V_[29]; L30 = V_[30]; L31 = V_[31]; L32 = V_[32]; L33 = V_[33]; L34 = V_[34]; L35 = V_[35]; R = V_[36]; } while (0)
MO_U static MoValue f27(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("message_record");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    MoValue L21 MO_U = MO_NONE_V;
    MoValue L22 MO_U = MO_NONE_V;
    MoValue L23 MO_U = MO_NONE_V;
    MoValue L24 MO_U = MO_NONE_V;
    MoValue L25 MO_U = MO_NONE_V;
    MoValue L26 MO_U = MO_NONE_V;
    MoValue L27 MO_U = MO_NONE_V;
    MoValue L28 MO_U = MO_NONE_V;
    MoValue L29 MO_U = MO_NONE_V;
    MoValue L30 MO_U = MO_NONE_V;
    MoValue L31 MO_U = MO_NONE_V;
    MoValue L32 MO_U = MO_NONE_V;
    MoValue L33 MO_U = MO_NONE_V;
    MoValue L34 MO_U = MO_NONE_V;
    MoValue L35 MO_U = MO_NONE_V;
    MoValue V_[37];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 37, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L2;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("message", 7)}, MO_KIND_NONE);
    L3 = t2;
    if (!mo_is(L3, 0)) goto F97;
    L4 = L3.as.xs[0];
    if (!mo_is(L4, 7)) goto F97;
    L5 = L4.as.xs[0];
    L6 = L5;
    MoValue t3 MO_U = L6;
    t0 = t3;
    goto E96;
    F97:;
    if (!mo_is(L3, 1)) goto F100;
    goto E99;
    F100:;
    if (!mo_is(L3, 0)) goto F101;
    L7 = L3.as.xs[0];
    if (!mo_is(L7, 9)) goto F101;
    goto E99;
    F101:;
    if (!mo_is(L3, 0)) goto F102;
    L8 = L3.as.xs[0];
    if (!mo_is(L8, 8)) goto F102;
    goto E99;
    F102:;
    if (!mo_is(L3, 0)) goto F103;
    L9 = L3.as.xs[0];
    if (!mo_is(L9, 10)) goto F103;
    goto E99;
    F103:;
    if (!mo_is(L3, 0)) goto F104;
    L10 = L3.as.xs[0];
    if (!mo_is(L10, 11)) goto F104;
    goto E99;
    F104:;
    if (!mo_is(L3, 0)) goto F98;
    L11 = L3.as.xs[0];
    if (!mo_is(L11, 12)) goto F98;
    E99:;
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    mo_disown_in(L0);
    MoValue t4 MO_U = L0;
    MoValue t5 MO_U = L1.as.xs[0];
    MoValue t6 MO_U = L1.as.xs[1];
    SAVE_f27();
    uint64_t w7 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t8 MO_U = f44(t4, t5, t6, mo_str("conversation message is not an object", 37));
    FR_.walking = false; if (mo_walks != w7) LOAD_f27();
    R = t8;
    goto X95;
    t0 = MO_NONE_V;
    goto E96;
    F98:;
    mo_crash(13);
    E96:;
    L12 = t0;
    MoValue t9 MO_U = MO_NONE_V;
    MoValue t10 MO_U = L12;
    MoValue t11 MO_U = mo_r_Map_get((const MoValue[]){t10, mo_str("role", 4)}, MO_KIND_NONE);
    L13 = t11;
    if (!mo_is(L13, 0)) goto F107;
    L14 = L13.as.xs[0];
    if (!mo_is(L14, 9)) goto F107;
    L15 = L14.as.xs[0];
    L16 = L15;
    MoValue t12 MO_U = L16;
    t9 = t12;
    goto E106;
    F107:;
    if (!mo_is(L13, 1)) goto F110;
    goto E109;
    F110:;
    if (!mo_is(L13, 0)) goto F111;
    L17 = L13.as.xs[0];
    if (!mo_is(L17, 7)) goto F111;
    goto E109;
    F111:;
    if (!mo_is(L13, 0)) goto F112;
    L18 = L13.as.xs[0];
    if (!mo_is(L18, 8)) goto F112;
    goto E109;
    F112:;
    if (!mo_is(L13, 0)) goto F113;
    L19 = L13.as.xs[0];
    if (!mo_is(L19, 10)) goto F113;
    goto E109;
    F113:;
    if (!mo_is(L13, 0)) goto F114;
    L20 = L13.as.xs[0];
    if (!mo_is(L20, 11)) goto F114;
    goto E109;
    F114:;
    if (!mo_is(L13, 0)) goto F108;
    L21 = L13.as.xs[0];
    if (!mo_is(L21, 12)) goto F108;
    E109:;
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    mo_disown_in(L0);
    MoValue t13 MO_U = L0;
    MoValue t14 MO_U = L1.as.xs[0];
    MoValue t15 MO_U = L1.as.xs[1];
    SAVE_f27();
    uint64_t w16 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t17 MO_U = f44(t13, t14, t15, mo_str("conversation message role is not a string", 41));
    FR_.walking = false; if (mo_walks != w16) LOAD_f27();
    R = t17;
    goto X95;
    t9 = MO_NONE_V;
    goto E106;
    F108:;
    mo_crash(14);
    E106:;
    L22 = t9;
    MoValue t18 MO_U = L22;
    MoValue t19 MO_U = L1.as.xs[2];
    MoValue t20 MO_U = mo_bool(mo_compare(MO_NE, t18, t19));
    if (t20.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
        mo_disown_in(L0);
        MoValue t21 MO_U = L0;
        MoValue t22 MO_U = L1.as.xs[0];
        MoValue t23 MO_U = L1.as.xs[1];
        SAVE_f27();
        uint64_t w24 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t25 MO_U = f44(t21, t22, t23, mo_str("top-level type and message role disagree", 40));
        FR_.walking = false; if (mo_walks != w24) LOAD_f27();
        R = t25;
        goto X95;
    }
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    MoValue t26 MO_U = L0;
    MoValue t27 MO_U = L1.as.xs[0];
    MoValue t28 MO_U = L1.as.xs[1];
    mo_disown_in(L12);
    MoValue t29 MO_U = L12;
    SAVE_f27();
    uint64_t w30 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t31 MO_U = f28(t26, t27, t28, t29);
    FR_.walking = false; if (mo_walks != w30) LOAD_f27();
    L23 = t31;
    MoValue t32 MO_U = MO_NONE_V;
    MoValue t33 MO_U = L12;
    MoValue t34 MO_U = mo_r_Map_get((const MoValue[]){t33, mo_str("content", 7)}, MO_KIND_NONE);
    L24 = t34;
    if (!mo_is(L24, 0)) goto F117;
    L25 = L24.as.xs[0];
    if (!mo_is(L25, 9)) goto F117;
    L26 = L25.as.xs[0];
    L27 = L26;
    MoValue t35 MO_U = L23.as.xs[0];
    mo_disown_in(t35);
    MoValue t36 MO_U = L22;
    MoValue t37 MO_U = L27;
    MoValue t38 MO_U = L1.as.xs[0];
    MoValue t39 MO_U = L1.as.xs[1];
    MoValue t40 MO_U = mo_variant(1, 0, NULL);
    MoValue t41 MO_U = f32(t36, t37, t38, t39, mo_i64(INT64_C(0)), t40);
    mo_disown_in(t41);
    MoValue t42 MO_U = mo_list_of(1, (const MoValue[]){t41});
    MoValue t43 MO_U = mo_record(41, 2, (const MoValue[]){t35, t42});
    t32 = t43;
    goto E116;
    F117:;
    if (!mo_is(L24, 0)) goto F118;
    L28 = L24.as.xs[0];
    if (!mo_is(L28, 8)) goto F118;
    L29 = L28.as.xs[0];
    L30 = L29;
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    MoValue t44 MO_U = L23.as.xs[0];
    mo_disown_in(t44);
    MoValue t45 MO_U = L22;
    MoValue t46 MO_U = L1.as.xs[0];
    MoValue t47 MO_U = L1.as.xs[1];
    MoValue t48 MO_U = L30;
    SAVE_f27();
    uint64_t w49 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t50 MO_U = f30(t44, t45, t46, t47, t48);
    FR_.walking = false; if (mo_walks != w49) LOAD_f27();
    t32 = t50;
    goto E116;
    F118:;
    if (!mo_is(L24, 1)) goto F121;
    goto E120;
    F121:;
    if (!mo_is(L24, 0)) goto F122;
    L31 = L24.as.xs[0];
    if (!mo_is(L31, 7)) goto F122;
    goto E120;
    F122:;
    if (!mo_is(L24, 0)) goto F123;
    L32 = L24.as.xs[0];
    if (!mo_is(L32, 10)) goto F123;
    goto E120;
    F123:;
    if (!mo_is(L24, 0)) goto F124;
    L33 = L24.as.xs[0];
    if (!mo_is(L33, 11)) goto F124;
    goto E120;
    F124:;
    if (!mo_is(L24, 0)) goto F119;
    L34 = L24.as.xs[0];
    if (!mo_is(L34, 12)) goto F119;
    E120:;
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    MoValue t51 MO_U = L23.as.xs[0];
    MoValue t52 MO_U = L1.as.xs[0];
    MoValue t53 MO_U = L1.as.xs[1];
    SAVE_f27();
    uint64_t w54 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t55 MO_U = f44(t51, t52, t53, mo_str("conversation content is neither text nor a block array", 54));
    FR_.walking = false; if (mo_walks != w54) LOAD_f27();
    R = t55;
    goto X95;
    t32 = MO_NONE_V;
    goto E116;
    F119:;
    mo_crash(15);
    E116:;
    L35 = t32;
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    MoValue t56 MO_U = L35.as.xs[0];
    MoValue t57 MO_U = L1;
    MoValue t58 MO_U = L23.as.xs[1];
    MoValue t59 MO_U = L35.as.xs[1];
    SAVE_f27();
    uint64_t w60 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t61 MO_U = f29(t56, t57, t58, t59);
    FR_.walking = false; if (mo_walks != w60) LOAD_f27();
    R = t61;
    X95:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f27
#undef LOAD_f27
MO_U static MoValue f28(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("identity_of");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L3;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("id", 2)}, MO_KIND_NONE);
    L4 = t2;
    if (!mo_is(L4, 0)) goto F128;
    L5 = L4.as.xs[0];
    if (!mo_is(L5, 9)) goto F128;
    L6 = L5.as.xs[0];
    L7 = L6;
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L7;
    MoValue t5 MO_U = L7;
    MoValue t6 MO_U = mo_record(43, 3, (const MoValue[]){mo_str("provided", 8), t4, t5});
    MoValue t7 MO_U = mo_tuple(2, (const MoValue[]){t3, t6});
    t0 = t7;
    goto E127;
    F128:;
    if (!mo_is(L4, 1)) goto F129;
    MoValue t8 MO_U = L2;
    MoValue t9 MO_U = mo_concat(2, (const MoValue[]){mo_str("physical:", 9), t8});
    L8 = t9;
    mo_disown_in(L0);
    MoValue t10 MO_U = L0;
    MoValue t11 MO_U = L2;
    MoValue t12 MO_U = mo_concat(1, (const MoValue[]){t11});
    MoValue t13 MO_U = L8;
    MoValue t14 MO_U = mo_record(43, 3, (const MoValue[]){mo_str("physical", 8), t12, t13});
    MoValue t15 MO_U = mo_tuple(2, (const MoValue[]){t10, t14});
    t0 = t15;
    goto E127;
    F129:;
    if (!mo_is(L4, 0)) goto F132;
    L9 = L4.as.xs[0];
    if (!mo_is(L9, 7)) goto F132;
    goto E131;
    F132:;
    if (!mo_is(L4, 0)) goto F133;
    L10 = L4.as.xs[0];
    if (!mo_is(L10, 8)) goto F133;
    goto E131;
    F133:;
    if (!mo_is(L4, 0)) goto F134;
    L11 = L4.as.xs[0];
    if (!mo_is(L11, 10)) goto F134;
    goto E131;
    F134:;
    if (!mo_is(L4, 0)) goto F135;
    L12 = L4.as.xs[0];
    if (!mo_is(L12, 11)) goto F135;
    goto E131;
    F135:;
    if (!mo_is(L4, 0)) goto F130;
    L13 = L4.as.xs[0];
    if (!mo_is(L13, 12)) goto F130;
    E131:;
    MoValue t16 MO_U = L2;
    MoValue t17 MO_U = mo_concat(2, (const MoValue[]){mo_str("physical:", 9), t16});
    L14 = t17;
    MoValue t18 MO_U = L0;
    MoValue t19 MO_U = L1;
    MoValue t20 MO_U = L2;
    MoValue t21 MO_U = f44(t18, t19, t20, mo_str("message id is not a string", 26));
    MoValue t22 MO_U = L2;
    MoValue t23 MO_U = mo_concat(1, (const MoValue[]){t22});
    MoValue t24 MO_U = L14;
    MoValue t25 MO_U = mo_record(43, 3, (const MoValue[]){mo_str("physical", 8), t23, t24});
    MoValue t26 MO_U = mo_tuple(2, (const MoValue[]){t21, t25});
    t0 = t26;
    goto E127;
    F130:;
    mo_crash(16);
    E127:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a0(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("retain_message");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = mo_variant(54, 0, NULL);
    MoValue t2 MO_U = mo_bool(mo_compare(MO_EQ, t0, t1));
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f29() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = R; } while (0)
#define LOAD_f29() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; R = V_[18]; } while (0)
MO_U static MoValue f29(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("retain_message");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue V_[19];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 19, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L4 = t0;
    MoValue t1 MO_U = L3;
    MoValue t2 MO_U = mo_r_List_size((const MoValue[]){t1}, MO_KIND_NONE);
    MoValue t3 MO_U = mo_bool(t2.as.u == mo_i64(INT64_C(0)).as.u);
    if (t3.as.b) {
        mo_disown_in(L4);
        MoValue t4 MO_U = L4;
        R = t4;
        goto X137;
    }
    MoValue t5 MO_U = MO_NONE_V;
    MoValue t6 MO_U = L1.as.xs[3];
    MoValue t7 MO_U = mo_bool(mo_compare(MO_EQ, t6, mo_str("", 0)));
    if (t7.as.b) {
        MoValue t8 MO_U = L1.as.xs[0];
        MoValue t9 MO_U = mo_concat(2, (const MoValue[]){mo_str("file:", 5), t8});
        t5 = t9;
    } else {
        MoValue t10 MO_U = L1.as.xs[3];
        MoValue t11 MO_U = mo_concat(2, (const MoValue[]){mo_str("session:", 8), t10});
        t5 = t11;
    }
    L5 = t5;
    MoValue t12 MO_U = MO_NONE_V;
    MoValue t13 MO_U = L1.as.xs[3];
    MoValue t14 MO_U = mo_bool(mo_compare(MO_EQ, t13, mo_str("", 0)));
    if (t14.as.b) {
        MoValue t15 MO_U = L1.as.xs[0];
        MoValue t16 MO_U = mo_concat(3, (const MoValue[]){mo_str("(missing session id in ", 23), t15, mo_str(")", 1)});
        t12 = t16;
    } else {
        MoValue t17 MO_U = L1.as.xs[3];
        t12 = t17;
    }
    L6 = t12;
    MoValue t18 MO_U = L1.as.xs[0];
    MoValue t19 MO_U = L5;
    MoValue t20 MO_U = L1.as.xs[2];
    MoValue t21 MO_U = L2.as.xs[0];
    MoValue t22 MO_U = L2.as.xs[1];
    MoValue t23 MO_U = mo_tuple(5, (const MoValue[]){t18, t19, t20, t21, t22});
    MoValue t24 MO_U = mo_r_Json_encode((const MoValue[]){t23}, 0);
    L7 = t24;
    MoValue t25 MO_U = L4;
    MoValue t26 MO_U = t25.as.xs[0];
    MoValue t27 MO_U = L7;
    MoValue t28 MO_U = mo_r_Map_get((const MoValue[]){t26, t27}, MO_KIND_NONE);
    L8 = t28;
    mo_disown_in(L8);
    MoValue t29 MO_U = L8;
    L9 = t29;
    MoValue t30 MO_U = mo_bool(true);
    if (!mo_is(L9, 1)) goto F138;
    goto E139;
    F138:;
    t30 = mo_bool(false);
    E139:;
    MoValue t31 MO_U = mo_bool(false);
    if (t30.as.b) {
        MoValue t32 MO_U = L4;
        MoValue t33 MO_U = t32.as.xs[0];
        MoValue t34 MO_U = mo_r_Map_size((const MoValue[]){t33}, MO_KIND_NONE);
        MoValue t35 MO_U = f41(t34);
        MoValue t36 MO_U = mo_bool(!t35.as.b);
        t31 = t36;
    }
    if (t31.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f29(); mo_walk(&FR_); LOAD_f29(); }
        mo_disown_in(L4);
        MoValue t37 MO_U = L4;
        MoValue t38 MO_U = L1.as.xs[0];
        MoValue t39 MO_U = L1.as.xs[1];
        SAVE_f29();
        uint64_t w40 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t41 MO_U = f44(t37, t38, t39, mo_str("more than 100000 logical messages would be retained", 51));
        FR_.walking = false; if (mo_walks != w40) LOAD_f29();
        R = t41;
        goto X137;
    }
    MoValue t42 MO_U = f11();
    MoValue t43 MO_U = L4.as.xs[7];
    MoValue t44 MO_U = mo_r_Int_saturating_sub((const MoValue[]){t42, t43}, 7);
    L10 = t44;
    MoValue t45 MO_U = L3;
    MoValue t46 MO_U = L10;
    MoValue t47 MO_U = mo_r_List_take((const MoValue[]){t45, t46}, MO_KIND_NONE);
    L11 = t47;
    MoValue t48 MO_U = L11;
    MoValue t49 MO_U = mo_r_List_size((const MoValue[]){t48}, MO_KIND_NONE);
    MoValue t50 MO_U = L3;
    MoValue t51 MO_U = mo_r_List_size((const MoValue[]){t50}, MO_KIND_NONE);
    MoValue t52 MO_U = mo_bool(t49.as.u < t51.as.u);
    if (t52.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f29(); mo_walk(&FR_); LOAD_f29(); }
        MoValue t53 MO_U = L4;
        MoValue t54 MO_U = L1.as.xs[0];
        MoValue t55 MO_U = L1.as.xs[1];
        SAVE_f29();
        uint64_t w56 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t57 MO_U = f44(t53, t54, t55, mo_str("more than 500000 searchable blocks would be retained", 52));
        FR_.walking = false; if (mo_walks != w56) LOAD_f29();
        L4 = t57;
    }
    MoValue t58 MO_U = L4.as.xs[7];
    MoValue t59 MO_U = L11;
    MoValue t60 MO_U = mo_r_List_size((const MoValue[]){t59}, MO_KIND_NONE);
    MoValue t61 MO_U = mo_add_u64(t58, t60, 17);
    MoValue t62 MO_U = L4;
    MoValue t63 MO_U = mo_set_field(t62, 7, t61);
    L4 = t63;
    MoValue t64 MO_U = MO_NONE_V;
    MoValue t65 MO_U = L11;
    MoValue t66 MO_U = mo_closure(a0, 45, 0, NULL);
    MoValue t67 MO_U = mo_r_List_any_q((const MoValue[]){t65, t66}, MO_KIND_NONE);
    if (t67.as.b) {
        MoValue t68 MO_U = L1.as.xs[4];
        t64 = t68;
    } else {
        MoValue t69 MO_U = mo_variant(1, 0, NULL);
        t64 = t69;
    }
    L12 = t64;
    MoValue t70 MO_U = L8;
    L13 = t70;
    if (!mo_is(L13, 0)) goto F142;
    L14 = L13.as.xs[0];
    L15 = L14;
    MoValue t71 MO_U = L7;
    MoValue t72 MO_U = L5;
    MoValue t73 MO_U = L6;
    MoValue t74 MO_U = L1.as.xs[2];
    MoValue t75 MO_U = L2.as.xs[2];
    MoValue t76 MO_U = L1.as.xs[0];
    MoValue t77 MO_U = L15.as.xs[6];
    MoValue t78 MO_U = L15.as.xs[7];
    MoValue t79 MO_U = L12;
    MoValue t80 MO_U = f42(t78, t79);
    MoValue t81 MO_U = L15.as.xs[8];
    MoValue t82 MO_U = L11;
    MoValue t83 MO_U = mo_r_List_concat((const MoValue[]){t81, t82}, MO_KIND_NONE);
    MoValue t84 MO_U = mo_record(32, 9, (const MoValue[]){t71, t72, t73, t74, t75, t76, t77, t80, t83});
    L16 = t84;
    MoValue t85 MO_U = L4;
    MoValue t86 MO_U = t85.as.xs[0];
    MoValue t87 MO_U = L7;
    MoValue t88 MO_U = L16;
    mo_disown_in(t88);
    MoValue t89 MO_U = mo_r_Map_set((const MoValue[]){t86, t87, t88}, MO_KIND_UNIQUE);
    MoValue t90 MO_U = L4;
    MoValue t91 MO_U = mo_set_field(t90, 0, t89);
    L4 = t91;
    goto E141;
    F142:;
    if (!mo_is(L13, 1)) goto F143;
    MoValue t92 MO_U = L7;
    MoValue t93 MO_U = L5;
    MoValue t94 MO_U = L6;
    MoValue t95 MO_U = L1.as.xs[2];
    MoValue t96 MO_U = L2.as.xs[2];
    MoValue t97 MO_U = L1.as.xs[0];
    MoValue t98 MO_U = L1.as.xs[1];
    MoValue t99 MO_U = L12;
    MoValue t100 MO_U = L11;
    MoValue t101 MO_U = mo_record(32, 9, (const MoValue[]){t92, t93, t94, t95, t96, t97, t98, t99, t100});
    L17 = t101;
    MoValue t102 MO_U = L4;
    MoValue t103 MO_U = t102.as.xs[0];
    MoValue t104 MO_U = L7;
    MoValue t105 MO_U = L17;
    mo_disown_in(t105);
    MoValue t106 MO_U = mo_r_Map_set((const MoValue[]){t103, t104, t105}, MO_KIND_UNIQUE);
    MoValue t107 MO_U = L4;
    MoValue t108 MO_U = mo_set_field(t107, 0, t106);
    L4 = t108;
    goto E141;
    F143:;
    mo_crash(18);
    E141:;
    MoValue t109 MO_U = L4;
    R = t109;
    X137:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f29
#undef LOAD_f29
#define SAVE_f30() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = R; } while (0)
#define LOAD_f30() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; R = V_[9]; } while (0)
#define ROOTS_f30(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, R}; mo_compact(m, r_, 10); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; R = r_[9]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f30(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("blocks_of");
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    size_t m145 MO_U = 0, k145 MO_U = 0;
    MoValue V_[10];
    size_t *const M_[] = {&F_, &m145, &k145};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 10, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_record(41, 2, (const MoValue[]){t0, t1});
    L5 = t2;
    MoValue t3 MO_U = L4;
    MoValue t4 MO_U = mo_r_List_enumerate((const MoValue[]){t3}, MO_KIND_NONE);
    L6 = t4;
    {
        m145 = mo_mark(); k145 = 0;
        for (uint32_t i145 = 0; i145 < L6.aux; i145++) {
            MoValue t5 MO_U = L6.as.xs[i145];
            L7 = t5;
            if (mo_walk_due(&FR_)) { SAVE_f30(); mo_walk(&FR_); LOAD_f30(); }
            MoValue t6 MO_U = L5.as.xs[0];
            mo_disown_in(t6);
            MoValue t7 MO_U = L1;
            MoValue t8 MO_U = L2;
            MoValue t9 MO_U = L3;
            MoValue t10 MO_U = L7.as.xs[0];
            MoValue t11 MO_U = L7.as.xs[1];
            SAVE_f30();
            uint64_t w12 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t13 MO_U = f31(t6, t7, t8, t9, t10, t11);
            FR_.walking = false; if (mo_walks != w12) LOAD_f30();
            L8 = t13;
            MoValue t14 MO_U = L8.as.xs[0];
            MoValue t15 MO_U = L5;
            MoValue t16 MO_U = mo_set_field(t15, 0, t14);
            L5 = t16;
            MoValue t17 MO_U = L5.as.xs[1];
            MoValue t18 MO_U = L8.as.xs[1];
            MoValue t19 MO_U = mo_r_List_concat((const MoValue[]){t17, t18}, MO_KIND_NONE);
            MoValue t20 MO_U = L5;
            MoValue t21 MO_U = mo_set_field(t20, 1, t19);
            L5 = t21;
            ROOTS_f30(m145, k145);
        }
    }
    MoValue t22 MO_U = L5;
    R = t22;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f30
#undef SAVE_f30
#undef LOAD_f30
#define SAVE_f31() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = L18; V_[19] = L19; V_[20] = L20; V_[21] = L21; V_[22] = L22; V_[23] = L23; V_[24] = L24; V_[25] = L25; V_[26] = L26; V_[27] = L27; V_[28] = L28; V_[29] = L29; V_[30] = L30; V_[31] = L31; V_[32] = R; } while (0)
#define LOAD_f31() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; L18 = V_[18]; L19 = V_[19]; L20 = V_[20]; L21 = V_[21]; L22 = V_[22]; L23 = V_[23]; L24 = V_[24]; L25 = V_[25]; L26 = V_[26]; L27 = V_[27]; L28 = V_[28]; L29 = V_[29]; L30 = V_[30]; L31 = V_[31]; R = V_[32]; } while (0)
MO_U static MoValue f31(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("block_of");
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    MoValue L21 MO_U = MO_NONE_V;
    MoValue L22 MO_U = MO_NONE_V;
    MoValue L23 MO_U = MO_NONE_V;
    MoValue L24 MO_U = MO_NONE_V;
    MoValue L25 MO_U = MO_NONE_V;
    MoValue L26 MO_U = MO_NONE_V;
    MoValue L27 MO_U = MO_NONE_V;
    MoValue L28 MO_U = MO_NONE_V;
    MoValue L29 MO_U = MO_NONE_V;
    MoValue L30 MO_U = MO_NONE_V;
    MoValue L31 MO_U = MO_NONE_V;
    MoValue V_[33];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 33, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L5;
    L6 = t1;
    if (!mo_is(L6, 7)) goto F148;
    L7 = L6.as.xs[0];
    L8 = L7;
    MoValue t2 MO_U = L8;
    t0 = t2;
    goto E147;
    F148:;
    if (!mo_is(L6, 9)) goto F151;
    goto E150;
    F151:;
    if (!mo_is(L6, 8)) goto F152;
    goto E150;
    F152:;
    if (!mo_is(L6, 10)) goto F153;
    goto E150;
    F153:;
    if (!mo_is(L6, 11)) goto F154;
    goto E150;
    F154:;
    if (!mo_is(L6, 12)) goto F149;
    E150:;
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L2;
    MoValue t5 MO_U = L3;
    MoValue t6 MO_U = L4;
    MoValue t7 MO_U = mo_concat(3, (const MoValue[]){mo_str("content block ", 14), t6, mo_str(" is not an object", 17)});
    MoValue t8 MO_U = f44(t3, t4, t5, t7);
    MoValue t9 MO_U = mo_list_of(0, NULL);
    MoValue t10 MO_U = mo_record(41, 2, (const MoValue[]){t8, t9});
    R = t10;
    goto X146;
    t0 = MO_NONE_V;
    goto E147;
    F149:;
    mo_crash(19);
    E147:;
    L9 = t0;
    MoValue t11 MO_U = MO_NONE_V;
    MoValue t12 MO_U = L9;
    MoValue t13 MO_U = mo_r_Map_get((const MoValue[]){t12, mo_str("type", 4)}, MO_KIND_NONE);
    L10 = t13;
    if (!mo_is(L10, 0)) goto F157;
    L11 = L10.as.xs[0];
    if (!mo_is(L11, 9)) goto F157;
    L12 = L11.as.xs[0];
    L13 = L12;
    MoValue t14 MO_U = L13;
    t11 = t14;
    goto E156;
    F157:;
    if (!mo_is(L10, 1)) goto F160;
    goto E159;
    F160:;
    if (!mo_is(L10, 0)) goto F161;
    L14 = L10.as.xs[0];
    if (!mo_is(L14, 7)) goto F161;
    goto E159;
    F161:;
    if (!mo_is(L10, 0)) goto F162;
    L15 = L10.as.xs[0];
    if (!mo_is(L15, 8)) goto F162;
    goto E159;
    F162:;
    if (!mo_is(L10, 0)) goto F163;
    L16 = L10.as.xs[0];
    if (!mo_is(L16, 10)) goto F163;
    goto E159;
    F163:;
    if (!mo_is(L10, 0)) goto F164;
    L17 = L10.as.xs[0];
    if (!mo_is(L17, 11)) goto F164;
    goto E159;
    F164:;
    if (!mo_is(L10, 0)) goto F158;
    L18 = L10.as.xs[0];
    if (!mo_is(L18, 12)) goto F158;
    E159:;
    mo_disown_in(L0);
    MoValue t15 MO_U = L0;
    MoValue t16 MO_U = L2;
    MoValue t17 MO_U = L3;
    MoValue t18 MO_U = L4;
    MoValue t19 MO_U = mo_concat(3, (const MoValue[]){mo_str("content block ", 14), t18, mo_str(" has no string type", 19)});
    MoValue t20 MO_U = f44(t15, t16, t17, t19);
    MoValue t21 MO_U = mo_list_of(0, NULL);
    MoValue t22 MO_U = mo_record(41, 2, (const MoValue[]){t20, t21});
    R = t22;
    goto X146;
    t11 = MO_NONE_V;
    goto E156;
    F158:;
    mo_crash(20);
    E156:;
    L19 = t11;
    if (mo_walk_due(&FR_)) { SAVE_f31(); mo_walk(&FR_); LOAD_f31(); }
    MoValue t23 MO_U = L0;
    MoValue t24 MO_U = L2;
    MoValue t25 MO_U = L3;
    MoValue t26 MO_U = L4;
    mo_disown_in(L9);
    MoValue t27 MO_U = L9;
    SAVE_f31();
    uint64_t w28 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t29 MO_U = f37(t23, t24, t25, t26, t27);
    FR_.walking = false; if (mo_walks != w28) LOAD_f31();
    L20 = t29;
    MoValue t30 MO_U = L20.as.xs[0];
    L21 = t30;
    MoValue t31 MO_U = MO_NONE_V;
    MoValue t32 MO_U = L19;
    L22 = t32;
    if (!mo_equal(L22, mo_str("text", 4))) goto F167;
    MoValue t33 MO_U = MO_NONE_V;
    MoValue t34 MO_U = L9;
    MoValue t35 MO_U = mo_r_Map_get((const MoValue[]){t34, mo_str("text", 4)}, MO_KIND_NONE);
    L23 = t35;
    if (!mo_is(L23, 0)) goto F169;
    L24 = L23.as.xs[0];
    if (!mo_is(L24, 9)) goto F169;
    L25 = L24.as.xs[0];
    L26 = L25;
    mo_disown_in(L21);
    MoValue t36 MO_U = L21;
    MoValue t37 MO_U = L1;
    MoValue t38 MO_U = L26;
    MoValue t39 MO_U = L2;
    MoValue t40 MO_U = L3;
    MoValue t41 MO_U = L4;
    MoValue t42 MO_U = L20.as.xs[1];
    MoValue t43 MO_U = f32(t37, t38, t39, t40, t41, t42);
    mo_disown_in(t43);
    MoValue t44 MO_U = mo_list_of(1, (const MoValue[]){t43});
    MoValue t45 MO_U = mo_record(41, 2, (const MoValue[]){t36, t44});
    t33 = t45;
    goto E168;
    F169:;
    if (!mo_is(L23, 1)) goto F172;
    goto E171;
    F172:;
    if (!mo_is(L23, 0)) goto F173;
    L27 = L23.as.xs[0];
    if (!mo_is(L27, 7)) goto F173;
    goto E171;
    F173:;
    if (!mo_is(L23, 0)) goto F174;
    L28 = L23.as.xs[0];
    if (!mo_is(L28, 8)) goto F174;
    goto E171;
    F174:;
    if (!mo_is(L23, 0)) goto F175;
    L29 = L23.as.xs[0];
    if (!mo_is(L29, 10)) goto F175;
    goto E171;
    F175:;
    if (!mo_is(L23, 0)) goto F176;
    L30 = L23.as.xs[0];
    if (!mo_is(L30, 11)) goto F176;
    goto E171;
    F176:;
    if (!mo_is(L23, 0)) goto F170;
    L31 = L23.as.xs[0];
    if (!mo_is(L31, 12)) goto F170;
    E171:;
    mo_disown_in(L21);
    MoValue t46 MO_U = L21;
    MoValue t47 MO_U = L2;
    MoValue t48 MO_U = L3;
    MoValue t49 MO_U = L4;
    MoValue t50 MO_U = mo_concat(3, (const MoValue[]){mo_str("text block ", 11), t49, mo_str(" has no string text", 19)});
    MoValue t51 MO_U = f44(t46, t47, t48, t50);
    MoValue t52 MO_U = mo_list_of(0, NULL);
    MoValue t53 MO_U = mo_record(41, 2, (const MoValue[]){t51, t52});
    t33 = t53;
    goto E168;
    F170:;
    mo_crash(21);
    E168:;
    t31 = t33;
    goto E166;
    F167:;
    if (!mo_equal(L22, mo_str("thinking", 8))) goto F180;
    goto E179;
    F180:;
    if (!mo_equal(L22, mo_str("redacted_thinking", 17))) goto F181;
    goto E179;
    F181:;
    if (!mo_equal(L22, mo_str("image", 5))) goto F178;
    E179:;
    mo_disown_in(L21);
    MoValue t54 MO_U = L21;
    MoValue t55 MO_U = mo_list_of(0, NULL);
    MoValue t56 MO_U = mo_record(41, 2, (const MoValue[]){t54, t55});
    t31 = t56;
    goto E166;
    F178:;
    if (!mo_equal(L22, mo_str("tool_use", 8))) goto F183;
    if (mo_walk_due(&FR_)) { SAVE_f31(); mo_walk(&FR_); LOAD_f31(); }
    mo_disown_in(L21);
    MoValue t57 MO_U = L21;
    MoValue t58 MO_U = L2;
    MoValue t59 MO_U = L3;
    MoValue t60 MO_U = L4;
    MoValue t61 MO_U = L20.as.xs[1];
    mo_disown_in(L9);
    MoValue t62 MO_U = L9;
    SAVE_f31();
    uint64_t w63 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t64 MO_U = f33(t57, t58, t59, t60, t61, t62);
    FR_.walking = false; if (mo_walks != w63) LOAD_f31();
    t31 = t64;
    goto E166;
    F183:;
    if (!mo_equal(L22, mo_str("tool_result", 11))) goto F184;
    if (mo_walk_due(&FR_)) { SAVE_f31(); mo_walk(&FR_); LOAD_f31(); }
    mo_disown_in(L21);
    MoValue t65 MO_U = L21;
    MoValue t66 MO_U = L2;
    MoValue t67 MO_U = L3;
    MoValue t68 MO_U = L4;
    MoValue t69 MO_U = L20.as.xs[1];
    MoValue t70 MO_U = L9;
    SAVE_f31();
    uint64_t w71 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t72 MO_U = f34(t65, t66, t67, t68, t69, t70);
    FR_.walking = false; if (mo_walks != w71) LOAD_f31();
    t31 = t72;
    goto E166;
    F184:;
    MoValue t73 MO_U = L21;
    MoValue t74 MO_U = L2;
    MoValue t75 MO_U = L3;
    MoValue t76 MO_U = L19;
    MoValue t77 MO_U = mo_concat(2, (const MoValue[]){mo_str("unsupported conversation block type ", 36), t76});
    MoValue t78 MO_U = f44(t73, t74, t75, t77);
    MoValue t79 MO_U = mo_list_of(0, NULL);
    MoValue t80 MO_U = mo_record(41, 2, (const MoValue[]){t78, t79});
    t31 = t80;
    goto E166;
    mo_crash(22);
    E166:;
    R = t31;
    X146:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f31
#undef LOAD_f31
MO_U static MoValue f32(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("conversation_block");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_variant(54, 0, NULL);
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_concat(2, (const MoValue[]){t1, mo_str(" text", 5)});
    MoValue t3 MO_U = L1;
    MoValue t4 MO_U = L2;
    MoValue t5 MO_U = L3;
    MoValue t6 MO_U = L4;
    MoValue t7 MO_U = L5;
    MoValue t8 MO_U = mo_record(31, 7, (const MoValue[]){t0, t2, t3, t4, t5, t6, t7});
    R = t8;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f33(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("tool_use");
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L5;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("name", 4)}, MO_KIND_NONE);
    L6 = t2;
    if (!mo_is(L6, 0)) goto F189;
    L7 = L6.as.xs[0];
    if (!mo_is(L7, 9)) goto F189;
    L8 = L7.as.xs[0];
    L9 = L8;
    MoValue t3 MO_U = L9;
    t0 = t3;
    goto E188;
    F189:;
    if (!mo_is(L6, 1)) goto F192;
    goto E191;
    F192:;
    if (!mo_is(L6, 0)) goto F193;
    L10 = L6.as.xs[0];
    if (!mo_is(L10, 7)) goto F193;
    goto E191;
    F193:;
    if (!mo_is(L6, 0)) goto F194;
    L11 = L6.as.xs[0];
    if (!mo_is(L11, 8)) goto F194;
    goto E191;
    F194:;
    if (!mo_is(L6, 0)) goto F195;
    L12 = L6.as.xs[0];
    if (!mo_is(L12, 10)) goto F195;
    goto E191;
    F195:;
    if (!mo_is(L6, 0)) goto F196;
    L13 = L6.as.xs[0];
    if (!mo_is(L13, 11)) goto F196;
    goto E191;
    F196:;
    if (!mo_is(L6, 0)) goto F190;
    L14 = L6.as.xs[0];
    if (!mo_is(L14, 12)) goto F190;
    E191:;
    mo_disown_in(L0);
    MoValue t4 MO_U = L0;
    MoValue t5 MO_U = L1;
    MoValue t6 MO_U = L2;
    MoValue t7 MO_U = L3;
    MoValue t8 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool_use block ", 15), t7, mo_str(" has no string name", 19)});
    MoValue t9 MO_U = f44(t4, t5, t6, t8);
    MoValue t10 MO_U = mo_list_of(0, NULL);
    MoValue t11 MO_U = mo_record(41, 2, (const MoValue[]){t9, t10});
    R = t11;
    goto X187;
    t0 = MO_NONE_V;
    goto E188;
    F190:;
    mo_crash(23);
    E188:;
    L15 = t0;
    MoValue t12 MO_U = MO_NONE_V;
    MoValue t13 MO_U = L5;
    MoValue t14 MO_U = mo_r_Map_get((const MoValue[]){t13, mo_str("input", 5)}, MO_KIND_NONE);
    L16 = t14;
    if (!mo_is(L16, 0)) goto F199;
    L17 = L16.as.xs[0];
    L18 = L17;
    MoValue t15 MO_U = L18;
    t12 = t15;
    goto E198;
    F199:;
    if (!mo_is(L16, 1)) goto F200;
    mo_disown_in(L0);
    MoValue t16 MO_U = L0;
    MoValue t17 MO_U = L1;
    MoValue t18 MO_U = L2;
    MoValue t19 MO_U = L3;
    MoValue t20 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool_use block ", 15), t19, mo_str(" has no input", 13)});
    MoValue t21 MO_U = f44(t16, t17, t18, t20);
    MoValue t22 MO_U = mo_list_of(0, NULL);
    MoValue t23 MO_U = mo_record(41, 2, (const MoValue[]){t21, t22});
    R = t23;
    goto X187;
    t12 = MO_NONE_V;
    goto E198;
    F200:;
    mo_crash(24);
    E198:;
    L19 = t12;
    MoValue t24 MO_U = mo_variant(55, 0, NULL);
    MoValue t25 MO_U = L15;
    MoValue t26 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool ", 5), t25, mo_str(" arguments", 10)});
    MoValue t27 MO_U = L19;
    MoValue t28 MO_U = mo_r_Json_encode((const MoValue[]){t27}, 2);
    MoValue t29 MO_U = L1;
    MoValue t30 MO_U = L2;
    MoValue t31 MO_U = L3;
    MoValue t32 MO_U = L4;
    MoValue t33 MO_U = mo_record(31, 7, (const MoValue[]){t24, t26, t28, t29, t30, t31, t32});
    L20 = t33;
    MoValue t34 MO_U = L0;
    MoValue t35 MO_U = L20;
    mo_disown_in(t35);
    MoValue t36 MO_U = mo_list_of(1, (const MoValue[]){t35});
    MoValue t37 MO_U = mo_record(41, 2, (const MoValue[]){t34, t36});
    R = t37;
    X187:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f34() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = L16; V_[17] = L17; V_[18] = L18; V_[19] = L19; V_[20] = L20; V_[21] = L21; V_[22] = L22; V_[23] = L23; V_[24] = R; } while (0)
#define LOAD_f34() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; L16 = V_[16]; L17 = V_[17]; L18 = V_[18]; L19 = V_[19]; L20 = V_[20]; L21 = V_[21]; L22 = V_[22]; L23 = V_[23]; R = V_[24]; } while (0)
MO_U static MoValue f34(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4, MoValue L5) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("tool_result");
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    MoValue L21 MO_U = MO_NONE_V;
    MoValue L22 MO_U = MO_NONE_V;
    MoValue L23 MO_U = MO_NONE_V;
    MoValue V_[25];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 25, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L5;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("tool_use_id", 11)}, MO_KIND_NONE);
    L6 = t2;
    if (!mo_is(L6, 0)) goto F203;
    L7 = L6.as.xs[0];
    if (!mo_is(L7, 9)) goto F203;
    L8 = L7.as.xs[0];
    L9 = L8;
    MoValue t3 MO_U = L9;
    t0 = t3;
    goto E202;
    F203:;
    if (!mo_is(L6, 1)) goto F204;
    t0 = mo_str("unknown", 7);
    goto E202;
    F204:;
    if (!mo_is(L6, 0)) goto F205;
    mo_disown_in(L0);
    MoValue t4 MO_U = L0;
    MoValue t5 MO_U = L1;
    MoValue t6 MO_U = L2;
    MoValue t7 MO_U = L3;
    MoValue t8 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool_result block ", 18), t7, mo_str(" has a non-string tool_use_id", 29)});
    MoValue t9 MO_U = f44(t4, t5, t6, t8);
    MoValue t10 MO_U = mo_list_of(0, NULL);
    MoValue t11 MO_U = mo_record(41, 2, (const MoValue[]){t9, t10});
    R = t11;
    goto X201;
    t0 = MO_NONE_V;
    goto E202;
    F205:;
    mo_crash(25);
    E202:;
    L10 = t0;
    MoValue t12 MO_U = MO_NONE_V;
    MoValue t13 MO_U = L5;
    MoValue t14 MO_U = mo_r_Map_get((const MoValue[]){t13, mo_str("content", 7)}, MO_KIND_NONE);
    L11 = t14;
    if (!mo_is(L11, 0)) goto F207;
    L12 = L11.as.xs[0];
    if (!mo_is(L12, 9)) goto F207;
    L13 = L12.as.xs[0];
    L14 = L13;
    MoValue t15 MO_U = mo_variant(55, 0, NULL);
    MoValue t16 MO_U = L10;
    MoValue t17 MO_U = mo_concat(2, (const MoValue[]){mo_str("tool result ", 12), t16});
    MoValue t18 MO_U = L14;
    MoValue t19 MO_U = L1;
    MoValue t20 MO_U = L2;
    MoValue t21 MO_U = L3;
    MoValue t22 MO_U = L4;
    MoValue t23 MO_U = mo_record(31, 7, (const MoValue[]){t15, t17, t18, t19, t20, t21, t22});
    L15 = t23;
    mo_disown_in(L0);
    MoValue t24 MO_U = L0;
    MoValue t25 MO_U = L15;
    mo_disown_in(t25);
    MoValue t26 MO_U = mo_list_of(1, (const MoValue[]){t25});
    MoValue t27 MO_U = mo_record(41, 2, (const MoValue[]){t24, t26});
    t12 = t27;
    goto E206;
    F207:;
    if (!mo_is(L11, 0)) goto F208;
    L16 = L11.as.xs[0];
    if (!mo_is(L16, 8)) goto F208;
    L17 = L16.as.xs[0];
    L18 = L17;
    MoValue t28 MO_U = L1;
    MoValue t29 MO_U = L2;
    MoValue t30 MO_U = L3;
    MoValue t31 MO_U = L4;
    MoValue t32 MO_U = L10;
    MoValue t33 MO_U = mo_record(44, 5, (const MoValue[]){t28, t29, t30, t31, t32});
    L19 = t33;
    if (mo_walk_due(&FR_)) { SAVE_f34(); mo_walk(&FR_); LOAD_f34(); }
    mo_disown_in(L0);
    MoValue t34 MO_U = L0;
    MoValue t35 MO_U = L19;
    MoValue t36 MO_U = L18;
    SAVE_f34();
    uint64_t w37 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t38 MO_U = f35(t34, t35, t36);
    FR_.walking = false; if (mo_walks != w37) LOAD_f34();
    t12 = t38;
    goto E206;
    F208:;
    if (!mo_is(L11, 1)) goto F211;
    goto E210;
    F211:;
    if (!mo_is(L11, 0)) goto F212;
    L20 = L11.as.xs[0];
    if (!mo_is(L20, 7)) goto F212;
    goto E210;
    F212:;
    if (!mo_is(L11, 0)) goto F213;
    L21 = L11.as.xs[0];
    if (!mo_is(L21, 10)) goto F213;
    goto E210;
    F213:;
    if (!mo_is(L11, 0)) goto F214;
    L22 = L11.as.xs[0];
    if (!mo_is(L22, 11)) goto F214;
    goto E210;
    F214:;
    if (!mo_is(L11, 0)) goto F209;
    L23 = L11.as.xs[0];
    if (!mo_is(L23, 12)) goto F209;
    E210:;
    MoValue t39 MO_U = L0;
    MoValue t40 MO_U = L1;
    MoValue t41 MO_U = L2;
    MoValue t42 MO_U = L3;
    MoValue t43 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool_result block ", 18), t42, mo_str(" has unsupported content", 24)});
    MoValue t44 MO_U = f44(t39, t40, t41, t43);
    MoValue t45 MO_U = mo_list_of(0, NULL);
    MoValue t46 MO_U = mo_record(41, 2, (const MoValue[]){t44, t45});
    t12 = t46;
    goto E206;
    F209:;
    mo_crash(26);
    E206:;
    R = t12;
    X201:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f34
#undef LOAD_f34
#define SAVE_f35() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = R; } while (0)
#define LOAD_f35() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; R = V_[7]; } while (0)
#define ROOTS_f35(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, R}; mo_compact(m, r_, 8); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; R = r_[7]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f35(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("result_parts");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    size_t m217 MO_U = 0, k217 MO_U = 0;
    MoValue V_[8];
    size_t *const M_[] = {&F_, &m217, &k217};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 8, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_record(41, 2, (const MoValue[]){t0, t1});
    L3 = t2;
    MoValue t3 MO_U = L2;
    MoValue t4 MO_U = mo_r_List_enumerate((const MoValue[]){t3}, MO_KIND_NONE);
    L4 = t4;
    {
        m217 = mo_mark(); k217 = 0;
        for (uint32_t i217 = 0; i217 < L4.aux; i217++) {
            MoValue t5 MO_U = L4.as.xs[i217];
            L5 = t5;
            if (mo_walk_due(&FR_)) { SAVE_f35(); mo_walk(&FR_); LOAD_f35(); }
            MoValue t6 MO_U = L3.as.xs[0];
            mo_disown_in(t6);
            mo_disown_in(L1);
            MoValue t7 MO_U = L1;
            MoValue t8 MO_U = L5.as.xs[0];
            MoValue t9 MO_U = L5.as.xs[1];
            SAVE_f35();
            uint64_t w10 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t11 MO_U = f36(t6, t7, t8, t9);
            FR_.walking = false; if (mo_walks != w10) LOAD_f35();
            L6 = t11;
            MoValue t12 MO_U = L6.as.xs[0];
            MoValue t13 MO_U = L3;
            MoValue t14 MO_U = mo_set_field(t13, 0, t12);
            L3 = t14;
            MoValue t15 MO_U = L3.as.xs[1];
            MoValue t16 MO_U = L6.as.xs[1];
            MoValue t17 MO_U = mo_r_List_concat((const MoValue[]){t15, t16}, MO_KIND_NONE);
            MoValue t18 MO_U = L3;
            MoValue t19 MO_U = mo_set_field(t18, 1, t17);
            L3 = t19;
            ROOTS_f35(m217, k217);
        }
    }
    MoValue t20 MO_U = L3;
    R = t20;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f35
#undef SAVE_f35
#undef LOAD_f35
MO_U static MoValue f36(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("result_part");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    MoValue L19 MO_U = MO_NONE_V;
    MoValue L20 MO_U = MO_NONE_V;
    MoValue L21 MO_U = MO_NONE_V;
    MoValue L22 MO_U = MO_NONE_V;
    MoValue L23 MO_U = MO_NONE_V;
    MoValue L24 MO_U = MO_NONE_V;
    MoValue L25 MO_U = MO_NONE_V;
    MoValue L26 MO_U = MO_NONE_V;
    MoValue L27 MO_U = MO_NONE_V;
    MoValue L28 MO_U = MO_NONE_V;
    MoValue L29 MO_U = MO_NONE_V;
    MoValue L30 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L3;
    L4 = t1;
    if (!mo_is(L4, 7)) goto F220;
    L5 = L4.as.xs[0];
    L6 = L5;
    MoValue t2 MO_U = L6;
    t0 = t2;
    goto E219;
    F220:;
    if (!mo_is(L4, 9)) goto F223;
    goto E222;
    F223:;
    if (!mo_is(L4, 8)) goto F224;
    goto E222;
    F224:;
    if (!mo_is(L4, 10)) goto F225;
    goto E222;
    F225:;
    if (!mo_is(L4, 11)) goto F226;
    goto E222;
    F226:;
    if (!mo_is(L4, 12)) goto F221;
    E222:;
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = L1.as.xs[0];
    MoValue t5 MO_U = L1.as.xs[1];
    MoValue t6 MO_U = L2;
    MoValue t7 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool result part ", 17), t6, mo_str(" is not an object", 17)});
    MoValue t8 MO_U = f44(t3, t4, t5, t7);
    MoValue t9 MO_U = mo_list_of(0, NULL);
    MoValue t10 MO_U = mo_record(41, 2, (const MoValue[]){t8, t9});
    R = t10;
    goto X218;
    t0 = MO_NONE_V;
    goto E219;
    F221:;
    mo_crash(27);
    E219:;
    L7 = t0;
    MoValue t11 MO_U = MO_NONE_V;
    MoValue t12 MO_U = L7;
    MoValue t13 MO_U = mo_r_Map_get((const MoValue[]){t12, mo_str("type", 4)}, MO_KIND_NONE);
    L8 = t13;
    if (!mo_is(L8, 0)) goto F229;
    L9 = L8.as.xs[0];
    if (!mo_is(L9, 9)) goto F229;
    L10 = L9.as.xs[0];
    if (!mo_equal(L10, mo_str("text", 4))) goto F229;
    MoValue t14 MO_U = MO_NONE_V;
    MoValue t15 MO_U = L7;
    MoValue t16 MO_U = mo_r_Map_get((const MoValue[]){t15, mo_str("text", 4)}, MO_KIND_NONE);
    L11 = t16;
    if (!mo_is(L11, 0)) goto F231;
    L12 = L11.as.xs[0];
    if (!mo_is(L12, 9)) goto F231;
    L13 = L12.as.xs[0];
    L14 = L13;
    MoValue t17 MO_U = mo_variant(55, 0, NULL);
    MoValue t18 MO_U = L1.as.xs[4];
    MoValue t19 MO_U = L2;
    MoValue t20 MO_U = mo_concat(4, (const MoValue[]){mo_str("tool result ", 12), t18, mo_str(" part ", 6), t19});
    MoValue t21 MO_U = L14;
    MoValue t22 MO_U = L1.as.xs[0];
    MoValue t23 MO_U = L1.as.xs[1];
    MoValue t24 MO_U = L1.as.xs[2];
    MoValue t25 MO_U = L1.as.xs[3];
    MoValue t26 MO_U = mo_record(31, 7, (const MoValue[]){t17, t20, t21, t22, t23, t24, t25});
    L15 = t26;
    mo_disown_in(L0);
    MoValue t27 MO_U = L0;
    MoValue t28 MO_U = L15;
    mo_disown_in(t28);
    MoValue t29 MO_U = mo_list_of(1, (const MoValue[]){t28});
    MoValue t30 MO_U = mo_record(41, 2, (const MoValue[]){t27, t29});
    t14 = t30;
    goto E230;
    F231:;
    if (!mo_is(L11, 1)) goto F234;
    goto E233;
    F234:;
    if (!mo_is(L11, 0)) goto F235;
    L16 = L11.as.xs[0];
    if (!mo_is(L16, 7)) goto F235;
    goto E233;
    F235:;
    if (!mo_is(L11, 0)) goto F236;
    L17 = L11.as.xs[0];
    if (!mo_is(L17, 8)) goto F236;
    goto E233;
    F236:;
    if (!mo_is(L11, 0)) goto F237;
    L18 = L11.as.xs[0];
    if (!mo_is(L18, 10)) goto F237;
    goto E233;
    F237:;
    if (!mo_is(L11, 0)) goto F238;
    L19 = L11.as.xs[0];
    if (!mo_is(L19, 11)) goto F238;
    goto E233;
    F238:;
    if (!mo_is(L11, 0)) goto F232;
    L20 = L11.as.xs[0];
    if (!mo_is(L20, 12)) goto F232;
    E233:;
    mo_disown_in(L0);
    MoValue t31 MO_U = L0;
    MoValue t32 MO_U = L1.as.xs[0];
    MoValue t33 MO_U = L1.as.xs[1];
    MoValue t34 MO_U = L2;
    MoValue t35 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool result text part ", 22), t34, mo_str(" has no string text", 19)});
    MoValue t36 MO_U = f44(t31, t32, t33, t35);
    MoValue t37 MO_U = mo_list_of(0, NULL);
    MoValue t38 MO_U = mo_record(41, 2, (const MoValue[]){t36, t37});
    t14 = t38;
    goto E230;
    F232:;
    mo_crash(28);
    E230:;
    t11 = t14;
    goto E228;
    F229:;
    if (!mo_is(L8, 0)) goto F240;
    L21 = L8.as.xs[0];
    if (!mo_is(L21, 9)) goto F240;
    L22 = L21.as.xs[0];
    if (!mo_equal(L22, mo_str("image", 5))) goto F240;
    mo_disown_in(L0);
    MoValue t39 MO_U = L0;
    MoValue t40 MO_U = mo_list_of(0, NULL);
    MoValue t41 MO_U = mo_record(41, 2, (const MoValue[]){t39, t40});
    t11 = t41;
    goto E228;
    F240:;
    if (!mo_is(L8, 0)) goto F241;
    L23 = L8.as.xs[0];
    if (!mo_is(L23, 9)) goto F241;
    L24 = L23.as.xs[0];
    L25 = L24;
    mo_disown_in(L0);
    MoValue t42 MO_U = L0;
    MoValue t43 MO_U = L1.as.xs[0];
    MoValue t44 MO_U = L1.as.xs[1];
    MoValue t45 MO_U = L25;
    MoValue t46 MO_U = mo_concat(2, (const MoValue[]){mo_str("unsupported tool result part type ", 34), t45});
    MoValue t47 MO_U = f44(t42, t43, t44, t46);
    MoValue t48 MO_U = mo_list_of(0, NULL);
    MoValue t49 MO_U = mo_record(41, 2, (const MoValue[]){t47, t48});
    t11 = t49;
    goto E228;
    F241:;
    if (!mo_is(L8, 1)) goto F244;
    goto E243;
    F244:;
    if (!mo_is(L8, 0)) goto F245;
    L26 = L8.as.xs[0];
    if (!mo_is(L26, 7)) goto F245;
    goto E243;
    F245:;
    if (!mo_is(L8, 0)) goto F246;
    L27 = L8.as.xs[0];
    if (!mo_is(L27, 8)) goto F246;
    goto E243;
    F246:;
    if (!mo_is(L8, 0)) goto F247;
    L28 = L8.as.xs[0];
    if (!mo_is(L28, 10)) goto F247;
    goto E243;
    F247:;
    if (!mo_is(L8, 0)) goto F248;
    L29 = L8.as.xs[0];
    if (!mo_is(L29, 11)) goto F248;
    goto E243;
    F248:;
    if (!mo_is(L8, 0)) goto F242;
    L30 = L8.as.xs[0];
    if (!mo_is(L30, 12)) goto F242;
    E243:;
    MoValue t50 MO_U = L0;
    MoValue t51 MO_U = L1.as.xs[0];
    MoValue t52 MO_U = L1.as.xs[1];
    MoValue t53 MO_U = L2;
    MoValue t54 MO_U = mo_concat(3, (const MoValue[]){mo_str("tool result part ", 17), t53, mo_str(" has no string type", 19)});
    MoValue t55 MO_U = f44(t50, t51, t52, t54);
    MoValue t56 MO_U = mo_list_of(0, NULL);
    MoValue t57 MO_U = mo_record(41, 2, (const MoValue[]){t55, t56});
    t11 = t57;
    goto E228;
    F242:;
    mo_crash(29);
    E228:;
    R = t11;
    X218:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f37(MoValue L0, MoValue L1, MoValue L2, MoValue L3, MoValue L4) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("api_index");
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L4;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t1, mo_str("apiBlockIndex", 13)}, MO_KIND_NONE);
    L5 = t2;
    if (!mo_is(L5, 1)) goto F252;
    mo_disown_in(L0);
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = mo_variant(1, 0, NULL);
    MoValue t5 MO_U = mo_tuple(2, (const MoValue[]){t3, t4});
    t0 = t5;
    goto E251;
    F252:;
    if (!mo_is(L5, 0)) goto F253;
    L6 = L5.as.xs[0];
    L7 = L6;
    MoValue t6 MO_U = MO_NONE_V;
    MoValue t7 MO_U = L7;
    MoValue t8 MO_U = mo_r_Json_to_i64((const MoValue[]){t7}, MO_KIND_NONE);
    L8 = t8;
    if (!mo_is(L8, 0)) goto F255;
    L9 = L8.as.xs[0];
    L10 = L9;
    MoValue t9 MO_U = MO_NONE_V;
    MoValue t10 MO_U = L10;
    MoValue t11 MO_U = mo_bool(t10.as.i >= mo_i64(INT64_C(0)).as.i);
    if (t11.as.b) {
        mo_disown_in(L0);
        MoValue t12 MO_U = L0;
        MoValue t13 MO_U = L10;
        MoValue t14 MO_U = mo_r_Int_to_u64((const MoValue[]){t13}, 3);
        MoValue t15 MO_U = mo_variant(0, 1, (const MoValue[]){t14});
        MoValue t16 MO_U = mo_tuple(2, (const MoValue[]){t12, t15});
        t9 = t16;
    } else {
        mo_disown_in(L0);
        MoValue t17 MO_U = L0;
        MoValue t18 MO_U = L1;
        MoValue t19 MO_U = L2;
        MoValue t20 MO_U = L3;
        MoValue t21 MO_U = mo_concat(3, (const MoValue[]){mo_str("apiBlockIndex on block ", 23), t20, mo_str(" is negative", 12)});
        MoValue t22 MO_U = f44(t17, t18, t19, t21);
        MoValue t23 MO_U = mo_variant(1, 0, NULL);
        MoValue t24 MO_U = mo_tuple(2, (const MoValue[]){t22, t23});
        t9 = t24;
    }
    t6 = t9;
    goto E254;
    F255:;
    if (!mo_is(L8, 1)) goto F256;
    MoValue t25 MO_U = L0;
    MoValue t26 MO_U = L1;
    MoValue t27 MO_U = L2;
    MoValue t28 MO_U = L3;
    MoValue t29 MO_U = mo_concat(3, (const MoValue[]){mo_str("apiBlockIndex on block ", 23), t28, mo_str(" is not a whole integer", 23)});
    MoValue t30 MO_U = f44(t25, t26, t27, t29);
    MoValue t31 MO_U = mo_variant(1, 0, NULL);
    MoValue t32 MO_U = mo_tuple(2, (const MoValue[]){t30, t31});
    t6 = t32;
    goto E254;
    F256:;
    mo_crash(30);
    E254:;
    t0 = t6;
    goto E251;
    F253:;
    mo_crash(31);
    E251:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f38(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("marked\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1;
    MoValue t2 MO_U = mo_r_Map_get((const MoValue[]){t0, t1}, MO_KIND_NONE);
    MoValue t3 MO_U = mo_variant(11, 1, (const MoValue[]){mo_bool(true)});
    MoValue t4 MO_U = mo_variant(0, 1, (const MoValue[]){t3});
    MoValue t5 MO_U = mo_bool(mo_compare(MO_EQ, t2, t4));
    R = t5;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f39(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_record_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f8();
    MoValue t2 MO_U = mo_bool(t0.as.u < t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f40(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("record_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f9();
    MoValue t2 MO_U = mo_bool(t0.as.u < t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f41(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("message_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f10();
    MoValue t2 MO_U = mo_bool(t0.as.u < t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f42(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("later");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = L1;
    MoValue t3 MO_U = mo_tuple(2, (const MoValue[]){t1, t2});
    L2 = t3;
    L3 = L2.as.xs[0];
    if (!mo_is(L3, 0)) goto F263;
    L4 = L3.as.xs[0];
    L5 = L4;
    L6 = L2.as.xs[1];
    if (!mo_is(L6, 0)) goto F263;
    L7 = L6.as.xs[0];
    L8 = L7;
    MoValue t4 MO_U = L5;
    MoValue t5 MO_U = L8;
    MoValue t6 MO_U = mo_r_max_of((const MoValue[]){t4, t5}, MO_KIND_NONE);
    MoValue t7 MO_U = mo_variant(0, 1, (const MoValue[]){t6});
    t0 = t7;
    goto E262;
    F263:;
    L9 = L2.as.xs[0];
    if (!mo_is(L9, 0)) goto F264;
    L10 = L9.as.xs[0];
    L11 = L10;
    L12 = L2.as.xs[1];
    if (!mo_is(L12, 1)) goto F264;
    MoValue t8 MO_U = L11;
    MoValue t9 MO_U = mo_variant(0, 1, (const MoValue[]){t8});
    t0 = t9;
    goto E262;
    F264:;
    L13 = L2.as.xs[0];
    if (!mo_is(L13, 1)) goto F265;
    L14 = L2.as.xs[1];
    if (!mo_is(L14, 0)) goto F265;
    L15 = L14.as.xs[0];
    L16 = L15;
    MoValue t10 MO_U = L16;
    MoValue t11 MO_U = mo_variant(0, 1, (const MoValue[]){t10});
    t0 = t11;
    goto E262;
    F265:;
    L17 = L2.as.xs[0];
    if (!mo_is(L17, 1)) goto F266;
    L18 = L2.as.xs[1];
    if (!mo_is(L18, 1)) goto F266;
    MoValue t12 MO_U = mo_variant(1, 0, NULL);
    t0 = t12;
    goto E262;
    F266:;
    mo_crash(32);
    E262:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a1(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("unknown");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_Int_saturating_add((const MoValue[]){t0, mo_i64(INT64_C(1))}, 7);
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a2(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("unknown");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_Int_saturating_add((const MoValue[]){t0, mo_i64(INT64_C(1))}, 7);
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f43(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("unknown");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L2 = t0;
    MoValue t1 MO_U = MO_NONE_V;
    MoValue t2 MO_U = L1;
    MoValue t3 MO_U = mo_r_String_size((const MoValue[]){t2}, MO_KIND_NONE);
    MoValue t4 MO_U = mo_bool(t3.as.u <= mo_i64(INT64_C(128)).as.u);
    if (t4.as.b) {
        MoValue t5 MO_U = L1;
        t1 = t5;
    } else {
        MoValue t6 MO_U = L1;
        MoValue t7 MO_U = mo_r_String_slice((const MoValue[]){t6, mo_i64(INT64_C(0)), mo_i64(INT64_C(128))}, MO_KIND_NONE);
        MoValue t8 MO_U = mo_concat(2, (const MoValue[]){t7, mo_str("...", 3)});
        t1 = t8;
    }
    L3 = t1;
    MoValue t9 MO_U = L2;
    MoValue t10 MO_U = t9.as.xs[2];
    MoValue t11 MO_U = L3;
    MoValue t12 MO_U = mo_r_Map_has_q((const MoValue[]){t10, t11}, MO_KIND_NONE);
    if (t12.as.b) {
        MoValue t13 MO_U = L2;
        MoValue t14 MO_U = t13.as.xs[2];
        MoValue t15 MO_U = L3;
        MoValue t16 MO_U = mo_closure(a1, 46, 0, NULL);
        MoValue t17 MO_U = mo_r_Map_update((const MoValue[]){t14, t15, mo_i64(INT64_C(0)), t16}, MO_KIND_UNIQUE);
        MoValue t18 MO_U = L2;
        MoValue t19 MO_U = mo_set_field(t18, 2, t17);
        L2 = t19;
    } else {
        MoValue t20 MO_U = L2;
        MoValue t21 MO_U = t20.as.xs[2];
        MoValue t22 MO_U = mo_r_Map_size((const MoValue[]){t21}, MO_KIND_NONE);
        MoValue t23 MO_U = f13();
        MoValue t24 MO_U = mo_r_Int_saturating_sub((const MoValue[]){t23, mo_i64(INT64_C(1))}, 7);
        MoValue t25 MO_U = mo_bool(t22.as.u < t24.as.u);
        if (t25.as.b) {
            MoValue t26 MO_U = L2;
            MoValue t27 MO_U = t26.as.xs[2];
            MoValue t28 MO_U = L3;
            MoValue t29 MO_U = mo_r_Map_set((const MoValue[]){t27, t28, mo_i64(INT64_C(1))}, MO_KIND_UNIQUE);
            MoValue t30 MO_U = L2;
            MoValue t31 MO_U = mo_set_field(t30, 2, t29);
            L2 = t31;
        } else {
            MoValue t32 MO_U = L2;
            MoValue t33 MO_U = t32.as.xs[2];
            MoValue t34 MO_U = mo_closure(a2, 47, 0, NULL);
            MoValue t35 MO_U = mo_r_Map_update((const MoValue[]){t33, mo_str("<additional kinds>", 18), mo_i64(INT64_C(0)), t34}, MO_KIND_UNIQUE);
            MoValue t36 MO_U = L2;
            MoValue t37 MO_U = mo_set_field(t36, 2, t35);
            L2 = t37;
        }
    }
    MoValue t38 MO_U = L2;
    R = t38;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f44(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("problem");
    MoValue L4 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L4 = t0;
    MoValue t1 MO_U = L4;
    MoValue t2 MO_U = mo_set_field(t1, 8, mo_bool(true));
    L4 = t2;
    MoValue t3 MO_U = L4.as.xs[1];
    MoValue t4 MO_U = mo_r_List_size((const MoValue[]){t3}, MO_KIND_NONE);
    MoValue t5 MO_U = f13();
    MoValue t6 MO_U = mo_bool(t4.as.u < t5.as.u);
    if (t6.as.b) {
        MoValue t7 MO_U = L4.as.xs[1];
        MoValue t8 MO_U = L1;
        MoValue t9 MO_U = L2;
        MoValue t10 MO_U = L3;
        MoValue t11 MO_U = mo_record(34, 3, (const MoValue[]){t8, t9, t10});
        mo_disown_in(t11);
        MoValue t12 MO_U = mo_r_List_push((const MoValue[]){t7, t11}, MO_KIND_NONE);
        MoValue t13 MO_U = L4;
        MoValue t14 MO_U = mo_set_field(t13, 1, t12);
        L4 = t14;
    }
    MoValue t15 MO_U = L4;
    R = t15;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_test0() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = R; } while (0)
#define LOAD_test0() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; R = V_[4]; } while (0)
MO_U static MoValue test0(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("decoded UUID equality ignores object order and JSON spelling");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue V_[5];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 5, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    L0 = mo_str("{\"type\":\"user\",\"uuid\":\"u\",\"message\":{\"role\":\"user\",\"id\":\"m\",\"content\":\"a\"}}", 75);
    L1 = mo_str("{\"message\":{\"content\":\"\\u0061\",\"id\":\"m\",\"role\":\"user\"},\"uuid\":\"u\",\"type\":\"user\"}", 80);
    if (mo_walk_due(&FR_)) { SAVE_test0(); mo_walk(&FR_); LOAD_test0(); }
    MoValue t0 MO_U = f18();
    MoValue t1 MO_U = f20(t0, mo_str("one.jsonl", 9), mo_i64(INT64_C(10000)));
    MoValue t2 MO_U = L0;
    SAVE_test0();
    uint64_t w3 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t4 MO_U = f21(t1, t2);
    FR_.walking = false; if (mo_walks != w3) LOAD_test0();
    L2 = t4;
    if (mo_walk_due(&FR_)) { SAVE_test0(); mo_walk(&FR_); LOAD_test0(); }
    MoValue t5 MO_U = L2;
    MoValue t6 MO_U = L1;
    SAVE_test0();
    uint64_t w7 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t8 MO_U = f21(t5, t6);
    FR_.walking = false; if (mo_walks != w7) LOAD_test0();
    L3 = t8;
    MoValue t9 MO_U = L3;
    MoValue t10 MO_U = t9.as.xs[0];
    MoValue t11 MO_U = t10.as.xs[0];
    MoValue t12 MO_U = mo_r_Map_size((const MoValue[]){t11}, MO_KIND_NONE);
    MoValue t13 MO_U = mo_bool(t12.as.u == mo_i64(INT64_C(1)).as.u);
    MoValue t14 MO_U = mo_bool(false);
    if (t13.as.b) {
        MoValue t15 MO_U = L3.as.xs[0];
        MoValue t16 MO_U = t15.as.xs[8];
        MoValue t17 MO_U = mo_bool(!t16.as.b);
        t14 = t17;
    }
    MoValue t18 MO_U = mo_bool(false);
    if (t14.as.b) {
        MoValue t19 MO_U = L3.as.xs[0];
        MoValue t20 MO_U = t19.as.xs[6];
        MoValue t21 MO_U = mo_bool(t20.as.u == mo_i64(INT64_C(2)).as.u);
        t18 = t21;
    }
    if (!t18.as.b) mo_crash(33);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_test0
#undef LOAD_test0
#define SAVE_test1() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = R; } while (0)
#define LOAD_test1() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; R = V_[6]; } while (0)
MO_U static MoValue test1(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file-local UUID state resets and malformed middle input retains neighboring messages");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue V_[7];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 7, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    L0 = mo_str("{\"type\":\"user\",\"uuid\":\"u\",\"message\":{\"role\":\"user\",\"id\":\"a\",\"content\":\"before\"}}", 80);
    L1 = mo_str("{\"type\":\"user\",\"uuid\":\"v\",\"message\":{\"role\":\"user\",\"id\":\"b\",\"content\":\"after\"}}", 79);
    if (mo_walk_due(&FR_)) { SAVE_test1(); mo_walk(&FR_); LOAD_test1(); }
    MoValue t0 MO_U = f18();
    MoValue t1 MO_U = f20(t0, mo_str("one.jsonl", 9), mo_i64(INT64_C(10000)));
    MoValue t2 MO_U = L0;
    SAVE_test1();
    uint64_t w3 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t4 MO_U = f21(t1, t2);
    FR_.walking = false; if (mo_walks != w3) LOAD_test1();
    L2 = t4;
    if (mo_walk_due(&FR_)) { SAVE_test1(); mo_walk(&FR_); LOAD_test1(); }
    MoValue t5 MO_U = L2;
    SAVE_test1();
    uint64_t w6 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t7 MO_U = f21(t5, mo_str("{", 1));
    FR_.walking = false; if (mo_walks != w6) LOAD_test1();
    L3 = t7;
    if (mo_walk_due(&FR_)) { SAVE_test1(); mo_walk(&FR_); LOAD_test1(); }
    MoValue t8 MO_U = L3;
    MoValue t9 MO_U = L1;
    SAVE_test1();
    uint64_t w10 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t11 MO_U = f21(t8, t9);
    FR_.walking = false; if (mo_walks != w10) LOAD_test1();
    L4 = t11;
    MoValue t12 MO_U = L4;
    MoValue t13 MO_U = t12.as.xs[0];
    MoValue t14 MO_U = t13.as.xs[0];
    MoValue t15 MO_U = mo_r_Map_size((const MoValue[]){t14}, MO_KIND_NONE);
    MoValue t16 MO_U = mo_bool(t15.as.u == mo_i64(INT64_C(2)).as.u);
    MoValue t17 MO_U = mo_bool(false);
    if (t16.as.b) {
        MoValue t18 MO_U = L4.as.xs[0];
        MoValue t19 MO_U = t18.as.xs[8];
        t17 = t19;
    }
    MoValue t20 MO_U = mo_bool(false);
    if (t17.as.b) {
        MoValue t21 MO_U = L4.as.xs[0];
        MoValue t22 MO_U = t21.as.xs[6];
        MoValue t23 MO_U = mo_bool(t22.as.u == mo_i64(INT64_C(3)).as.u);
        t20 = t23;
    }
    if (!t20.as.b) mo_crash(34);
    if (mo_walk_due(&FR_)) { SAVE_test1(); mo_walk(&FR_); LOAD_test1(); }
    MoValue t24 MO_U = L4.as.xs[0];
    MoValue t25 MO_U = f20(t24, mo_str("two.jsonl", 9), mo_i64(INT64_C(10000)));
    MoValue t26 MO_U = L0;
    SAVE_test1();
    uint64_t w27 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t28 MO_U = f21(t25, t26);
    FR_.walking = false; if (mo_walks != w27) LOAD_test1();
    L5 = t28;
    MoValue t29 MO_U = L5;
    MoValue t30 MO_U = t29.as.xs[0];
    MoValue t31 MO_U = t30.as.xs[0];
    MoValue t32 MO_U = mo_r_Map_size((const MoValue[]){t31}, MO_KIND_NONE);
    if (!mo_compare(MO_EQ, t32, mo_i64(INT64_C(3)))) mo_crash_values(35, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t32, mo_i64(INT64_C(3))});
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_test1
#undef LOAD_test1
#define SAVE_test2() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = R; } while (0)
#define LOAD_test2() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; R = V_[5]; } while (0)
MO_U static MoValue test2(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("replacement characters and conflicting payloads preserve first results but are incomplete");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue V_[6];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 6, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    L0 = mo_str("{\"type\":\"user\",\"uuid\":\"u\",\"message\":{\"role\":\"user\",\"id\":\"m\",\"content\":\"kept\"}}", 78);
    L1 = mo_str("{\"type\":\"user\",\"uuid\":\"u\",\"message\":{\"role\":\"user\",\"id\":\"m\",\"content\":\"changed\"}}", 81);
    if (mo_walk_due(&FR_)) { SAVE_test2(); mo_walk(&FR_); LOAD_test2(); }
    MoValue t0 MO_U = f18();
    MoValue t1 MO_U = f20(t0, mo_str("one.jsonl", 9), mo_i64(INT64_C(10000)));
    MoValue t2 MO_U = L0;
    SAVE_test2();
    uint64_t w3 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t4 MO_U = f21(t1, t2);
    FR_.walking = false; if (mo_walks != w3) LOAD_test2();
    L2 = t4;
    if (mo_walk_due(&FR_)) { SAVE_test2(); mo_walk(&FR_); LOAD_test2(); }
    MoValue t5 MO_U = L2;
    MoValue t6 MO_U = L1;
    SAVE_test2();
    uint64_t w7 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t8 MO_U = f21(t5, t6);
    FR_.walking = false; if (mo_walks != w7) LOAD_test2();
    L3 = t8;
    if (mo_walk_due(&FR_)) { SAVE_test2(); mo_walk(&FR_); LOAD_test2(); }
    MoValue t9 MO_U = L3;
    SAVE_test2();
    uint64_t w10 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t11 MO_U = f21(t9, mo_str("{\"type\":\"progress\",\"text\":\"\357\277\275\"}", 32));
    FR_.walking = false; if (mo_walks != w10) LOAD_test2();
    L4 = t11;
    MoValue t12 MO_U = L4;
    MoValue t13 MO_U = t12.as.xs[0];
    MoValue t14 MO_U = t13.as.xs[0];
    MoValue t15 MO_U = mo_r_Map_size((const MoValue[]){t14}, MO_KIND_NONE);
    MoValue t16 MO_U = mo_bool(t15.as.u == mo_i64(INT64_C(1)).as.u);
    MoValue t17 MO_U = mo_bool(false);
    if (t16.as.b) {
        MoValue t18 MO_U = L4.as.xs[0];
        MoValue t19 MO_U = t18.as.xs[8];
        t17 = t19;
    }
    if (!t17.as.b) mo_crash(36);
    MoValue t20 MO_U = L4;
    MoValue t21 MO_U = t20.as.xs[0];
    MoValue t22 MO_U = t21.as.xs[2];
    MoValue t23 MO_U = mo_r_Map_get((const MoValue[]){t22, mo_str("progress", 8)}, MO_KIND_NONE);
    MoValue t24 MO_U = mo_variant(0, 1, (const MoValue[]){mo_i64(INT64_C(1))});
    if (!mo_compare(MO_EQ, t23, t24)) mo_crash_values(37, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t23, t24});
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_test2
#undef LOAD_test2
MO_U static MoValue a3(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("production per-file total-record and retained-block counters refuse the next value");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[2];
    MoValue t1 MO_U = mo_bool(mo_compare(MO_EQ, t0, mo_str("the file exceeds 200000 records", 31)));
    MoValue t2 MO_U = mo_bool(false);
    if (t1.as.b) {
        MoValue t3 MO_U = L0.as.xs[1];
        MoValue t4 MO_U = mo_bool(t3.as.u == mo_i64(INT64_C(1)).as.u);
        t2 = t4;
    }
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a4(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("production per-file total-record and retained-block counters refuse the next value");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[2];
    MoValue t1 MO_U = mo_bool(mo_compare(MO_EQ, t0, mo_str("the search exceeds 1000000 records", 34)));
    MoValue t2 MO_U = mo_bool(false);
    if (t1.as.b) {
        MoValue t3 MO_U = L0.as.xs[1];
        MoValue t4 MO_U = mo_bool(t3.as.u == mo_i64(INT64_C(1)).as.u);
        t2 = t4;
    }
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_test3() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = R; } while (0)
#define LOAD_test3() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; R = V_[11]; } while (0)
MO_U static MoValue test3(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("production per-file total-record and retained-block counters refuse the next value");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue V_[12];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 12, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    L0 = mo_str("{\"type\":\"user\",\"message\":{\"role\":\"user\",\"id\":\"m\",\"content\":\"kept\"}}", 67);
    if (mo_walk_due(&FR_)) { SAVE_test3(); mo_walk(&FR_); LOAD_test3(); }
    MoValue t0 MO_U = f18();
    SAVE_test3();
    uint64_t w1 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t2 MO_U = f20(t0, mo_str("one.jsonl", 9), mo_i64(INT64_C(10000)));
    FR_.walking = false; if (mo_walks != w1) LOAD_test3();
    L1 = t2;
    MoValue t3 MO_U = L1;
    MoValue t4 MO_U = mo_set_field(t3, 4, mo_i64(INT64_C(200000)));
    L1 = t4;
    if (mo_walk_due(&FR_)) { SAVE_test3(); mo_walk(&FR_); LOAD_test3(); }
    MoValue t5 MO_U = L1;
    MoValue t6 MO_U = L0;
    SAVE_test3();
    uint64_t w7 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t8 MO_U = f21(t5, t6);
    FR_.walking = false; if (mo_walks != w7) LOAD_test3();
    L2 = t8;
    MoValue t9 MO_U = L2.as.xs[8];
    MoValue t10 MO_U = mo_bool(false);
    if (t9.as.b) {
        MoValue t11 MO_U = L2.as.xs[4];
        MoValue t12 MO_U = mo_bool(t11.as.u == mo_i64(INT64_C(200000)).as.u);
        t10 = t12;
    }
    if (!t10.as.b) mo_crash(38);
    MoValue t13 MO_U = L2.as.xs[0];
    MoValue t14 MO_U = t13.as.xs[6];
    MoValue t15 MO_U = mo_bool(t14.as.u == mo_i64(INT64_C(0)).as.u);
    MoValue t16 MO_U = mo_bool(false);
    if (t15.as.b) {
        MoValue t17 MO_U = L2;
        MoValue t18 MO_U = t17.as.xs[0];
        MoValue t19 MO_U = t18.as.xs[0];
        MoValue t20 MO_U = mo_r_Map_size((const MoValue[]){t19}, MO_KIND_NONE);
        MoValue t21 MO_U = mo_bool(t20.as.u == mo_i64(INT64_C(0)).as.u);
        t16 = t21;
    }
    if (!t16.as.b) mo_crash(39);
    MoValue t22 MO_U = L2.as.xs[0];
    MoValue t23 MO_U = t22.as.xs[1];
    MoValue t24 MO_U = mo_closure(a3, 48, 0, NULL);
    MoValue t25 MO_U = mo_r_List_any_q((const MoValue[]){t23, t24}, MO_KIND_NONE);
    if (!t25.as.b) mo_crash(40);
    if (mo_walk_due(&FR_)) { SAVE_test3(); mo_walk(&FR_); LOAD_test3(); }
    MoValue t26 MO_U = f18();
    SAVE_test3();
    uint64_t w27 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t28 MO_U = f20(t26, mo_str("below.jsonl", 11), mo_i64(INT64_C(10000)));
    FR_.walking = false; if (mo_walks != w27) LOAD_test3();
    L3 = t28;
    MoValue t29 MO_U = L3;
    MoValue t30 MO_U = mo_set_field(t29, 4, mo_i64(INT64_C(199999)));
    L3 = t30;
    if (mo_walk_due(&FR_)) { SAVE_test3(); mo_walk(&FR_); LOAD_test3(); }
    MoValue t31 MO_U = L3;
    MoValue t32 MO_U = L0;
    SAVE_test3();
    uint64_t w33 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t34 MO_U = f21(t31, t32);
    FR_.walking = false; if (mo_walks != w33) LOAD_test3();
    L4 = t34;
    MoValue t35 MO_U = L4.as.xs[8];
    MoValue t36 MO_U = mo_bool(!t35.as.b);
    MoValue t37 MO_U = mo_bool(false);
    if (t36.as.b) {
        MoValue t38 MO_U = L4.as.xs[4];
        MoValue t39 MO_U = mo_bool(t38.as.u == mo_i64(INT64_C(200000)).as.u);
        t37 = t39;
    }
    if (!t37.as.b) mo_crash(41);
    MoValue t40 MO_U = L4.as.xs[0];
    MoValue t41 MO_U = t40.as.xs[6];
    MoValue t42 MO_U = mo_bool(t41.as.u == mo_i64(INT64_C(1)).as.u);
    MoValue t43 MO_U = mo_bool(false);
    if (t42.as.b) {
        MoValue t44 MO_U = L4;
        MoValue t45 MO_U = t44.as.xs[0];
        MoValue t46 MO_U = t45.as.xs[0];
        MoValue t47 MO_U = mo_r_Map_size((const MoValue[]){t46}, MO_KIND_NONE);
        MoValue t48 MO_U = mo_bool(t47.as.u == mo_i64(INT64_C(1)).as.u);
        t43 = t48;
    }
    if (!t43.as.b) mo_crash(42);
    if (mo_walk_due(&FR_)) { SAVE_test3(); mo_walk(&FR_); LOAD_test3(); }
    SAVE_test3();
    uint64_t w49 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t50 MO_U = f18();
    FR_.walking = false; if (mo_walks != w49) LOAD_test3();
    L5 = t50;
    MoValue t51 MO_U = L5;
    MoValue t52 MO_U = mo_set_field(t51, 6, mo_i64(INT64_C(1000000)));
    L5 = t52;
    if (mo_walk_due(&FR_)) { SAVE_test3(); mo_walk(&FR_); LOAD_test3(); }
    MoValue t53 MO_U = L5;
    MoValue t54 MO_U = f20(t53, mo_str("two.jsonl", 9), mo_i64(INT64_C(10000)));
    MoValue t55 MO_U = L0;
    SAVE_test3();
    uint64_t w56 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t57 MO_U = f21(t54, t55);
    FR_.walking = false; if (mo_walks != w56) LOAD_test3();
    L6 = t57;
    MoValue t58 MO_U = L6.as.xs[8];
    MoValue t59 MO_U = mo_bool(false);
    if (t58.as.b) {
        MoValue t60 MO_U = L6.as.xs[4];
        MoValue t61 MO_U = mo_bool(t60.as.u == mo_i64(INT64_C(0)).as.u);
        t59 = t61;
    }
    if (!t59.as.b) mo_crash(43);
    MoValue t62 MO_U = L6.as.xs[0];
    MoValue t63 MO_U = t62.as.xs[6];
    MoValue t64 MO_U = mo_bool(t63.as.u == mo_i64(INT64_C(1000000)).as.u);
    MoValue t65 MO_U = mo_bool(false);
    if (t64.as.b) {
        MoValue t66 MO_U = L6;
        MoValue t67 MO_U = t66.as.xs[0];
        MoValue t68 MO_U = t67.as.xs[0];
        MoValue t69 MO_U = mo_r_Map_size((const MoValue[]){t68}, MO_KIND_NONE);
        MoValue t70 MO_U = mo_bool(t69.as.u == mo_i64(INT64_C(0)).as.u);
        t65 = t70;
    }
    if (!t65.as.b) mo_crash(44);
    MoValue t71 MO_U = L6.as.xs[0];
    MoValue t72 MO_U = t71.as.xs[1];
    MoValue t73 MO_U = mo_closure(a4, 49, 0, NULL);
    MoValue t74 MO_U = mo_r_List_any_q((const MoValue[]){t72, t73}, MO_KIND_NONE);
    if (!t74.as.b) mo_crash(45);
    if (mo_walk_due(&FR_)) { SAVE_test3(); mo_walk(&FR_); LOAD_test3(); }
    SAVE_test3();
    uint64_t w75 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t76 MO_U = f18();
    FR_.walking = false; if (mo_walks != w75) LOAD_test3();
    L7 = t76;
    MoValue t77 MO_U = L7;
    MoValue t78 MO_U = mo_set_field(t77, 6, mo_i64(INT64_C(999999)));
    L7 = t78;
    if (mo_walk_due(&FR_)) { SAVE_test3(); mo_walk(&FR_); LOAD_test3(); }
    MoValue t79 MO_U = L7;
    MoValue t80 MO_U = f20(t79, mo_str("total-below.jsonl", 17), mo_i64(INT64_C(10000)));
    MoValue t81 MO_U = L0;
    SAVE_test3();
    uint64_t w82 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t83 MO_U = f21(t80, t81);
    FR_.walking = false; if (mo_walks != w82) LOAD_test3();
    L8 = t83;
    MoValue t84 MO_U = L8.as.xs[8];
    MoValue t85 MO_U = mo_bool(!t84.as.b);
    MoValue t86 MO_U = mo_bool(false);
    if (t85.as.b) {
        MoValue t87 MO_U = L8.as.xs[4];
        MoValue t88 MO_U = mo_bool(t87.as.u == mo_i64(INT64_C(1)).as.u);
        t86 = t88;
    }
    if (!t86.as.b) mo_crash(46);
    MoValue t89 MO_U = L8.as.xs[0];
    MoValue t90 MO_U = t89.as.xs[6];
    MoValue t91 MO_U = mo_bool(t90.as.u == mo_i64(INT64_C(1000000)).as.u);
    MoValue t92 MO_U = mo_bool(false);
    if (t91.as.b) {
        MoValue t93 MO_U = L8;
        MoValue t94 MO_U = t93.as.xs[0];
        MoValue t95 MO_U = t94.as.xs[0];
        MoValue t96 MO_U = mo_r_Map_size((const MoValue[]){t95}, MO_KIND_NONE);
        MoValue t97 MO_U = mo_bool(t96.as.u == mo_i64(INT64_C(1)).as.u);
        t92 = t97;
    }
    if (!t92.as.b) mo_crash(47);
    if (mo_walk_due(&FR_)) { SAVE_test3(); mo_walk(&FR_); LOAD_test3(); }
    SAVE_test3();
    uint64_t w98 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t99 MO_U = f18();
    FR_.walking = false; if (mo_walks != w98) LOAD_test3();
    L9 = t99;
    MoValue t100 MO_U = L9;
    MoValue t101 MO_U = mo_set_field(t100, 7, mo_i64(INT64_C(500000)));
    L9 = t101;
    MoValue t102 MO_U = L9;
    MoValue t103 MO_U = f20(t102, mo_str("three.jsonl", 11), mo_i64(INT64_C(10000)));
    MoValue t104 MO_U = L0;
    MoValue t105 MO_U = f21(t103, t104);
    MoValue t106 MO_U = t105.as.xs[0];
    L10 = t106;
    MoValue t107 MO_U = L10.as.xs[8];
    MoValue t108 MO_U = mo_bool(false);
    if (t107.as.b) {
        MoValue t109 MO_U = L10.as.xs[7];
        MoValue t110 MO_U = mo_bool(t109.as.u == mo_i64(INT64_C(500000)).as.u);
        t108 = t110;
    }
    if (!t108.as.b) mo_crash(48);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_test3
#undef LOAD_test3
MO_U static MoValue test4(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("production record and message admission predicates differ at each boundary");
    MoValue t0 MO_U = f39(mo_i64(INT64_C(199999)));
    MoValue t1 MO_U = mo_bool(false);
    if (t0.as.b) {
        MoValue t2 MO_U = f39(mo_i64(INT64_C(200000)));
        MoValue t3 MO_U = mo_bool(!t2.as.b);
        t1 = t3;
    }
    if (!t1.as.b) mo_crash(49);
    MoValue t4 MO_U = f40(mo_i64(INT64_C(999999)));
    MoValue t5 MO_U = mo_bool(false);
    if (t4.as.b) {
        MoValue t6 MO_U = f40(mo_i64(INT64_C(1000000)));
        MoValue t7 MO_U = mo_bool(!t6.as.b);
        t5 = t7;
    }
    if (!t5.as.b) mo_crash(50);
    MoValue t8 MO_U = f41(mo_i64(INT64_C(99999)));
    MoValue t9 MO_U = mo_bool(false);
    if (t8.as.b) {
        MoValue t10 MO_U = f41(mo_i64(INT64_C(100000)));
        MoValue t11 MO_U = mo_bool(!t10.as.b);
        t9 = t11;
    }
    if (!t9.as.b) mo_crash(51);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}

int main(void) {
    return mo_run_tests();
}
