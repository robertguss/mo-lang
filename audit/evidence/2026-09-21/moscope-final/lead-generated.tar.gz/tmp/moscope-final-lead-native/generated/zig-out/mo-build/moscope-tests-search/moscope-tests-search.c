/* Written by mo build (toolchain/src/emit_c.zig); links toolchain/runtime/mo_rt.c. */
#include "mo_rt.h"

MO_U static MoValue f0(void);
MO_U static MoValue f1(void);
MO_U static MoValue f2(void);
MO_U static MoValue f3(void);
MO_U static MoValue f4(void);
MO_U static MoValue f5(void);
MO_U static MoValue f6(void);
MO_U static MoValue f7(void);
MO_U static MoValue f8(void);
MO_U static MoValue f9(void);
MO_U static MoValue f10(void);
MO_U static MoValue f11(void);
MO_U static MoValue f12(void);
MO_U static MoValue f13(void);
MO_U static MoValue f14(void);
MO_U static MoValue f15(void);
MO_U static MoValue f16(void);
MO_U static MoValue f17(void);
MO_U static MoValue f18(void);
MO_U static MoValue f19(void);
MO_U static MoValue a0(const MoValue *cap, const MoValue *args);
MO_U static MoValue f20(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue a1(const MoValue *cap, const MoValue *args);
MO_U static MoValue a2(const MoValue *cap, const MoValue *args);
MO_U static MoValue a3(const MoValue *cap, const MoValue *args);
MO_U static MoValue f21(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue a5(const MoValue *cap, const MoValue *args);
MO_U static MoValue a4(const MoValue *cap, const MoValue *args);
MO_U static MoValue f22(MoValue L0, MoValue L1);
MO_U static MoValue f23(MoValue L0);
MO_U static MoValue a6(const MoValue *cap, const MoValue *args);
MO_U static MoValue a7(const MoValue *cap, const MoValue *args);
MO_U static MoValue a9(const MoValue *cap, const MoValue *args);
MO_U static MoValue a8(const MoValue *cap, const MoValue *args);
MO_U static MoValue a10(const MoValue *cap, const MoValue *args);
MO_U static MoValue a11(const MoValue *cap, const MoValue *args);
MO_U static MoValue a12(const MoValue *cap, const MoValue *args);
MO_U static MoValue a13(const MoValue *cap, const MoValue *args);
MO_U static MoValue a14(const MoValue *cap, const MoValue *args);
MO_U static MoValue a15(const MoValue *cap, const MoValue *args);
MO_U static MoValue f24(MoValue L0, MoValue L1);
MO_U static MoValue f25(MoValue L0);
MO_U static MoValue f26(MoValue L0, MoValue L1);
MO_U static MoValue f27(MoValue L0);
MO_U static MoValue f28(MoValue L0, MoValue L1);
MO_U static MoValue a16(const MoValue *cap, const MoValue *args);
MO_U static MoValue f29(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue a17(const MoValue *cap, const MoValue *args);
MO_U static MoValue a18(const MoValue *cap, const MoValue *args);
MO_U static MoValue f30(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f31(MoValue L0, MoValue L1);
MO_U static MoValue f32(MoValue L0, MoValue L1, MoValue L2);
MO_U static MoValue f33(MoValue L0);
MO_U static MoValue a19(const MoValue *cap, const MoValue *args);
MO_U static MoValue f34(MoValue L0);
MO_U static MoValue a20(const MoValue *cap, const MoValue *args);
MO_U static MoValue a21(const MoValue *cap, const MoValue *args);
MO_U static MoValue a22(const MoValue *cap, const MoValue *args);
MO_U static MoValue f35(MoValue L0);
MO_U static MoValue a23(const MoValue *cap, const MoValue *args);
MO_U static MoValue f36(MoValue L0);
MO_U static MoValue f37(MoValue L0, MoValue L1);
MO_U static MoValue f38(MoValue L0);
MO_U static MoValue f39(MoValue L0, MoValue L1);
MO_U static MoValue f40(MoValue L0, MoValue L1, MoValue L2, MoValue L3);
MO_U static MoValue test0(void);
MO_U static MoValue test1(void);
MO_U static MoValue test2(void);
MO_U static MoValue test3(void);
MO_U static MoValue test4(void);
MO_U static MoValue test5(void);

static const MoField decl_fields_0[] = {{NULL, 0}};
static const MoRefineFn decl_refines_0[] = {NULL};
static const MoField decl_fields_1[] = {{NULL, 0}};
static const MoRefineFn decl_refines_1[] = {NULL};
static const MoField decl_fields_2[] = {{NULL, 0}};
static const MoRefineFn decl_refines_2[] = {NULL};
static const MoField decl_fields_3[] = {{NULL, 0}};
static const MoRefineFn decl_refines_3[] = {NULL};
static const MoField decl_fields_4[] = {{NULL, 0}};
static const MoRefineFn decl_refines_4[] = {NULL};
static const MoField decl_fields_5[] = {{NULL, 0}};
static const MoRefineFn decl_refines_5[] = {NULL};
static const MoField decl_fields_6[] = {{NULL, 0}};
static const MoRefineFn decl_refines_6[] = {NULL};
static const MoField decl_fields_7[] = {{NULL, 0}};
static const MoRefineFn decl_refines_7[] = {NULL};
static const MoField decl_fields_8[] = {{NULL, 0}};
static const MoRefineFn decl_refines_8[] = {NULL};
static const MoField decl_fields_9[] = {{NULL, 0}};
static const MoRefineFn decl_refines_9[] = {NULL};
static const MoField decl_fields_10[] = {{NULL, 0}};
static const MoRefineFn decl_refines_10[] = {NULL};
static const MoField decl_fields_11[] = {{NULL, 0}};
static const MoRefineFn decl_refines_11[] = {NULL};
static const MoField decl_fields_12[] = {{NULL, 0}};
static const MoRefineFn decl_refines_12[] = {NULL};
static const MoField decl_fields_13[] = {{NULL, 0}};
static const MoRefineFn decl_refines_13[] = {NULL};
static const MoField decl_fields_14[] = {{NULL, 0}};
static const MoRefineFn decl_refines_14[] = {NULL};
static const MoField decl_fields_15[] = {{NULL, 0}};
static const MoRefineFn decl_refines_15[] = {NULL};
static const MoField decl_fields_16[] = {{NULL, 0}};
static const MoRefineFn decl_refines_16[] = {NULL};
static const MoField decl_fields_17[] = {{"id", 0}, {"captured_at", 2}, {"captured_amount", 3}, {"refunded", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_17[] = {NULL};
static const MoField decl_fields_18[] = {{"id", 0}, {"amount", 3}, {NULL, 0}};
static const MoRefineFn decl_refines_18[] = {NULL};
static const MoField decl_fields_19[] = {{"refund", 6}, {NULL, 0}};
static const MoRefineFn decl_refines_19[] = {NULL};
static const MoField decl_fields_20[] = {{"request", 7}, {"reason", 8}, {NULL, 0}};
static const MoRefineFn decl_refines_20[] = {NULL};
static const MoField decl_fields_21[] = {{"method", 1}, {"path", 1}, {"query", 9}, {"headers", 10}, {"body", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_21[] = {NULL};
static const MoField decl_fields_22[] = {{"status", 11}, {"headers", 12}, {"body", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_22[] = {NULL};
static const MoField decl_fields_23[] = {{"id", 4}, {"name", 1}, {"alive", 5}, {"mailbox", 4}, {"bound", 4}, {"waiting_in", 13}, {"restarts", 4}, {"region_bytes", 4}, {"paused", 5}, {"scheduler", 4}, {NULL, 0}};
static const MoRefineFn decl_refines_23[] = {NULL};
static const MoField decl_fields_24[] = {{"kind", 1}, {"target", 4}, {"name", 1}, {"in_flight", 4}, {"paused", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_24[] = {NULL};
static const MoField decl_fields_25[] = {{"name", 1}, {"kind", 14}, {"links", 4}, {"setuid", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_25[] = {NULL};
static const MoField decl_fields_26[] = {{"exit", 15}, {"stdout", 16}, {"stderr", 18}, {"truncated", 5}, {"took", 19}, {NULL, 0}};
static const MoRefineFn decl_refines_26[] = {NULL};
static const MoField decl_fields_27[] = {{"resident_bytes", 4}, {"region_bytes", 4}, {"region_resident_bytes", 4}, {"packed_bytes", 4}, {"event_bytes", 4}, {"largest", 20}, {NULL, 0}};
static const MoRefineFn decl_refines_27[] = {NULL};
static const MoField decl_fields_28[] = {{NULL, 0}};
static const MoRefineFn decl_refines_28[] = {NULL};
static const MoField decl_fields_29[] = {{"query", 1}, {"dir", 1}, {"mode", 22}, {"include_tools", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_29[] = {NULL};
static const MoField decl_fields_30[] = {{NULL, 0}};
static const MoRefineFn decl_refines_30[] = {NULL};
static const MoField decl_fields_31[] = {{"kind", 23}, {"label", 1}, {"text", 1}, {"path", 1}, {"line", 4}, {"local_index", 4}, {"api_index", 24}, {NULL, 0}};
static const MoRefineFn decl_refines_31[] = {NULL};
static const MoField decl_fields_32[] = {{"key", 1}, {"session_key", 1}, {"session_label", 1}, {"role", 1}, {"id", 1}, {"path", 1}, {"first_line", 4}, {"conversation_at", 25}, {"blocks", 26}, {NULL, 0}};
static const MoRefineFn decl_refines_32[] = {NULL};
static const MoField decl_fields_33[] = {{"payload", 28}, {"line", 4}, {NULL, 0}};
static const MoRefineFn decl_refines_33[] = {NULL};
static const MoField decl_fields_34[] = {{"path", 1}, {"line", 4}, {"detail", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_34[] = {NULL};
static const MoField decl_fields_35[] = {{"messages", 29}, {"issues", 31}, {"unknown_kinds", 33}, {"skipped_links", 4}, {"files_read", 4}, {"admitted_bytes", 4}, {"records", 4}, {"retained_blocks", 4}, {"incomplete", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_35[] = {NULL};
static const MoField decl_fields_36[] = {{"files", 34}, {"issues", 35}, {"entries", 4}, {"skipped_links", 4}, {"incomplete", 5}, {"stopped", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_36[] = {NULL};
static const MoField decl_fields_37[] = {{"entry", 30}, {"blocks", 36}, {NULL, 0}};
static const MoRefineFn decl_refines_37[] = {NULL};
static const MoField decl_fields_38[] = {{"key", 1}, {"label", 1}, {"latest", 37}, {"hits", 38}, {NULL, 0}};
static const MoRefineFn decl_refines_38[] = {NULL};
static const MoField decl_fields_39[] = {{"text", 1}, {"diagnostics", 1}, {"matches", 4}, {"incomplete", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_39[] = {NULL};
static const MoField decl_fields_40[] = {{"scan", 40}, {"hits", 41}, {NULL, 0}};
static const MoRefineFn decl_refines_40[] = {NULL};
static const MoField decl_fields_41[] = {{"text", 1}, {"truncated", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_41[] = {NULL};
static const MoField variant_fields_0[] = {{"path", 1}, {NULL, 0}};
static const MoField variant_fields_1[] = {{NULL, 0}};
static const MoField variant_fields_2[] = {{NULL, 0}};
static const MoField variant_fields_3[] = {{NULL, 0}};
static const MoField variant_fields_4[] = {{NULL, 0}};
static const MoField variant_fields_5[] = {{NULL, 0}};
static const MoField variant_fields_6[] = {{"fields", 42}, {NULL, 0}};
static const MoField variant_fields_7[] = {{"items", 43}, {NULL, 0}};
static const MoField variant_fields_8[] = {{"text", 1}, {NULL, 0}};
static const MoField variant_fields_9[] = {{"value", 44}, {NULL, 0}};
static const MoField variant_fields_10[] = {{"value", 5}, {NULL, 0}};
static const MoField variant_fields_11[] = {{NULL, 0}};
static const MoField variant_fields_12[] = {{"at", 4}, {NULL, 0}};
static const MoField variant_fields_13[] = {{NULL, 0}};
static const MoField variant_fields_14[] = {{NULL, 0}};
static const MoField variant_fields_15[] = {{NULL, 0}};
static const MoField variant_fields_16[] = {{NULL, 0}};
static const MoField variant_fields_17[] = {{NULL, 0}};
static const MoField variant_fields_18[] = {{NULL, 0}};
static const MoField variant_fields_19[] = {{NULL, 0}};
static const MoField variant_fields_20[] = {{NULL, 0}};
static const MoField variant_fields_21[] = {{NULL, 0}};
static const MoField variant_fields_22[] = {{NULL, 0}};
static const MoField variant_fields_23[] = {{NULL, 0}};
static const MoField variant_fields_24[] = {{NULL, 0}};
static const MoField variant_fields_25[] = {{NULL, 0}};
static const MoField variant_fields_26[] = {{"why", 1}, {NULL, 0}};
static const MoField variant_fields_27[] = {{NULL, 0}};
static const MoField variant_fields_28[] = {{NULL, 0}};
static const MoField variant_fields_29[] = {{NULL, 0}};
static const MoField variant_fields_30[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"taking", 1}, {"took_us", 4}, {"waited_us", 4}, {"longest", 1}, {NULL, 0}};
static const MoField variant_fields_31[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"scheduler", 4}, {NULL, 0}};
static const MoField variant_fields_32[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_33[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"restarts", 4}, {NULL, 0}};
static const MoField variant_fields_34[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"seed", 4}, {"clause", 1}, {"taking", 1}, {"snapshot", 1}, {NULL, 0}};
static const MoField variant_fields_35[] = {{"at", 2}, {"sender", 45}, {"sender_name", 1}, {"target", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_36[] = {{"at", 2}, {"pid", 46}, {"name", 1}, {"call", 1}, {NULL, 0}};
static const MoField variant_fields_37[] = {{"at", 2}, {"source", 1}, {"target", 4}, {"name", 1}, {"in_flight", 4}, {NULL, 0}};
static const MoField variant_fields_38[] = {{"at", 2}, {"source", 1}, {"target", 4}, {"name", 1}, {"in_flight", 4}, {NULL, 0}};
static const MoField variant_fields_39[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"taking", 1}, {NULL, 0}};
static const MoField variant_fields_40[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_41[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_42[] = {{"at", 2}, {"sender", 47}, {"sender_name", 1}, {"target", 4}, {"name", 1}, {"taking", 1}, {"why", 1}, {NULL, 0}};
static const MoField variant_fields_43[] = {{NULL, 0}};
static const MoField variant_fields_44[] = {{NULL, 0}};
static const MoField variant_fields_45[] = {{NULL, 0}};
static const MoField variant_fields_46[] = {{NULL, 0}};
static const MoField variant_fields_47[] = {{NULL, 0}};
static const MoField variant_fields_48[] = {{NULL, 0}};
static const MoField variant_fields_49[] = {{NULL, 0}};
static const MoField variant_fields_50[] = {{NULL, 0}};
static const MoField variant_fields_51[] = {{"text", 1}, {NULL, 0}};
static const MoField variant_fields_52[] = {{NULL, 0}};
static const MoField variant_fields_53[] = {{"code", 17}, {NULL, 0}};
static const MoField variant_fields_54[] = {{"signal", 17}, {NULL, 0}};
static const MoField variant_fields_55[] = {{NULL, 0}};
static const MoField variant_fields_56[] = {{NULL, 0}};
static const MoField variant_fields_57[] = {{NULL, 0}};
static const MoField variant_fields_58[] = {{"why", 1}, {NULL, 0}};
static const MoField variant_fields_59[] = {{NULL, 0}};
static const MoField variant_fields_60[] = {{NULL, 0}};
static const MoField variant_fields_61[] = {{NULL, 0}};
static const MoField variant_fields_62[] = {{NULL, 0}};
const MoDecl mo_decls[] = {
    {"ChargeId", 2, 0, decl_fields_0, 0, 0, 0, decl_refines_0, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Money", 2, 0, decl_fields_1, 0, 0, 0, decl_refines_1, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"CardNumber", 2, 0, decl_fields_2, 0, 0, 0, decl_refines_2, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"FsError", 8, 0, decl_fields_3, 0, 3, 0, decl_refines_3, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"AskError", 8, 0, decl_fields_4, 3, 2, 0, decl_refines_4, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"LedgerError", 8, 0, decl_fields_5, 5, 1, 0, decl_refines_5, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Json", 8, 0, decl_fields_6, 6, 6, 0, decl_refines_6, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"JsonError", 8, 0, decl_fields_7, 12, 1, 0, decl_refines_7, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"NetError", 8, 0, decl_fields_8, 13, 5, 0, decl_refines_8, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"HttpError", 8, 0, decl_fields_9, 18, 7, 0, decl_refines_9, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RuntimeError", 8, 0, decl_fields_10, 25, 5, 0, decl_refines_10, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Event", 8, 0, decl_fields_11, 30, 13, 0, decl_refines_11, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"EntryKind", 8, 0, decl_fields_12, 43, 3, 0, decl_refines_12, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"TlsError", 8, 0, decl_fields_13, 46, 5, 0, decl_refines_13, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Arg", 8, 0, decl_fields_14, 51, 2, 0, decl_refines_14, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Exit", 8, 0, decl_fields_15, 53, 2, 0, decl_refines_15, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ExecError", 8, 0, decl_fields_16, 55, 4, 0, decl_refines_16, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Charge", 0, 4, decl_fields_17, 0, 0, 0, decl_refines_17, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundRequest", 0, 2, decl_fields_18, 0, 0, 0, decl_refines_18, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundCompleted", 0, 1, decl_fields_19, 0, 0, 0, decl_refines_19, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundFailed", 0, 2, decl_fields_20, 0, 0, 0, decl_refines_20, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Request", 0, 5, decl_fields_21, 0, 0, 0, decl_refines_21, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Response", 0, 3, decl_fields_22, 0, 0, 0, decl_refines_22, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ProcessInfo", 0, 10, decl_fields_23, 0, 0, 0, decl_refines_23, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"SourceInfo", 0, 5, decl_fields_24, 0, 0, 0, decl_refines_24, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Entry", 0, 4, decl_fields_25, 0, 0, 0, decl_refines_25, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Done", 0, 5, decl_fields_26, 0, 0, 0, decl_refines_26, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"MemoryInfo", 0, 6, decl_fields_27, 0, 0, 0, decl_refines_27, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Mode", 1, 0, decl_fields_28, 59, 2, 0, decl_refines_28, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Options", 0, 4, decl_fields_29, 0, 0, 0, decl_refines_29, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"BlockKind", 1, 0, decl_fields_30, 61, 2, 0, decl_refines_30, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Block", 0, 7, decl_fields_31, 0, 0, 0, decl_refines_31, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Message", 0, 9, decl_fields_32, 0, 0, 0, decl_refines_32, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Seen", 0, 2, decl_fields_33, 0, 0, 0, decl_refines_33, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Issue", 0, 3, decl_fields_34, 0, 0, 0, decl_refines_34, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Scan", 0, 9, decl_fields_35, 0, 0, 0, decl_refines_35, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Discovery", 0, 6, decl_fields_36, 0, 0, 0, decl_refines_36, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Hit", 0, 2, decl_fields_37, 0, 0, 0, decl_refines_37, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Session", 0, 4, decl_fields_38, 0, 0, 0, decl_refines_38, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Report", 0, 4, decl_fields_39, 0, 0, 0, decl_refines_39, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Searched", 0, 2, decl_fields_40, 0, 0, 0, decl_refines_40, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Render", 0, 2, decl_fields_41, 0, 0, 0, decl_refines_41, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {NULL, 0, 0, NULL, 0, 0, 0, NULL, false, 0, 0, 0}
};
const MoVariantDef mo_variants[] = {
    {4, 1, variant_fields_0},
    {5, 0, variant_fields_1},
    {21, 0, variant_fields_2},
    {5, 0, variant_fields_3},
    {13, 0, variant_fields_4},
    {5, 0, variant_fields_5},
    {7, 1, variant_fields_6},
    {8, 1, variant_fields_7},
    {9, 1, variant_fields_8},
    {10, 1, variant_fields_9},
    {11, 1, variant_fields_10},
    {12, 0, variant_fields_11},
    {6, 1, variant_fields_12},
    {5, 0, variant_fields_13},
    {14, 0, variant_fields_14},
    {15, 0, variant_fields_15},
    {16, 0, variant_fields_16},
    {17, 0, variant_fields_17},
    {5, 0, variant_fields_18},
    {14, 0, variant_fields_19},
    {15, 0, variant_fields_20},
    {17, 0, variant_fields_21},
    {18, 0, variant_fields_22},
    {19, 0, variant_fields_23},
    {20, 0, variant_fields_24},
    {26, 0, variant_fields_25},
    {27, 1, variant_fields_26},
    {28, 0, variant_fields_27},
    {29, 0, variant_fields_28},
    {5, 0, variant_fields_29},
    {30, 7, variant_fields_30},
    {31, 4, variant_fields_31},
    {32, 3, variant_fields_32},
    {33, 4, variant_fields_33},
    {34, 7, variant_fields_34},
    {35, 5, variant_fields_35},
    {36, 4, variant_fields_36},
    {37, 5, variant_fields_37},
    {38, 5, variant_fields_38},
    {39, 4, variant_fields_39},
    {40, 3, variant_fields_40},
    {41, 3, variant_fields_41},
    {44, 7, variant_fields_42},
    {42, 0, variant_fields_43},
    {43, 0, variant_fields_44},
    {48, 0, variant_fields_45},
    {45, 0, variant_fields_46},
    {46, 0, variant_fields_47},
    {5, 0, variant_fields_48},
    {15, 0, variant_fields_49},
    {47, 0, variant_fields_50},
    {49, 1, variant_fields_51},
    {50, 0, variant_fields_52},
    {51, 1, variant_fields_53},
    {52, 1, variant_fields_54},
    {4, 0, variant_fields_55},
    {14, 0, variant_fields_56},
    {5, 0, variant_fields_57},
    {53, 1, variant_fields_58},
    {56, 0, variant_fields_59},
    {57, 0, variant_fields_60},
    {54, 0, variant_fields_61},
    {55, 0, variant_fields_62},
    {0, 0, NULL}
};
const uint32_t mo_nvariants = 63;
const MoType mo_types[] = {
    {17, "ChargeId", UINT32_MAX, false, 0, 1, NULL},
    {4, "String", UINT32_MAX, false, 0, 0, NULL},
    {5, "Time", UINT32_MAX, false, 0, 0, NULL},
    {17, "Money", UINT32_MAX, false, 1, 4, NULL},
    {7, "UInt64", UINT32_MAX, false, 7, 0, NULL},
    {3, "Bool", UINT32_MAX, false, 0, 0, NULL},
    {24, "a type not yet known", UINT32_MAX, false, 0, 0, NULL},
    {16, "RefundRequest", UINT32_MAX, false, 18, 0, NULL},
    {24, "a type not yet known", UINT32_MAX, false, 0, 0, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {7, "UInt16", UINT32_MAX, false, 5, 0, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {10, "Option(String)", UINT32_MAX, false, 1, 0, NULL},
    {16, "EntryKind", UINT32_MAX, false, 12, 0, NULL},
    {16, "Exit", UINT32_MAX, false, 15, 0, NULL},
    {9, "List(UInt8)", UINT32_MAX, false, 17, 0, NULL},
    {7, "UInt8", UINT32_MAX, false, 4, 0, NULL},
    {9, "List(UInt8)", UINT32_MAX, false, 17, 0, NULL},
    {6, "Duration", UINT32_MAX, false, 0, 0, NULL},
    {9, "List(ProcessInfo)", UINT32_MAX, false, 21, 0, NULL},
    {16, "ProcessInfo", UINT32_MAX, false, 23, 0, NULL},
    {16, "Mode", UINT32_MAX, false, 28, 0, NULL},
    {16, "BlockKind", UINT32_MAX, false, 30, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {10, "Option(Time)", UINT32_MAX, false, 2, 0, NULL},
    {9, "List(Block)", UINT32_MAX, false, 27, 0, NULL},
    {16, "Block", UINT32_MAX, false, 31, 0, NULL},
    {16, "Json", UINT32_MAX, false, 6, 0, NULL},
    {12, "Map(String, Message)", UINT32_MAX, false, 1, 30, NULL},
    {16, "Message", UINT32_MAX, false, 32, 0, NULL},
    {9, "List(Issue)", UINT32_MAX, false, 32, 0, NULL},
    {16, "Issue", UINT32_MAX, false, 34, 0, NULL},
    {12, "Map(String, UInt64)", UINT32_MAX, false, 1, 4, NULL},
    {9, "List(String)", UINT32_MAX, false, 1, 0, NULL},
    {9, "List(Issue)", UINT32_MAX, false, 32, 0, NULL},
    {9, "List(Block)", UINT32_MAX, false, 27, 0, NULL},
    {10, "Option(Time)", UINT32_MAX, false, 2, 0, NULL},
    {9, "List(Hit)", UINT32_MAX, false, 39, 0, NULL},
    {16, "Hit", UINT32_MAX, false, 37, 0, NULL},
    {16, "Scan", UINT32_MAX, false, 35, 0, NULL},
    {9, "List(Hit)", UINT32_MAX, false, 39, 0, NULL},
    {12, "Map(String, Json)", UINT32_MAX, false, 1, 28, NULL},
    {9, "List(Json)", UINT32_MAX, false, 28, 0, NULL},
    {8, "Float64", UINT32_MAX, false, 64, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {0, NULL, UINT32_MAX, false, 0, 0, NULL}
};
const uint32_t mo_nrecorded = 0;
const char *const mo_names[] = {"Some", "None", "Ok", "Error", "Missing", "Timeout", "Syntax", "Object", "Array", "String", "Number", "Bool", "Null", "Down", "Refused", "Closed", "LineTooLong", "Busy", "Malformed", "TooLarge", "Unsupported", "NotText", "Accepted", "Line", "Chunk", "Idle", "NoProcess", "Unparsed", "ReadOnly", "MailboxFull", "Updated", "Started", "Ended", "Restarted", "Crashed", "Overflowed", "TimedOut", "SourcePaused", "SourceResumed", "Sent", "Paused", "Resumed", "File", "Folder", "Dropped", "BadPem", "Handshake", "Untrusted", "Link", "Fixed", "Hole", "Exited", "Signalled", "Failed", "Conversation", "Tool", "Phrase", "AllWords", NULL};
const uint32_t mo_nnames = 58;
const MoClause mo_clauses[] = {
    {6, false, "started + process_time()", "report", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:26:21"},
    {6, false, "started + process_time()", "report", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:39:23"},
    {6, false, "started + process_time()", "searched", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:70:21"},
    {10, false, "case options.mode", "searched", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:78:13"},
    {10, false, "case session.latest", "session_heading", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:133:12"},
    {10, false, "case block.api_index", "render_hit", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:147:11"},
    {6, false, "byte + 32 else: byte", "ascii_lower", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:242:35"},
    {6, false, "byte / 16).to_u64", "hex", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:276:11"},
    {6, false, "byte % 16).to_u64", "hex", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:277:10"},
    {6, false, "high + 1)}#{digits.slice(low, low + 1)}\"", "hex", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:278:25"},
    {6, false, "low + 1)}\"", "hex", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:278:55"},
    {10, false, "case (a, b)", "later", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:282:3"},
    {5, false, "assert ascii_lower(\"Connection REFUSED \303\211\") == \"connection refused \303\211\"", "ASCII folding leaves non-ASCII exact, and punctuation remains literal", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:300:3"},
    {5, false, "assert ascii_lower(\"\303\211\") != ascii_lower(\"\303\251\")", "ASCII folding leaves non-ASCII exact, and punctuation remains literal", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:301:3"},
    {5, false, "assert ascii_lower(\"a.b[\") == \"a.b[\"", "ASCII folding leaves non-ASCII exact, and punctuation remains literal", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:302:3"},
    {5, false, "assert query_terms(\"  one\\ttwo\\nTHREE\\u{000B}four\\u{000C}five\\r \") == [\"one\",", "all-words uses exactly the six ASCII whitespace bytes", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:306:3"},
    {5, false, "assert safe(\"a\\u{001B}[31m caf\303\251\\\\z\") == \"a\\\\x1B[31m caf\\\\xC3\\\\xA9\\\\\\\\z\"", "safe output has no raw controls or non-ASCII bytes", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:314:3"},
    {5, false, "assert safe(\"A\\\\\\u{0000}\\u{007F}\303\251\") == \"A\\\\\\\\\\\\x00\\\\x7F\\\\xC3\\\\xA9\"", "terminal safety covers NUL DEL and bidi while doubling backslash", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:318:3"},
    {5, false, "assert safe(\"\\u{202E}\") == \"\\\\xE2\\\\x80\\\\xAE\"", "terminal safety covers NUL DEL and bidi while doubling backslash", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:319:3"},
    {5, false, "assert bounded_excerpt(\"x\".repeat(239)).size == 239", "excerpt boundaries and output admission differ on both sides of the limit", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:323:3"},
    {5, false, "assert bounded_excerpt(\"x\".repeat(240)).size == 240", "excerpt boundaries and output admission differ on both sides of the limit", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:324:3"},
    {5, false, "assert bounded_excerpt(\"x\".repeat(241)).size == 243", "excerpt boundaries and output admission differ on both sides of the limit", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:325:3"},
    {5, false, "assert full.text == \"1234\" and full.truncated", "excerpt boundaries and output admission differ on both sides of the limit", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:327:3"},
    {5, false, "assert room.text == \"12345\" and !room.truncated", "excerpt boundaries and output admission differ on both sides of the limit", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:329:3"},
    {5, false, "assert result_admitted\?(9_999) and !result_admitted\?(10_000)", "production result admission differs at the matching-message boundary", "/tmp/mo-lead-moscope-full/examples/programs/moscope/search.mo:333:3"},
    {0, false, NULL, NULL, NULL}
};
const MoTest mo_tests[] = {
    {MO_TEST, "ASCII folding leaves non-ASCII exact, and punctuation remains literal", test0},
    {MO_TEST, "all-words uses exactly the six ASCII whitespace bytes", test1},
    {MO_TEST, "safe output has no raw controls or non-ASCII bytes", test2},
    {MO_TEST, "terminal safety covers NUL DEL and bidi while doubling backslash", test3},
    {MO_TEST, "excerpt boundaries and output admission differ on both sides of the limit", test4},
    {MO_TEST, "production result admission differs at the matching-message boundary", test5},
    {0, NULL, NULL}
};
const uint32_t mo_ntests = 6;
const MoNever mo_nevers[] = {
    {NULL, 0, 0, NULL}
};
const uint32_t mo_nnevers = 0;
const MoProcess mo_processes[] = {
    {NULL, 0, 0, NULL, NULL, 0, NULL, false}
};
const uint32_t mo_nprocesses = 0;
const MoSupervisor mo_supervisors[] = {
    {NULL, 0, NULL}
};
const uint32_t mo_nsupervisors = 0;
const uint32_t mo_charge_decl = 17;
const uint32_t mo_request_decl = 21;
const uint32_t mo_response_decl = 22;
const uint32_t mo_process_info_decl = 23;
const uint32_t mo_source_info_decl = 24;
const uint32_t mo_memory_info_decl = 27;
const uint32_t mo_entry_decl = 25;
const uint32_t mo_done_decl = 26;
const bool mo_surface_built = false;
const uint32_t mo_surface_process = UINT32_MAX;
const bool mo_contracts_built = true;

MO_U static MoValue f0(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(4096));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f1(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("terms");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(64));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f2(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("depth");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(24));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f3(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("entries");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(50000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f4(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("files");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(5000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f5(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(67108864));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f6(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("total_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1073741824));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f7(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("line_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1048576));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f8(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("file_records");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(200000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f9(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("records");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(1000000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f10(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("messages");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(100000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f11(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("blocks");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(500000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f12(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("results");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(10000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f13(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("diagnostics");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(10000));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f14(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("excerpt");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(240));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f15(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("output_bytes");
    if (mo_contracts) {
    }
    R = mo_i64(INT64_C(8388608));
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f16(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("call_time");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Int_seconds((const MoValue[]){mo_i64(INT64_C(10))}, 3);
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f17(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("process_time");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Int_seconds((const MoValue[]){mo_i64(INT64_C(60))}, 3);
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f18(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("empty_scan");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t3 MO_U = mo_record(35, 9, (const MoValue[]){t0, t1, t2, mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_bool(false)});
    R = t3;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f19(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("empty_discovery");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_list_of(0, NULL);
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_record(36, 6, (const MoValue[]){t0, t1, mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_bool(false), mo_bool(false)});
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a0(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("report");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = t0.as.xs[5];
    MoValue t2 MO_U = L0.as.xs[0];
    MoValue t3 MO_U = t2.as.xs[6];
    MoValue t4 MO_U = L0.as.xs[0];
    MoValue t5 MO_U = t4.as.xs[3];
    MoValue t6 MO_U = L0.as.xs[0];
    MoValue t7 MO_U = t6.as.xs[4];
    MoValue t8 MO_U = mo_tuple(4, (const MoValue[]){t1, t3, t5, t7});
    R = t8;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f20() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = L12; V_[13] = L13; V_[14] = L14; V_[15] = L15; V_[16] = R; } while (0)
#define LOAD_f20() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; L12 = V_[12]; L13 = V_[13]; L14 = V_[14]; L15 = V_[15]; R = V_[16]; } while (0)
#define ROOTS_f20(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11, L12, L13, L14, L15, R}; mo_compact(m, r_, 17); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; L9 = r_[9]; L10 = r_[10]; L11 = r_[11]; L12 = r_[12]; L13 = r_[13]; L14 = r_[14]; L15 = r_[15]; R = r_[16]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f20(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("report");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    size_t m22 MO_U = 0, k22 MO_U = 0;
    size_t m24 MO_U = 0, k24 MO_U = 0;
    MoValue V_[17];
    size_t *const M_[] = {&F_, &m22, &k22, &m24, &k24};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 17, M_, 5};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    if (mo_walk_due(&FR_)) { SAVE_f20(); mo_walk(&FR_); LOAD_f20(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1;
    MoValue t2 MO_U = L2;
    MoValue t3 MO_U = L3;
    SAVE_f20();
    uint64_t w4 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t5 MO_U = f21(t0, t1, t2, t3);
    FR_.walking = false; if (mo_walks != w4) LOAD_f20();
    L4 = t5;
    if (mo_walk_due(&FR_)) { SAVE_f20(); mo_walk(&FR_); LOAD_f20(); }
    MoValue t6 MO_U = L4;
    MoValue t7 MO_U = t6.as.xs[0];
    MoValue t8 MO_U = t7.as.xs[0];
    MoValue t9 MO_U = mo_r_Map_values((const MoValue[]){t8}, MO_KIND_NONE);
    MoValue t10 MO_U = L4.as.xs[1];
    SAVE_f20();
    uint64_t w11 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t12 MO_U = f24(t9, t10);
    FR_.walking = false; if (mo_walks != w11) LOAD_f20();
    L5 = t12;
    MoValue t13 MO_U = L4.as.xs[0];
    L6 = t13;
    MoValue t14 MO_U = mo_record(41, 2, (const MoValue[]){mo_str("", 0), mo_bool(false)});
    L7 = t14;
    L8 = mo_bool(false);
    MoValue t15 MO_U = L5;
    L9 = t15;
    {
        m22 = mo_mark(); k22 = 0;
        for (uint32_t i22 = 0; i22 < L9.aux; i22++) {
            MoValue t16 MO_U = L9.as.xs[i22];
            L10 = t16;
            MoValue t17 MO_U = L2;
            MoValue t18 MO_U = mo_r_Clock_now((const MoValue[]){t17}, MO_KIND_NONE);
            MoValue t19 MO_U = L3;
            MoValue t20 MO_U = f17();
            MoValue t21 MO_U = mo_arith(MO_OP_ADD, t19, t20, 0);
            MoValue t22 MO_U = mo_bool(mo_compare(MO_GE, t18, t21));
            if (t22.as.b) {
                if (mo_walk_due(&FR_)) { SAVE_f20(); mo_walk(&FR_); LOAD_f20(); }
                MoValue t23 MO_U = L6;
                SAVE_f20();
                uint64_t w24 MO_U = mo_walks;
                FR_.walking = true;
                MoValue t25 MO_U = f40(t23, mo_str("<search>", 8), mo_i64(INT64_C(0)), mo_str("the 60 second processing deadline was exceeded", 46));
                FR_.walking = false; if (mo_walks != w24) LOAD_f20();
                L6 = t25;
                L8 = mo_bool(true);
                goto B22;
            }
            if (mo_walk_due(&FR_)) { SAVE_f20(); mo_walk(&FR_); LOAD_f20(); }
            MoValue t26 MO_U = L7;
            mo_disown_in(L10);
            MoValue t27 MO_U = L10;
            MoValue t28 MO_U = f25(t27);
            SAVE_f20();
            uint64_t w29 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t30 MO_U = f31(t26, t28);
            FR_.walking = false; if (mo_walks != w29) LOAD_f20();
            L7 = t30;
            MoValue t31 MO_U = L7.as.xs[1];
            if (t31.as.b) {
                goto B22;
            }
            MoValue t32 MO_U = L10.as.xs[3];
            MoValue t33 MO_U = mo_closure(a0, 41, 0, NULL);
            MoValue t34 MO_U = mo_r_List_sort_by((const MoValue[]){t32, t33}, MO_KIND_NONE);
            L11 = t34;
            {
                m24 = mo_mark(); k24 = 0;
                for (uint32_t i24 = 0; i24 < L11.aux; i24++) {
                    MoValue t35 MO_U = L11.as.xs[i24];
                    L12 = t35;
                    MoValue t36 MO_U = L2;
                    MoValue t37 MO_U = mo_r_Clock_now((const MoValue[]){t36}, MO_KIND_NONE);
                    MoValue t38 MO_U = L3;
                    MoValue t39 MO_U = f17();
                    MoValue t40 MO_U = mo_arith(MO_OP_ADD, t38, t39, 1);
                    MoValue t41 MO_U = mo_bool(mo_compare(MO_GE, t37, t40));
                    if (t41.as.b) {
                        if (mo_walk_due(&FR_)) { SAVE_f20(); mo_walk(&FR_); LOAD_f20(); }
                        MoValue t42 MO_U = L6;
                        SAVE_f20();
                        uint64_t w43 MO_U = mo_walks;
                        FR_.walking = true;
                        MoValue t44 MO_U = f40(t42, mo_str("<search>", 8), mo_i64(INT64_C(0)), mo_str("the 60 second processing deadline was exceeded", 46));
                        FR_.walking = false; if (mo_walks != w43) LOAD_f20();
                        L6 = t44;
                        L8 = mo_bool(true);
                        goto B24;
                    }
                    if (mo_walk_due(&FR_)) { SAVE_f20(); mo_walk(&FR_); LOAD_f20(); }
                    MoValue t45 MO_U = L7;
                    MoValue t46 MO_U = L12;
                    SAVE_f20();
                    uint64_t w47 MO_U = mo_walks;
                    FR_.walking = true;
                    MoValue t48 MO_U = f26(t45, t46);
                    FR_.walking = false; if (mo_walks != w47) LOAD_f20();
                    L7 = t48;
                    MoValue t49 MO_U = L7.as.xs[1];
                    if (t49.as.b) {
                        goto B24;
                    }
                    ROOTS_f20(m24, k24);
                }
            }
            B24:;
            MoValue t50 MO_U = L8;
            MoValue t51 MO_U = mo_bool(true);
            if (!t50.as.b) {
                MoValue t52 MO_U = L7.as.xs[1];
                t51 = t52;
            }
            if (t51.as.b) {
                goto B22;
            }
            ROOTS_f20(m22, k22);
        }
    }
    B22:;
    MoValue t53 MO_U = MO_NONE_V;
    MoValue t54 MO_U = L4.as.xs[1];
    MoValue t55 MO_U = mo_r_List_size((const MoValue[]){t54}, MO_KIND_NONE);
    MoValue t56 MO_U = mo_bool(t55.as.u == mo_i64(INT64_C(0)).as.u);
    if (t56.as.b) {
        t53 = mo_str("No matches.\012", 12);
    } else {
        MoValue t57 MO_U = L4.as.xs[1];
        MoValue t58 MO_U = mo_r_List_size((const MoValue[]){t57}, MO_KIND_NONE);
        MoValue t59 MO_U = mo_concat(2, (const MoValue[]){t58, mo_str(" matching messages.\012", 20)});
        t53 = t59;
    }
    L13 = t53;
    if (mo_walk_due(&FR_)) { SAVE_f20(); mo_walk(&FR_); LOAD_f20(); }
    MoValue t60 MO_U = L7;
    MoValue t61 MO_U = L13;
    SAVE_f20();
    uint64_t w62 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t63 MO_U = f31(t60, t61);
    FR_.walking = false; if (mo_walks != w62) LOAD_f20();
    L7 = t63;
    MoValue t64 MO_U = L7.as.xs[1];
    if (t64.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f20(); mo_walk(&FR_); LOAD_f20(); }
        MoValue t65 MO_U = L6;
        SAVE_f20();
        uint64_t w66 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t67 MO_U = f40(t65, mo_str("<output>", 8), mo_i64(INT64_C(0)), mo_str("rendered output exceeds 8 MiB", 29));
        FR_.walking = false; if (mo_walks != w66) LOAD_f20();
        L6 = t67;
    }
    MoValue t68 MO_U = f15();
    MoValue t69 MO_U = L7.as.xs[0];
    MoValue t70 MO_U = mo_r_String_byte_size((const MoValue[]){t69}, MO_KIND_NONE);
    MoValue t71 MO_U = mo_r_Int_saturating_sub((const MoValue[]){t68, t70}, 7);
    L14 = t71;
    if (mo_walk_due(&FR_)) { SAVE_f20(); mo_walk(&FR_); LOAD_f20(); }
    mo_disown_in(L6);
    MoValue t72 MO_U = L6;
    MoValue t73 MO_U = L14;
    SAVE_f20();
    uint64_t w74 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t75 MO_U = f28(t72, t73);
    FR_.walking = false; if (mo_walks != w74) LOAD_f20();
    L15 = t75;
    MoValue t76 MO_U = L7.as.xs[0];
    MoValue t77 MO_U = L15.as.xs[0];
    MoValue t78 MO_U = L4.as.xs[1];
    MoValue t79 MO_U = mo_r_List_size((const MoValue[]){t78}, MO_KIND_NONE);
    MoValue t80 MO_U = L6.as.xs[8];
    MoValue t81 MO_U = mo_bool(true);
    if (!t80.as.b) {
        MoValue t82 MO_U = L15.as.xs[1];
        t81 = t82;
    }
    MoValue t83 MO_U = mo_record(39, 4, (const MoValue[]){t76, t77, t79, t81});
    R = t83;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f20
#undef SAVE_f20
#undef LOAD_f20
MO_U static MoValue a1(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("searched");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    R = t0;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a2(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("searched");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = mo_variant(54, 0, NULL);
    MoValue t2 MO_U = mo_bool(mo_compare(MO_EQ, t0, t1));
    MoValue t3 MO_U = mo_bool(true);
    if (!t2.as.b) {
        MoValue t4 MO_U = cap[0].as.xs[3];
        MoValue t5 MO_U = mo_bool(false);
        if (t4.as.b) {
            MoValue t6 MO_U = L0.as.xs[0];
            MoValue t7 MO_U = mo_variant(55, 0, NULL);
            MoValue t8 MO_U = mo_bool(mo_compare(MO_EQ, t6, t7));
            t5 = t8;
        }
        t3 = t5;
    }
    R = t3;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a3(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("searched");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f23(t0);
    MoValue t2 MO_U = f34(t1);
    MoValue t3 MO_U = cap[0];
    MoValue t4 MO_U = mo_r_String_contains_q((const MoValue[]){t2, t3}, MO_KIND_NONE);
    R = t4;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f21() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = L10; V_[11] = L11; V_[12] = R; } while (0)
#define LOAD_f21() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; L10 = V_[10]; L11 = V_[11]; R = V_[12]; } while (0)
#define ROOTS_f21(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11, R}; mo_compact(m, r_, 13); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; L9 = r_[9]; L10 = r_[10]; L11 = r_[11]; R = r_[12]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f21(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("searched");
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    size_t m27 MO_U = 0, k27 MO_U = 0;
    MoValue V_[13];
    size_t *const M_[] = {&F_, &m27, &k27};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 13, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    mo_disown_in(L0);
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_record(40, 2, (const MoValue[]){t0, t1});
    L4 = t2;
    if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
    MoValue t3 MO_U = L1.as.xs[0];
    SAVE_f21();
    uint64_t w4 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t5 MO_U = f34(t3);
    FR_.walking = false; if (mo_walks != w4) LOAD_f21();
    L5 = t5;
    if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
    MoValue t6 MO_U = L1.as.xs[0];
    SAVE_f21();
    uint64_t w7 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t8 MO_U = f35(t6);
    FR_.walking = false; if (mo_walks != w7) LOAD_f21();
    L6 = t8;
    MoValue t9 MO_U = L0;
    MoValue t10 MO_U = t9.as.xs[0];
    MoValue t11 MO_U = mo_r_Map_values((const MoValue[]){t10}, MO_KIND_NONE);
    MoValue t12 MO_U = mo_closure(a1, 42, 0, NULL);
    MoValue t13 MO_U = mo_r_List_sort_by((const MoValue[]){t11, t12}, MO_KIND_NONE);
    L7 = t13;
    {
        m27 = mo_mark(); k27 = 0;
        for (uint32_t i27 = 0; i27 < L7.aux; i27++) {
            MoValue t14 MO_U = L7.as.xs[i27];
            L8 = t14;
            MoValue t15 MO_U = L2;
            MoValue t16 MO_U = mo_r_Clock_now((const MoValue[]){t15}, MO_KIND_NONE);
            MoValue t17 MO_U = L3;
            MoValue t18 MO_U = f17();
            MoValue t19 MO_U = mo_arith(MO_OP_ADD, t17, t18, 2);
            MoValue t20 MO_U = mo_bool(mo_compare(MO_GE, t16, t19));
            if (t20.as.b) {
                if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
                MoValue t21 MO_U = L4.as.xs[0];
                SAVE_f21();
                uint64_t w22 MO_U = mo_walks;
                FR_.walking = true;
                MoValue t23 MO_U = f40(t21, mo_str("<search>", 8), mo_i64(INT64_C(0)), mo_str("the 60 second processing deadline was exceeded", 46));
                FR_.walking = false; if (mo_walks != w22) LOAD_f21();
                MoValue t24 MO_U = L4;
                MoValue t25 MO_U = mo_set_field(t24, 0, t23);
                L4 = t25;
                goto B27;
            }
            MoValue t26 MO_U = L8.as.xs[8];
            mo_disown_in(L1);
            MoValue t27 MO_U = mo_closure(a2, 43, 1, (const MoValue[]){L1});
            MoValue t28 MO_U = mo_r_List_filter((const MoValue[]){t26, t27}, MO_KIND_NONE);
            L9 = t28;
            MoValue t29 MO_U = MO_NONE_V;
            MoValue t30 MO_U = L1.as.xs[2];
            L10 = t30;
            if (!mo_is(L10, 56)) goto F30;
            MoValue t31 MO_U = L9;
            mo_disown_in(L5);
            MoValue t32 MO_U = mo_closure(a3, 44, 1, (const MoValue[]){L5});
            MoValue t33 MO_U = mo_r_List_filter((const MoValue[]){t31, t32}, MO_KIND_NONE);
            t29 = t33;
            goto E29;
            F30:;
            if (!mo_is(L10, 57)) goto F32;
            MoValue t34 MO_U = MO_NONE_V;
            MoValue t35 MO_U = L6;
            MoValue t36 MO_U = L9;
            MoValue t37 MO_U = f22(t35, t36);
            if (t37.as.b) {
                MoValue t38 MO_U = L9;
                t34 = t38;
            } else {
                MoValue t39 MO_U = mo_list_of(0, NULL);
                t34 = t39;
            }
            t29 = t34;
            goto E29;
            F32:;
            mo_crash(3);
            E29:;
            L11 = t29;
            MoValue t40 MO_U = L11;
            MoValue t41 MO_U = mo_r_List_size((const MoValue[]){t40}, MO_KIND_NONE);
            MoValue t42 MO_U = mo_bool(t41.as.u > mo_i64(INT64_C(0)).as.u);
            if (t42.as.b) {
                MoValue t43 MO_U = L4.as.xs[1];
                MoValue t44 MO_U = mo_r_List_size((const MoValue[]){t43}, MO_KIND_NONE);
                MoValue t45 MO_U = f33(t44);
                MoValue t46 MO_U = mo_bool(!t45.as.b);
                if (t46.as.b) {
                    if (mo_walk_due(&FR_)) { SAVE_f21(); mo_walk(&FR_); LOAD_f21(); }
                    MoValue t47 MO_U = L4.as.xs[0];
                    MoValue t48 MO_U = L8.as.xs[5];
                    MoValue t49 MO_U = L8.as.xs[6];
                    SAVE_f21();
                    uint64_t w50 MO_U = mo_walks;
                    FR_.walking = true;
                    MoValue t51 MO_U = f40(t47, t48, t49, mo_str("search exceeds 10000 matching logical messages", 46));
                    FR_.walking = false; if (mo_walks != w50) LOAD_f21();
                    MoValue t52 MO_U = L4;
                    MoValue t53 MO_U = mo_set_field(t52, 0, t51);
                    L4 = t53;
                    goto B27;
                }
                MoValue t54 MO_U = L4.as.xs[1];
                MoValue t55 MO_U = L8;
                MoValue t56 MO_U = L11;
                MoValue t57 MO_U = mo_record(37, 2, (const MoValue[]){t55, t56});
                mo_disown_in(t57);
                MoValue t58 MO_U = mo_r_List_push((const MoValue[]){t54, t57}, MO_KIND_NONE);
                MoValue t59 MO_U = L4;
                MoValue t60 MO_U = mo_set_field(t59, 1, t58);
                L4 = t60;
            }
            ROOTS_f21(m27, k27);
        }
    }
    B27:;
    MoValue t61 MO_U = L4;
    R = t61;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f21
#undef SAVE_f21
#undef LOAD_f21
MO_U static MoValue a5(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("all_words_present\?");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f23(t0);
    MoValue t2 MO_U = f34(t1);
    MoValue t3 MO_U = cap[0];
    MoValue t4 MO_U = mo_r_String_contains_q((const MoValue[]){t2, t3}, MO_KIND_NONE);
    R = t4;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a4(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("all_words_present\?");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = cap[0];
    mo_disown_in(L0);
    MoValue t1 MO_U = mo_closure(a5, 46, 1, (const MoValue[]){L0});
    MoValue t2 MO_U = mo_r_List_any_q((const MoValue[]){t0, t1}, MO_KIND_NONE);
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f22(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("all_words_present\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    mo_disown_in(L1);
    MoValue t1 MO_U = mo_closure(a4, 45, 1, (const MoValue[]){L1});
    MoValue t2 MO_U = mo_r_List_all_q((const MoValue[]){t0, t1}, MO_KIND_NONE);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f23(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("searchable");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0.as.xs[0];
    MoValue t2 MO_U = mo_variant(55, 0, NULL);
    MoValue t3 MO_U = mo_bool(mo_compare(MO_EQ, t1, t2));
    if (t3.as.b) {
        MoValue t4 MO_U = L0.as.xs[1];
        MoValue t5 MO_U = L0.as.xs[2];
        MoValue t6 MO_U = mo_concat(3, (const MoValue[]){t4, mo_str("\012", 1), t5});
        t0 = t6;
    } else {
        MoValue t7 MO_U = L0.as.xs[2];
        t0 = t7;
    }
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a6(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    L1 = args[1];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1.as.xs[1];
    MoValue t2 MO_U = L1.as.xs[2];
    MoValue t3 MO_U = mo_r_Map_set((const MoValue[]){t0, t1, t2}, MO_KIND_UNIQUE);
    R = t3;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a7(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    L0 = args[0];
    L1 = args[1];
    (void)cap;
    (void)args;
    mo_disown_in(L0);
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1.as.xs[1];
    MoValue t2 MO_U = L0;
    MoValue t3 MO_U = L1.as.xs[1];
    MoValue t4 MO_U = mo_r_Map_get((const MoValue[]){t2, t3}, MO_KIND_NONE);
    L2 = t4;
    MoValue t5 MO_U = MO_NONE_V;
    if (mo_is(L2, MO_N_SOME)) {
        t5 = L2.as.xs[0];
    } else {
        MoValue t6 MO_U = mo_variant(1, 0, NULL);
        t5 = t6;
    }
    MoValue t7 MO_U = L1.as.xs[7];
    MoValue t8 MO_U = f39(t5, t7);
    MoValue t9 MO_U = mo_r_Map_set((const MoValue[]){t0, t1, t8}, MO_KIND_NONE);
    R = t9;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a9(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    mo_disown_in(cap[0]);
    MoValue t1 MO_U = cap[0];
    mo_disown_in(t1);
    MoValue t2 MO_U = mo_r_List_push((const MoValue[]){t0, t1}, MO_KIND_NONE);
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a8(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    L1 = args[1];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1.as.xs[0];
    MoValue t2 MO_U = t1.as.xs[1];
    MoValue t3 MO_U = mo_list_of(0, NULL);
    mo_disown_in(L1);
    MoValue t4 MO_U = mo_closure(a9, 50, 1, (const MoValue[]){L1});
    MoValue t5 MO_U = mo_r_Map_update((const MoValue[]){t0, t2, t3, t4}, MO_KIND_UNIQUE);
    R = t5;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a10(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = cap[0];
    MoValue t2 MO_U = L0.as.xs[0];
    MoValue t3 MO_U = mo_r_Map_get((const MoValue[]){t1, t2}, MO_KIND_NONE);
    L1 = t3;
    MoValue t4 MO_U = MO_NONE_V;
    if (mo_is(L1, MO_N_SOME)) {
        t4 = L1.as.xs[0];
    } else {
        MoValue t5 MO_U = L0.as.xs[0];
        t4 = t5;
    }
    MoValue t6 MO_U = cap[1];
    MoValue t7 MO_U = L0.as.xs[0];
    MoValue t8 MO_U = mo_r_Map_get((const MoValue[]){t6, t7}, MO_KIND_NONE);
    L2 = t8;
    MoValue t9 MO_U = MO_NONE_V;
    if (mo_is(L2, MO_N_SOME)) {
        t9 = L2.as.xs[0];
    } else {
        MoValue t10 MO_U = mo_variant(1, 0, NULL);
        t9 = t10;
    }
    MoValue t11 MO_U = L0.as.xs[1];
    MoValue t12 MO_U = mo_record(38, 4, (const MoValue[]){t0, t4, t9, t11});
    R = t12;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a11(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[2];
    L1 = t0;
    MoValue t1 MO_U = mo_bool(true);
    if (!mo_is(L1, 0)) goto F44;
    goto E45;
    F44:;
    t1 = mo_bool(false);
    E45:;
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a12(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[1];
    MoValue t1 MO_U = L0.as.xs[0];
    MoValue t2 MO_U = mo_tuple(2, (const MoValue[]){t0, t1});
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a13(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[2];
    L1 = t0;
    MoValue t1 MO_U = MO_NONE_V;
    if (mo_is(L1, MO_N_SOME)) {
        t1 = L1.as.xs[0];
    } else {
        MoValue t2 MO_U = mo_r_Time_from_parts((const MoValue[]){mo_i64(INT64_C(1970)), mo_i64(INT64_C(1)), mo_i64(INT64_C(1)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0))}, MO_KIND_NONE);
        t1 = t2;
    }
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a14(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[2];
    L1 = t0;
    MoValue t1 MO_U = mo_bool(true);
    if (!mo_is(L1, 1)) goto F49;
    goto E50;
    F49:;
    t1 = mo_bool(false);
    E50:;
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a15(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[1];
    MoValue t1 MO_U = L0.as.xs[0];
    MoValue t2 MO_U = mo_tuple(2, (const MoValue[]){t0, t1});
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f24(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("sessions_of");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t2 MO_U = mo_closure(a6, 47, 0, NULL);
    MoValue t3 MO_U = mo_r_List_reduce((const MoValue[]){t0, t1, t2}, MO_KIND_NONE);
    L2 = t3;
    MoValue t4 MO_U = L0;
    MoValue t5 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t6 MO_U = mo_closure(a7, 48, 0, NULL);
    MoValue t7 MO_U = mo_r_List_reduce((const MoValue[]){t4, t5, t6}, MO_KIND_NONE);
    L3 = t7;
    MoValue t8 MO_U = L1;
    MoValue t9 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t10 MO_U = mo_closure(a8, 49, 0, NULL);
    MoValue t11 MO_U = mo_r_List_reduce((const MoValue[]){t8, t9, t10}, MO_KIND_NONE);
    L4 = t11;
    MoValue t12 MO_U = L4;
    MoValue t13 MO_U = mo_r_Map_entries((const MoValue[]){t12}, MO_KIND_NONE);
    mo_disown_in(L2);
    mo_disown_in(L3);
    MoValue t14 MO_U = mo_closure(a10, 51, 2, (const MoValue[]){L2, L3});
    MoValue t15 MO_U = mo_r_List_map((const MoValue[]){t13, t14}, MO_KIND_NONE);
    L5 = t15;
    MoValue t16 MO_U = L5;
    MoValue t17 MO_U = mo_closure(a11, 52, 0, NULL);
    MoValue t18 MO_U = mo_r_List_filter((const MoValue[]){t16, t17}, MO_KIND_NONE);
    MoValue t19 MO_U = mo_closure(a12, 53, 0, NULL);
    MoValue t20 MO_U = mo_r_List_sort_by((const MoValue[]){t18, t19}, MO_KIND_NONE);
    MoValue t21 MO_U = mo_closure(a13, 54, 0, NULL);
    MoValue t22 MO_U = mo_r_List_sort_by_desc((const MoValue[]){t20, t21}, MO_KIND_NONE);
    L6 = t22;
    MoValue t23 MO_U = L5;
    MoValue t24 MO_U = mo_closure(a14, 55, 0, NULL);
    MoValue t25 MO_U = mo_r_List_filter((const MoValue[]){t23, t24}, MO_KIND_NONE);
    MoValue t26 MO_U = mo_closure(a15, 56, 0, NULL);
    MoValue t27 MO_U = mo_r_List_sort_by((const MoValue[]){t25, t26}, MO_KIND_NONE);
    L7 = t27;
    MoValue t28 MO_U = L6;
    MoValue t29 MO_U = L7;
    MoValue t30 MO_U = mo_r_List_concat((const MoValue[]){t28, t29}, MO_KIND_NONE);
    R = t30;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f25(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("session_heading");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0.as.xs[2];
    L1 = t1;
    if (!mo_is(L1, 0)) goto F54;
    L2 = L1.as.xs[0];
    L3 = L2;
    MoValue t2 MO_U = L3;
    MoValue t3 MO_U = mo_r_Time_to_iso8601((const MoValue[]){t2}, MO_KIND_NONE);
    t0 = t3;
    goto E53;
    F54:;
    if (!mo_is(L1, 1)) goto F55;
    t0 = mo_str("timestamp missing", 17);
    goto E53;
    F55:;
    mo_crash(4);
    E53:;
    L4 = t0;
    MoValue t4 MO_U = L0.as.xs[1];
    MoValue t5 MO_U = f37(t4, mo_i64(INT64_C(256)));
    MoValue t6 MO_U = L4;
    MoValue t7 MO_U = mo_concat(5, (const MoValue[]){mo_str("Session ", 8), t5, mo_str(" \342\200\224 latest ", 12), t6, mo_str("\012", 1)});
    R = t7;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f26() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = R; } while (0)
#define LOAD_f26() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; R = V_[9]; } while (0)
#define ROOTS_f26(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, R}; mo_compact(m, r_, 10); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; R = r_[9]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f26(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("render_hit");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    size_t m57 MO_U = 0, k57 MO_U = 0;
    MoValue V_[10];
    size_t *const M_[] = {&F_, &m57, &k57};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 10, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    if (mo_walk_due(&FR_)) { SAVE_f26(); mo_walk(&FR_); LOAD_f26(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1.as.xs[0];
    MoValue t2 MO_U = t1.as.xs[3];
    MoValue t3 MO_U = f37(t2, mo_i64(INT64_C(256)));
    MoValue t4 MO_U = L1.as.xs[0];
    MoValue t5 MO_U = t4.as.xs[4];
    MoValue t6 MO_U = f37(t5, mo_i64(INT64_C(256)));
    MoValue t7 MO_U = mo_concat(5, (const MoValue[]){mo_str("  ", 2), t3, mo_str(" message ", 9), t6, mo_str("\012", 1)});
    SAVE_f26();
    uint64_t w8 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t9 MO_U = f31(t0, t7);
    FR_.walking = false; if (mo_walks != w8) LOAD_f26();
    L2 = t9;
    MoValue t10 MO_U = L1.as.xs[1];
    L3 = t10;
    {
        m57 = mo_mark(); k57 = 0;
        for (uint32_t i57 = 0; i57 < L3.aux; i57++) {
            MoValue t11 MO_U = L3.as.xs[i57];
            L4 = t11;
            MoValue t12 MO_U = L2.as.xs[1];
            if (t12.as.b) {
                goto B57;
            }
            MoValue t13 MO_U = MO_NONE_V;
            MoValue t14 MO_U = L4.as.xs[6];
            L5 = t14;
            if (!mo_is(L5, 0)) goto F59;
            L6 = L5.as.xs[0];
            L7 = L6;
            MoValue t15 MO_U = L7;
            MoValue t16 MO_U = mo_concat(2, (const MoValue[]){mo_str(" apiBlockIndex=", 15), t15});
            t13 = t16;
            goto E58;
            F59:;
            if (!mo_is(L5, 1)) goto F60;
            t13 = mo_str("", 0);
            goto E58;
            F60:;
            mo_crash(5);
            E58:;
            L8 = t13;
            if (mo_walk_due(&FR_)) { SAVE_f26(); mo_walk(&FR_); LOAD_f26(); }
            MoValue t17 MO_U = L2;
            MoValue t18 MO_U = L4.as.xs[3];
            MoValue t19 MO_U = f37(t18, mo_i64(INT64_C(512)));
            MoValue t20 MO_U = L4.as.xs[4];
            MoValue t21 MO_U = L4.as.xs[1];
            MoValue t22 MO_U = f37(t21, mo_i64(INT64_C(256)));
            MoValue t23 MO_U = L4.as.xs[5];
            MoValue t24 MO_U = L8;
            MoValue t25 MO_U = mo_concat(11, (const MoValue[]){mo_str("    ", 4), t19, mo_str(":", 1), t20, mo_str(" ", 1), t22, mo_str(" content[", 9), t23, mo_str("]", 1), t24, mo_str("\012", 1)});
            SAVE_f26();
            uint64_t w26 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t27 MO_U = f31(t17, t25);
            FR_.walking = false; if (mo_walks != w26) LOAD_f26();
            L2 = t27;
            MoValue t28 MO_U = L2.as.xs[1];
            if (t28.as.b) {
                goto B57;
            }
            if (mo_walk_due(&FR_)) { SAVE_f26(); mo_walk(&FR_); LOAD_f26(); }
            MoValue t29 MO_U = L2;
            MoValue t30 MO_U = L4.as.xs[2];
            MoValue t31 MO_U = f27(t30);
            MoValue t32 MO_U = mo_concat(3, (const MoValue[]){mo_str("      ", 6), t31, mo_str("\012", 1)});
            SAVE_f26();
            uint64_t w33 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t34 MO_U = f31(t29, t32);
            FR_.walking = false; if (mo_walks != w33) LOAD_f26();
            L2 = t34;
            ROOTS_f26(m57, k57);
        }
    }
    B57:;
    MoValue t35 MO_U = L2;
    R = t35;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f26
#undef SAVE_f26
#undef LOAD_f26
#define SAVE_f27() do { V_[0] = L0; V_[1] = R; } while (0)
#define LOAD_f27() do { L0 = V_[0]; R = V_[1]; } while (0)
MO_U static MoValue f27(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("bounded_excerpt");
    MoValue V_[2];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 2, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    if (mo_walk_due(&FR_)) { SAVE_f27(); mo_walk(&FR_); LOAD_f27(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f14();
    SAVE_f27();
    uint64_t w2 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t3 MO_U = f37(t0, t1);
    FR_.walking = false; if (mo_walks != w2) LOAD_f27();
    R = t3;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f27
#undef LOAD_f27
#define SAVE_f28() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = R; } while (0)
#define LOAD_f28() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; R = V_[4]; } while (0)
MO_U static MoValue f28(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("diagnostics_text");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue V_[5];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 5, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_record(41, 2, (const MoValue[]){mo_str("", 0), mo_bool(false)});
    L2 = t0;
    MoValue t1 MO_U = L0.as.xs[8];
    if (t1.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f28(); mo_walk(&FR_); LOAD_f28(); }
        MoValue t2 MO_U = L2;
        mo_disown_in(L0);
        MoValue t3 MO_U = L0;
        MoValue t4 MO_U = L1;
        SAVE_f28();
        uint64_t w5 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t6 MO_U = f30(t2, t3, t4);
        FR_.walking = false; if (mo_walks != w5) LOAD_f28();
        L2 = t6;
    }
    MoValue t7 MO_U = L2.as.xs[1];
    MoValue t8 MO_U = mo_bool(!t7.as.b);
    if (t8.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f28(); mo_walk(&FR_); LOAD_f28(); }
        MoValue t9 MO_U = L2;
        MoValue t10 MO_U = L0;
        MoValue t11 MO_U = L1;
        SAVE_f28();
        uint64_t w12 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t13 MO_U = f29(t9, t10, t11);
        FR_.walking = false; if (mo_walks != w12) LOAD_f28();
        L2 = t13;
    }
    MoValue t14 MO_U = L2.as.xs[1];
    if (t14.as.b) {
        L3 = mo_str("moscope: incomplete: diagnostics exceed the 8 MiB rendered-output limit\012", 72);
        MoValue t15 MO_U = L2.as.xs[0];
        MoValue t16 MO_U = mo_r_String_byte_size((const MoValue[]){t15}, MO_KIND_NONE);
        MoValue t17 MO_U = L3;
        MoValue t18 MO_U = mo_r_String_byte_size((const MoValue[]){t17}, MO_KIND_NONE);
        MoValue t19 MO_U = mo_r_Int_saturating_add((const MoValue[]){t16, t18}, 7);
        MoValue t20 MO_U = L1;
        MoValue t21 MO_U = mo_bool(t19.as.u <= t20.as.u);
        if (t21.as.b) {
            MoValue t22 MO_U = L2.as.xs[0];
            MoValue t23 MO_U = L3;
            MoValue t24 MO_U = mo_concat(2, (const MoValue[]){t22, t23});
            MoValue t25 MO_U = L2;
            MoValue t26 MO_U = mo_set_field(t25, 0, t24);
            L2 = t26;
        }
    }
    MoValue t27 MO_U = L2;
    R = t27;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f28
#undef LOAD_f28
MO_U static MoValue a16(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("notices_text");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    R = t0;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f29() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = R; } while (0)
#define LOAD_f29() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; R = V_[6]; } while (0)
#define ROOTS_f29(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, R}; mo_compact(m, r_, 7); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; R = r_[6]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f29(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("notices_text");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    size_t m65 MO_U = 0, k65 MO_U = 0;
    MoValue V_[7];
    size_t *const M_[] = {&F_, &m65, &k65};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 7, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L3 = t0;
    MoValue t1 MO_U = L1.as.xs[3];
    MoValue t2 MO_U = mo_bool(t1.as.u > mo_i64(INT64_C(0)).as.u);
    if (t2.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f29(); mo_walk(&FR_); LOAD_f29(); }
        MoValue t3 MO_U = L3;
        MoValue t4 MO_U = L1.as.xs[3];
        MoValue t5 MO_U = mo_concat(3, (const MoValue[]){mo_str("moscope: diagnostic: skipped ", 29), t4, mo_str(" discovered symlinks\012", 21)});
        MoValue t6 MO_U = L2;
        SAVE_f29();
        uint64_t w7 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t8 MO_U = f32(t3, t5, t6);
        FR_.walking = false; if (mo_walks != w7) LOAD_f29();
        L3 = t8;
    }
    MoValue t9 MO_U = L3.as.xs[1];
    if (t9.as.b) {
        mo_disown_in(L3);
        MoValue t10 MO_U = L3;
        R = t10;
        goto X63;
    }
    MoValue t11 MO_U = L1;
    MoValue t12 MO_U = t11.as.xs[2];
    MoValue t13 MO_U = mo_r_Map_entries((const MoValue[]){t12}, MO_KIND_NONE);
    MoValue t14 MO_U = mo_closure(a16, 57, 0, NULL);
    MoValue t15 MO_U = mo_r_List_sort_by((const MoValue[]){t13, t14}, MO_KIND_NONE);
    L4 = t15;
    {
        m65 = mo_mark(); k65 = 0;
        for (uint32_t i65 = 0; i65 < L4.aux; i65++) {
            MoValue t16 MO_U = L4.as.xs[i65];
            L5 = t16;
            if (mo_walk_due(&FR_)) { SAVE_f29(); mo_walk(&FR_); LOAD_f29(); }
            MoValue t17 MO_U = L3;
            MoValue t18 MO_U = L5.as.xs[1];
            MoValue t19 MO_U = L5.as.xs[0];
            MoValue t20 MO_U = f37(t19, mo_i64(INT64_C(256)));
            MoValue t21 MO_U = mo_concat(5, (const MoValue[]){mo_str("moscope: diagnostic: ignored ", 29), t18, mo_str(" records of kind ", 17), t20, mo_str("\012", 1)});
            MoValue t22 MO_U = L2;
            SAVE_f29();
            uint64_t w23 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t24 MO_U = f32(t17, t21, t22);
            FR_.walking = false; if (mo_walks != w23) LOAD_f29();
            L3 = t24;
            MoValue t25 MO_U = L3.as.xs[1];
            if (t25.as.b) {
                goto B65;
            }
            ROOTS_f29(m65, k65);
        }
    }
    B65:;
    MoValue t26 MO_U = L3;
    R = t26;
    X63:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f29
#undef SAVE_f29
#undef LOAD_f29
MO_U static MoValue a17(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("incomplete_text");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = mo_bool(mo_compare(MO_EQ, t0, mo_str("<output>", 8)));
    MoValue t2 MO_U = mo_bool(false);
    if (t1.as.b) {
        MoValue t3 MO_U = L0.as.xs[2];
        MoValue t4 MO_U = mo_bool(mo_compare(MO_EQ, t3, mo_str("rendered output exceeds 8 MiB", 29)));
        t2 = t4;
    }
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a18(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("incomplete_text");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0.as.xs[0];
    MoValue t1 MO_U = mo_bool(mo_compare(MO_NE, t0, mo_str("<output>", 8)));
    MoValue t2 MO_U = mo_bool(true);
    if (!t1.as.b) {
        MoValue t3 MO_U = L0.as.xs[2];
        MoValue t4 MO_U = mo_bool(mo_compare(MO_NE, t3, mo_str("rendered output exceeds 8 MiB", 29)));
        t2 = t4;
    }
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f30() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = L4; V_[5] = L5; V_[6] = L6; V_[7] = L7; V_[8] = L8; V_[9] = L9; V_[10] = R; } while (0)
#define LOAD_f30() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; L4 = V_[4]; L5 = V_[5]; L6 = V_[6]; L7 = V_[7]; L8 = V_[8]; L9 = V_[9]; R = V_[10]; } while (0)
#define ROOTS_f30(m, k) do { if (mo_loop_due(m, k)) { MoValue r_[] = {L0, L1, L2, L3, L4, L5, L6, L7, L8, L9, R}; mo_compact(m, r_, 11); L0 = r_[0]; L1 = r_[1]; L2 = r_[2]; L3 = r_[3]; L4 = r_[4]; L5 = r_[5]; L6 = r_[6]; L7 = r_[7]; L8 = r_[8]; L9 = r_[9]; R = r_[10]; k = mo_heap.top - m; } } while (0)
MO_U static MoValue f30(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("incomplete_text");
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    size_t m69 MO_U = 0, k69 MO_U = 0;
    MoValue V_[11];
    size_t *const M_[] = {&F_, &m69, &k69};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 11, M_, 3};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L3 = t0;
    MoValue t1 MO_U = L1.as.xs[1];
    MoValue t2 MO_U = mo_closure(a17, 58, 0, NULL);
    MoValue t3 MO_U = mo_r_List_filter((const MoValue[]){t1, t2}, MO_KIND_NONE);
    L4 = t3;
    MoValue t4 MO_U = L1.as.xs[1];
    MoValue t5 MO_U = mo_closure(a18, 59, 0, NULL);
    MoValue t6 MO_U = mo_r_List_filter((const MoValue[]){t4, t5}, MO_KIND_NONE);
    L5 = t6;
    MoValue t7 MO_U = L4;
    MoValue t8 MO_U = L5;
    MoValue t9 MO_U = mo_r_List_concat((const MoValue[]){t7, t8}, MO_KIND_NONE);
    L6 = t9;
    {
        m69 = mo_mark(); k69 = 0;
        for (uint32_t i69 = 0; i69 < L6.aux; i69++) {
            MoValue t10 MO_U = L6.as.xs[i69];
            L7 = t10;
            if (mo_walk_due(&FR_)) { SAVE_f30(); mo_walk(&FR_); LOAD_f30(); }
            MoValue t11 MO_U = L7.as.xs[0];
            SAVE_f30();
            uint64_t w12 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t13 MO_U = f37(t11, mo_i64(INT64_C(512)));
            FR_.walking = false; if (mo_walks != w12) LOAD_f30();
            L8 = t13;
            MoValue t14 MO_U = MO_NONE_V;
            MoValue t15 MO_U = L7.as.xs[1];
            MoValue t16 MO_U = mo_bool(t15.as.u == mo_i64(INT64_C(0)).as.u);
            if (t16.as.b) {
                MoValue t17 MO_U = L8;
                t14 = t17;
            } else {
                MoValue t18 MO_U = L8;
                MoValue t19 MO_U = L7.as.xs[1];
                MoValue t20 MO_U = mo_concat(3, (const MoValue[]){t18, mo_str(":", 1), t19});
                t14 = t20;
            }
            L9 = t14;
            if (mo_walk_due(&FR_)) { SAVE_f30(); mo_walk(&FR_); LOAD_f30(); }
            MoValue t21 MO_U = L3;
            MoValue t22 MO_U = L9;
            MoValue t23 MO_U = L7.as.xs[2];
            MoValue t24 MO_U = f37(t23, mo_i64(INT64_C(512)));
            MoValue t25 MO_U = mo_concat(5, (const MoValue[]){mo_str("moscope: incomplete: ", 21), t22, mo_str(": ", 2), t24, mo_str("\012", 1)});
            MoValue t26 MO_U = L2;
            SAVE_f30();
            uint64_t w27 MO_U = mo_walks;
            FR_.walking = true;
            MoValue t28 MO_U = f32(t21, t25, t26);
            FR_.walking = false; if (mo_walks != w27) LOAD_f30();
            L3 = t28;
            MoValue t29 MO_U = L3.as.xs[1];
            if (t29.as.b) {
                goto B69;
            }
            ROOTS_f30(m69, k69);
        }
    }
    B69:;
    MoValue t30 MO_U = L3.as.xs[1];
    MoValue t31 MO_U = mo_bool(!t30.as.b);
    MoValue t32 MO_U = mo_bool(false);
    if (t31.as.b) {
        MoValue t33 MO_U = L1.as.xs[1];
        MoValue t34 MO_U = mo_r_List_size((const MoValue[]){t33}, MO_KIND_NONE);
        MoValue t35 MO_U = f13();
        MoValue t36 MO_U = mo_bool(t34.as.u >= t35.as.u);
        t32 = t36;
    }
    if (t32.as.b) {
        if (mo_walk_due(&FR_)) { SAVE_f30(); mo_walk(&FR_); LOAD_f30(); }
        MoValue t37 MO_U = L3;
        MoValue t38 MO_U = L2;
        SAVE_f30();
        uint64_t w39 MO_U = mo_walks;
        FR_.walking = true;
        MoValue t40 MO_U = f32(t37, mo_str("moscope: incomplete: diagnostic retention limit reached\012", 56), t38);
        FR_.walking = false; if (mo_walks != w39) LOAD_f30();
        L3 = t40;
    }
    MoValue t41 MO_U = L3;
    R = t41;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef ROOTS_f30
#undef SAVE_f30
#undef LOAD_f30
#define SAVE_f31() do { V_[0] = L0; V_[1] = L1; V_[2] = R; } while (0)
#define LOAD_f31() do { L0 = V_[0]; L1 = V_[1]; R = V_[2]; } while (0)
MO_U static MoValue f31(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("append");
    MoValue V_[3];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 3, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    if (mo_walk_due(&FR_)) { SAVE_f31(); mo_walk(&FR_); LOAD_f31(); }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L1;
    MoValue t2 MO_U = f15();
    MoValue t3 MO_U = mo_r_Int_saturating_sub((const MoValue[]){t2, mo_i64(INT64_C(512))}, 7);
    SAVE_f31();
    uint64_t w4 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t5 MO_U = f32(t0, t1, t3);
    FR_.walking = false; if (mo_walks != w4) LOAD_f31();
    R = t5;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f31
#undef LOAD_f31
MO_U static MoValue f32(MoValue L0, MoValue L1, MoValue L2) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("append_limit");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0.as.xs[1];
    if (t0.as.b) {
        mo_disown_in(L0);
        MoValue t1 MO_U = L0;
        R = t1;
        goto X71;
    }
    MoValue t2 MO_U = L0.as.xs[0];
    MoValue t3 MO_U = mo_r_String_byte_size((const MoValue[]){t2}, MO_KIND_NONE);
    MoValue t4 MO_U = L1;
    MoValue t5 MO_U = mo_r_String_byte_size((const MoValue[]){t4}, MO_KIND_NONE);
    MoValue t6 MO_U = mo_r_Int_saturating_add((const MoValue[]){t3, t5}, 7);
    MoValue t7 MO_U = L2;
    MoValue t8 MO_U = mo_bool(t6.as.u > t7.as.u);
    if (t8.as.b) {
        MoValue t9 MO_U = L0.as.xs[0];
        MoValue t10 MO_U = mo_record(41, 2, (const MoValue[]){t9, mo_bool(true)});
        R = t10;
        goto X71;
    }
    MoValue t11 MO_U = L0.as.xs[0];
    MoValue t12 MO_U = L1;
    MoValue t13 MO_U = mo_concat(2, (const MoValue[]){t11, t12});
    MoValue t14 MO_U = mo_record(41, 2, (const MoValue[]){t13, mo_bool(false)});
    R = t14;
    X71:;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f33(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("result_admitted\?");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = f12();
    MoValue t2 MO_U = mo_bool(t0.as.u < t1.as.u);
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a19(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("ascii_lower");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_bool(t1.as.u >= mo_i64(INT64_C(65)).as.u);
    MoValue t3 MO_U = mo_bool(false);
    if (t2.as.b) {
        MoValue t4 MO_U = L0;
        MoValue t5 MO_U = mo_bool(t4.as.u <= mo_i64(INT64_C(90)).as.u);
        t3 = t5;
    }
    if (t3.as.b) {
        MoValue t6 MO_U = L0;
        MoValue t7 MO_U = mo_add_u8(t6, mo_i64(INT64_C(32)), 6);
        t0 = t7;
    } else {
        MoValue t8 MO_U = L0;
        t0 = t8;
    }
    R = t0;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f34(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("ascii_lower");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_String_bytes((const MoValue[]){t0}, MO_KIND_NONE);
    MoValue t2 MO_U = mo_closure(a19, 60, 0, NULL);
    MoValue t3 MO_U = mo_r_List_map((const MoValue[]){t1, t2}, 4);
    L1 = t3;
    MoValue t4 MO_U = L1;
    MoValue t5 MO_U = mo_r_String_from_bytes((const MoValue[]){t4}, MO_KIND_NONE);
    L2 = t5;
    MoValue t6 MO_U = MO_NONE_V;
    if (mo_is(L2, MO_N_SOME)) {
        t6 = L2.as.xs[0];
    } else {
        t6 = mo_str("", 0);
    }
    R = t6;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a20(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_terms");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_bool(t1.as.u == mo_i64(INT64_C(9)).as.u);
    MoValue t3 MO_U = mo_bool(true);
    if (!t2.as.b) {
        MoValue t4 MO_U = L0;
        MoValue t5 MO_U = mo_bool(t4.as.u == mo_i64(INT64_C(10)).as.u);
        t3 = t5;
    }
    MoValue t6 MO_U = mo_bool(true);
    if (!t3.as.b) {
        MoValue t7 MO_U = L0;
        MoValue t8 MO_U = mo_bool(t7.as.u == mo_i64(INT64_C(11)).as.u);
        t6 = t8;
    }
    MoValue t9 MO_U = mo_bool(true);
    if (!t6.as.b) {
        MoValue t10 MO_U = L0;
        MoValue t11 MO_U = mo_bool(t10.as.u == mo_i64(INT64_C(12)).as.u);
        t9 = t11;
    }
    MoValue t12 MO_U = mo_bool(true);
    if (!t9.as.b) {
        MoValue t13 MO_U = L0;
        MoValue t14 MO_U = mo_bool(t13.as.u == mo_i64(INT64_C(13)).as.u);
        t12 = t14;
    }
    if (t12.as.b) {
        t0 = mo_i64(INT64_C(32));
    } else {
        MoValue t15 MO_U = L0;
        t0 = t15;
    }
    R = t0;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a21(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_terms");
    MoValue L0 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_bool(mo_compare(MO_NE, t0, mo_str("", 0)));
    R = t1;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_a22() do { V_[0] = L0; V_[1] = R; } while (0)
#define LOAD_a22() do { L0 = V_[0]; R = V_[1]; } while (0)
MO_U static MoValue a22(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_terms");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue V_[2];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 2, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    L0 = args[0];
    (void)cap;
    (void)args;
    if (mo_walk_due(&FR_)) { SAVE_a22(); mo_walk(&FR_); LOAD_a22(); }
    MoValue t0 MO_U = L0;
    SAVE_a22();
    uint64_t w1 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t2 MO_U = f34(t0);
    FR_.walking = false; if (mo_walks != w1) LOAD_a22();
    R = t2;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_a22
#undef LOAD_a22
MO_U static MoValue f35(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("query_terms");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_String_bytes((const MoValue[]){t0}, MO_KIND_NONE);
    MoValue t2 MO_U = mo_closure(a20, 61, 0, NULL);
    MoValue t3 MO_U = mo_r_List_map((const MoValue[]){t1, t2}, 4);
    L1 = t3;
    MoValue t4 MO_U = L1;
    MoValue t5 MO_U = mo_r_String_from_bytes((const MoValue[]){t4}, MO_KIND_NONE);
    L2 = t5;
    MoValue t6 MO_U = MO_NONE_V;
    if (mo_is(L2, MO_N_SOME)) {
        t6 = L2.as.xs[0];
    } else {
        t6 = mo_str("", 0);
    }
    L3 = t6;
    MoValue t7 MO_U = L3;
    MoValue t8 MO_U = mo_r_String_split((const MoValue[]){t7, mo_str(" ", 1)}, MO_KIND_NONE);
    MoValue t9 MO_U = mo_closure(a21, 62, 0, NULL);
    MoValue t10 MO_U = mo_r_List_filter((const MoValue[]){t8, t9}, MO_KIND_NONE);
    MoValue t11 MO_U = mo_closure(a22, 63, 0, NULL);
    MoValue t12 MO_U = mo_r_List_map((const MoValue[]){t10, t11}, MO_KIND_NONE);
    R = t12;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue a23(const MoValue *cap, const MoValue *args) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("safe");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    L0 = args[0];
    (void)cap;
    (void)args;
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_bool(t1.as.u >= mo_i64(INT64_C(32)).as.u);
    MoValue t3 MO_U = mo_bool(false);
    if (t2.as.b) {
        MoValue t4 MO_U = L0;
        MoValue t5 MO_U = mo_bool(t4.as.u <= mo_i64(INT64_C(126)).as.u);
        t3 = t5;
    }
    MoValue t6 MO_U = mo_bool(false);
    if (t3.as.b) {
        MoValue t7 MO_U = L0;
        MoValue t8 MO_U = mo_bool(t7.as.u != mo_i64(INT64_C(92)).as.u);
        t6 = t8;
    }
    if (t6.as.b) {
        MoValue t9 MO_U = L0;
        MoValue t10 MO_U = mo_list_of(1, (const MoValue[]){t9});
        MoValue t11 MO_U = mo_r_String_from_bytes((const MoValue[]){t10}, MO_KIND_NONE);
        L1 = t11;
        MoValue t12 MO_U = MO_NONE_V;
        if (mo_is(L1, MO_N_SOME)) {
            t12 = L1.as.xs[0];
        } else {
            t12 = mo_str("", 0);
        }
        t0 = t12;
    } else {
        MoValue t13 MO_U = MO_NONE_V;
        MoValue t14 MO_U = L0;
        MoValue t15 MO_U = mo_bool(t14.as.u == mo_i64(INT64_C(92)).as.u);
        if (t15.as.b) {
            t13 = mo_str("\\\\", 2);
        } else {
            MoValue t16 MO_U = L0;
            MoValue t17 MO_U = f38(t16);
            MoValue t18 MO_U = mo_concat(2, (const MoValue[]){mo_str("\\x", 2), t17});
            t13 = t18;
        }
        t0 = t13;
    }
    R = t0;
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f36(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("safe");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_r_String_bytes((const MoValue[]){t0}, MO_KIND_NONE);
    MoValue t2 MO_U = mo_closure(a23, 64, 0, NULL);
    MoValue t3 MO_U = mo_r_List_map((const MoValue[]){t1, t2}, 4);
    MoValue t4 MO_U = mo_r_String_join((const MoValue[]){t3, mo_str("", 0)}, MO_KIND_NONE);
    R = t4;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_f37() do { V_[0] = L0; V_[1] = L1; V_[2] = L2; V_[3] = L3; V_[4] = R; } while (0)
#define LOAD_f37() do { L0 = V_[0]; L1 = V_[1]; L2 = V_[2]; L3 = V_[3]; R = V_[4]; } while (0)
MO_U static MoValue f37(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("safe_prefix");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue V_[5];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 5, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = mo_r_String_size((const MoValue[]){t1}, MO_KIND_NONE);
    MoValue t3 MO_U = L1;
    MoValue t4 MO_U = mo_r_min_of((const MoValue[]){t2, t3}, MO_KIND_NONE);
    MoValue t5 MO_U = mo_r_String_slice((const MoValue[]){t0, mo_i64(INT64_C(0)), t4}, MO_KIND_NONE);
    L2 = t5;
    if (mo_walk_due(&FR_)) { SAVE_f37(); mo_walk(&FR_); LOAD_f37(); }
    MoValue t6 MO_U = L2;
    SAVE_f37();
    uint64_t w7 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t8 MO_U = f36(t6);
    FR_.walking = false; if (mo_walks != w7) LOAD_f37();
    L3 = t8;
    MoValue t9 MO_U = MO_NONE_V;
    MoValue t10 MO_U = L0;
    MoValue t11 MO_U = mo_r_String_size((const MoValue[]){t10}, MO_KIND_NONE);
    MoValue t12 MO_U = L1;
    MoValue t13 MO_U = mo_bool(t11.as.u > t12.as.u);
    if (t13.as.b) {
        MoValue t14 MO_U = L3;
        MoValue t15 MO_U = mo_concat(2, (const MoValue[]){t14, mo_str("...", 3)});
        t9 = t15;
    } else {
        MoValue t16 MO_U = L3;
        t9 = t16;
    }
    R = t9;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_f37
#undef LOAD_f37
MO_U static MoValue f38(MoValue L0) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("hex");
    MoValue L1 MO_U = MO_NONE_V;
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    L1 = mo_str("0123456789ABCDEF", 16);
    MoValue t0 MO_U = L0;
    MoValue t1 MO_U = mo_div_u8(t0, mo_i64(INT64_C(16)), 7);
    MoValue t2 MO_U = mo_r_Int_to_u64((const MoValue[]){t1}, 4);
    L2 = t2;
    MoValue t3 MO_U = L0;
    MoValue t4 MO_U = mo_rem_u8(t3, mo_i64(INT64_C(16)), 8);
    MoValue t5 MO_U = mo_r_Int_to_u64((const MoValue[]){t4}, 4);
    L3 = t5;
    MoValue t6 MO_U = L1;
    MoValue t7 MO_U = L2;
    MoValue t8 MO_U = L2;
    MoValue t9 MO_U = mo_add_u64(t8, mo_i64(INT64_C(1)), 9);
    MoValue t10 MO_U = mo_r_String_slice((const MoValue[]){t6, t7, t9}, MO_KIND_NONE);
    MoValue t11 MO_U = L1;
    MoValue t12 MO_U = L3;
    MoValue t13 MO_U = L3;
    MoValue t14 MO_U = mo_add_u64(t13, mo_i64(INT64_C(1)), 10);
    MoValue t15 MO_U = mo_r_String_slice((const MoValue[]){t11, t12, t14}, MO_KIND_NONE);
    MoValue t16 MO_U = mo_concat(2, (const MoValue[]){t10, t15});
    R = t16;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f39(MoValue L0, MoValue L1) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("later");
    MoValue L2 MO_U = MO_NONE_V;
    MoValue L3 MO_U = MO_NONE_V;
    MoValue L4 MO_U = MO_NONE_V;
    MoValue L5 MO_U = MO_NONE_V;
    MoValue L6 MO_U = MO_NONE_V;
    MoValue L7 MO_U = MO_NONE_V;
    MoValue L8 MO_U = MO_NONE_V;
    MoValue L9 MO_U = MO_NONE_V;
    MoValue L10 MO_U = MO_NONE_V;
    MoValue L11 MO_U = MO_NONE_V;
    MoValue L12 MO_U = MO_NONE_V;
    MoValue L13 MO_U = MO_NONE_V;
    MoValue L14 MO_U = MO_NONE_V;
    MoValue L15 MO_U = MO_NONE_V;
    MoValue L16 MO_U = MO_NONE_V;
    MoValue L17 MO_U = MO_NONE_V;
    MoValue L18 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = MO_NONE_V;
    MoValue t1 MO_U = L0;
    MoValue t2 MO_U = L1;
    MoValue t3 MO_U = mo_tuple(2, (const MoValue[]){t1, t2});
    L2 = t3;
    L3 = L2.as.xs[0];
    if (!mo_is(L3, 0)) goto F85;
    L4 = L3.as.xs[0];
    L5 = L4;
    L6 = L2.as.xs[1];
    if (!mo_is(L6, 0)) goto F85;
    L7 = L6.as.xs[0];
    L8 = L7;
    MoValue t4 MO_U = L5;
    MoValue t5 MO_U = L8;
    MoValue t6 MO_U = mo_r_max_of((const MoValue[]){t4, t5}, MO_KIND_NONE);
    MoValue t7 MO_U = mo_variant(0, 1, (const MoValue[]){t6});
    t0 = t7;
    goto E84;
    F85:;
    L9 = L2.as.xs[0];
    if (!mo_is(L9, 0)) goto F86;
    L10 = L9.as.xs[0];
    L11 = L10;
    L12 = L2.as.xs[1];
    if (!mo_is(L12, 1)) goto F86;
    MoValue t8 MO_U = L11;
    MoValue t9 MO_U = mo_variant(0, 1, (const MoValue[]){t8});
    t0 = t9;
    goto E84;
    F86:;
    L13 = L2.as.xs[0];
    if (!mo_is(L13, 1)) goto F87;
    L14 = L2.as.xs[1];
    if (!mo_is(L14, 0)) goto F87;
    L15 = L14.as.xs[0];
    L16 = L15;
    MoValue t10 MO_U = L16;
    MoValue t11 MO_U = mo_variant(0, 1, (const MoValue[]){t10});
    t0 = t11;
    goto E84;
    F87:;
    L17 = L2.as.xs[0];
    if (!mo_is(L17, 1)) goto F88;
    L18 = L2.as.xs[1];
    if (!mo_is(L18, 1)) goto F88;
    MoValue t12 MO_U = mo_variant(1, 0, NULL);
    t0 = t12;
    goto E84;
    F88:;
    mo_crash(11);
    E84:;
    R = t0;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f40(MoValue L0, MoValue L1, MoValue L2, MoValue L3) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("problem");
    MoValue L4 MO_U = MO_NONE_V;
    if (mo_contracts) {
    }
    MoValue t0 MO_U = L0;
    L4 = t0;
    MoValue t1 MO_U = L4;
    MoValue t2 MO_U = mo_set_field(t1, 8, mo_bool(true));
    L4 = t2;
    MoValue t3 MO_U = L4.as.xs[1];
    MoValue t4 MO_U = mo_r_List_size((const MoValue[]){t3}, MO_KIND_NONE);
    MoValue t5 MO_U = f13();
    MoValue t6 MO_U = mo_bool(t4.as.u < t5.as.u);
    if (t6.as.b) {
        MoValue t7 MO_U = L4.as.xs[1];
        MoValue t8 MO_U = L1;
        MoValue t9 MO_U = L2;
        MoValue t10 MO_U = L3;
        MoValue t11 MO_U = mo_record(34, 3, (const MoValue[]){t8, t9, t10});
        mo_disown_in(t11);
        MoValue t12 MO_U = mo_r_List_push((const MoValue[]){t7, t11}, MO_KIND_NONE);
        MoValue t13 MO_U = L4;
        MoValue t14 MO_U = mo_set_field(t13, 1, t12);
        L4 = t14;
    }
    MoValue t15 MO_U = L4;
    R = t15;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue test0(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("ASCII folding leaves non-ASCII exact, and punctuation remains literal");
    MoValue t0 MO_U = f34(mo_str("Connection REFUSED \303\211", 21));
    if (!mo_compare(MO_EQ, t0, mo_str("connection refused \303\211", 21))) mo_crash_values(12, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t0, mo_str("connection refused \303\211", 21)});
    MoValue t1 MO_U = f34(mo_str("\303\211", 2));
    MoValue t2 MO_U = f34(mo_str("\303\251", 2));
    if (!mo_compare(MO_NE, t1, t2)) mo_crash_values(13, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t1, t2});
    MoValue t3 MO_U = f34(mo_str("a.b[", 4));
    if (!mo_compare(MO_EQ, t3, mo_str("a.b[", 4))) mo_crash_values(14, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t3, mo_str("a.b[", 4)});
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue test1(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("all-words uses exactly the six ASCII whitespace bytes");
    MoValue t0 MO_U = f35(mo_str("  one\011two\012THREE\013four\014five\015 ", 27));
    MoValue t1 MO_U = mo_list_of(5, (const MoValue[]){mo_str("one", 3), mo_str("two", 3), mo_str("three", 5), mo_str("four", 4), mo_str("five", 4)});
    if (!mo_compare(MO_EQ, t0, t1)) mo_crash_values(15, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t0, t1});
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue test2(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("safe output has no raw controls or non-ASCII bytes");
    MoValue t0 MO_U = f36(mo_str("a\033[31m caf\303\251\\z", 14));
    if (!mo_compare(MO_EQ, t0, mo_str("a\\x1B[31m caf\\xC3\\xA9\\\\z", 24))) mo_crash_values(16, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t0, mo_str("a\\x1B[31m caf\\xC3\\xA9\\\\z", 24)});
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue test3(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("terminal safety covers NUL DEL and bidi while doubling backslash");
    MoValue t0 MO_U = f36(mo_str("A\\\000\177\303\251", 6));
    if (!mo_compare(MO_EQ, t0, mo_str("A\\\\\\x00\\x7F\\xC3\\xA9", 19))) mo_crash_values(17, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t0, mo_str("A\\\\\\x00\\x7F\\xC3\\xA9", 19)});
    MoValue t1 MO_U = f36(mo_str("\342\200\256", 3));
    if (!mo_compare(MO_EQ, t1, mo_str("\\xE2\\x80\\xAE", 12))) mo_crash_values(18, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t1, mo_str("\\xE2\\x80\\xAE", 12)});
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_test4() do { V_[0] = L0; V_[1] = L1; V_[2] = R; } while (0)
#define LOAD_test4() do { L0 = V_[0]; L1 = V_[1]; R = V_[2]; } while (0)
MO_U static MoValue test4(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("excerpt boundaries and output admission differ on both sides of the limit");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue V_[3];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 3, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    MoValue t0 MO_U = mo_r_String_repeat((const MoValue[]){mo_str("x", 1), mo_i64(INT64_C(239))}, MO_KIND_NONE);
    MoValue t1 MO_U = f27(t0);
    MoValue t2 MO_U = mo_r_String_size((const MoValue[]){t1}, MO_KIND_NONE);
    if (!mo_compare(MO_EQ, t2, mo_i64(INT64_C(239)))) mo_crash_values(19, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t2, mo_i64(INT64_C(239))});
    MoValue t3 MO_U = mo_r_String_repeat((const MoValue[]){mo_str("x", 1), mo_i64(INT64_C(240))}, MO_KIND_NONE);
    MoValue t4 MO_U = f27(t3);
    MoValue t5 MO_U = mo_r_String_size((const MoValue[]){t4}, MO_KIND_NONE);
    if (!mo_compare(MO_EQ, t5, mo_i64(INT64_C(240)))) mo_crash_values(20, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t5, mo_i64(INT64_C(240))});
    MoValue t6 MO_U = mo_r_String_repeat((const MoValue[]){mo_str("x", 1), mo_i64(INT64_C(241))}, MO_KIND_NONE);
    MoValue t7 MO_U = f27(t6);
    MoValue t8 MO_U = mo_r_String_size((const MoValue[]){t7}, MO_KIND_NONE);
    if (!mo_compare(MO_EQ, t8, mo_i64(INT64_C(243)))) mo_crash_values(21, 2, (const char *const[]){"left", "right"}, (const MoValue[]){t8, mo_i64(INT64_C(243))});
    if (mo_walk_due(&FR_)) { SAVE_test4(); mo_walk(&FR_); LOAD_test4(); }
    MoValue t9 MO_U = mo_record(41, 2, (const MoValue[]){mo_str("1234", 4), mo_bool(false)});
    SAVE_test4();
    uint64_t w10 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t11 MO_U = f32(t9, mo_str("5", 1), mo_i64(INT64_C(4)));
    FR_.walking = false; if (mo_walks != w10) LOAD_test4();
    L0 = t11;
    MoValue t12 MO_U = L0.as.xs[0];
    MoValue t13 MO_U = mo_bool(mo_compare(MO_EQ, t12, mo_str("1234", 4)));
    MoValue t14 MO_U = mo_bool(false);
    if (t13.as.b) {
        MoValue t15 MO_U = L0.as.xs[1];
        t14 = t15;
    }
    if (!t14.as.b) mo_crash(22);
    if (mo_walk_due(&FR_)) { SAVE_test4(); mo_walk(&FR_); LOAD_test4(); }
    MoValue t16 MO_U = mo_record(41, 2, (const MoValue[]){mo_str("1234", 4), mo_bool(false)});
    SAVE_test4();
    uint64_t w17 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t18 MO_U = f32(t16, mo_str("5", 1), mo_i64(INT64_C(5)));
    FR_.walking = false; if (mo_walks != w17) LOAD_test4();
    L1 = t18;
    MoValue t19 MO_U = L1.as.xs[0];
    MoValue t20 MO_U = mo_bool(mo_compare(MO_EQ, t19, mo_str("12345", 5)));
    MoValue t21 MO_U = mo_bool(false);
    if (t20.as.b) {
        MoValue t22 MO_U = L1.as.xs[1];
        MoValue t23 MO_U = mo_bool(!t22.as.b);
        t21 = t23;
    }
    if (!t21.as.b) mo_crash(23);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_test4
#undef LOAD_test4
MO_U static MoValue test5(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("production result admission differs at the matching-message boundary");
    MoValue t0 MO_U = f33(mo_i64(INT64_C(9999)));
    MoValue t1 MO_U = mo_bool(false);
    if (t0.as.b) {
        MoValue t2 MO_U = f33(mo_i64(INT64_C(10000)));
        MoValue t3 MO_U = mo_bool(!t2.as.b);
        t1 = t3;
    }
    if (!t1.as.b) mo_crash(24);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}

int main(void) {
    return mo_run_tests();
}
