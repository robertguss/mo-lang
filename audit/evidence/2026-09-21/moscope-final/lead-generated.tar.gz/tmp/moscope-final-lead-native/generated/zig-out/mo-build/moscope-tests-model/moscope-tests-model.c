/* Written by mo build (toolchain/src/emit_c.zig); links toolchain/runtime/mo_rt.c. */
#include "mo_rt.h"

MO_U static MoValue f0(void);
MO_U static MoValue f1(void);
MO_U static MoValue test0(void);

static const MoField decl_fields_0[] = {{NULL, 0}};
static const MoRefineFn decl_refines_0[] = {NULL};
static const MoField decl_fields_1[] = {{NULL, 0}};
static const MoRefineFn decl_refines_1[] = {NULL};
static const MoField decl_fields_2[] = {{NULL, 0}};
static const MoRefineFn decl_refines_2[] = {NULL};
static const MoField decl_fields_3[] = {{NULL, 0}};
static const MoRefineFn decl_refines_3[] = {NULL};
static const MoField decl_fields_4[] = {{NULL, 0}};
static const MoRefineFn decl_refines_4[] = {NULL};
static const MoField decl_fields_5[] = {{NULL, 0}};
static const MoRefineFn decl_refines_5[] = {NULL};
static const MoField decl_fields_6[] = {{NULL, 0}};
static const MoRefineFn decl_refines_6[] = {NULL};
static const MoField decl_fields_7[] = {{NULL, 0}};
static const MoRefineFn decl_refines_7[] = {NULL};
static const MoField decl_fields_8[] = {{NULL, 0}};
static const MoRefineFn decl_refines_8[] = {NULL};
static const MoField decl_fields_9[] = {{NULL, 0}};
static const MoRefineFn decl_refines_9[] = {NULL};
static const MoField decl_fields_10[] = {{NULL, 0}};
static const MoRefineFn decl_refines_10[] = {NULL};
static const MoField decl_fields_11[] = {{NULL, 0}};
static const MoRefineFn decl_refines_11[] = {NULL};
static const MoField decl_fields_12[] = {{NULL, 0}};
static const MoRefineFn decl_refines_12[] = {NULL};
static const MoField decl_fields_13[] = {{NULL, 0}};
static const MoRefineFn decl_refines_13[] = {NULL};
static const MoField decl_fields_14[] = {{NULL, 0}};
static const MoRefineFn decl_refines_14[] = {NULL};
static const MoField decl_fields_15[] = {{NULL, 0}};
static const MoRefineFn decl_refines_15[] = {NULL};
static const MoField decl_fields_16[] = {{NULL, 0}};
static const MoRefineFn decl_refines_16[] = {NULL};
static const MoField decl_fields_17[] = {{"id", 0}, {"captured_at", 2}, {"captured_amount", 3}, {"refunded", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_17[] = {NULL};
static const MoField decl_fields_18[] = {{"id", 0}, {"amount", 3}, {NULL, 0}};
static const MoRefineFn decl_refines_18[] = {NULL};
static const MoField decl_fields_19[] = {{"refund", 6}, {NULL, 0}};
static const MoRefineFn decl_refines_19[] = {NULL};
static const MoField decl_fields_20[] = {{"request", 7}, {"reason", 8}, {NULL, 0}};
static const MoRefineFn decl_refines_20[] = {NULL};
static const MoField decl_fields_21[] = {{"method", 1}, {"path", 1}, {"query", 9}, {"headers", 10}, {"body", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_21[] = {NULL};
static const MoField decl_fields_22[] = {{"status", 11}, {"headers", 12}, {"body", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_22[] = {NULL};
static const MoField decl_fields_23[] = {{"id", 4}, {"name", 1}, {"alive", 5}, {"mailbox", 4}, {"bound", 4}, {"waiting_in", 13}, {"restarts", 4}, {"region_bytes", 4}, {"paused", 5}, {"scheduler", 4}, {NULL, 0}};
static const MoRefineFn decl_refines_23[] = {NULL};
static const MoField decl_fields_24[] = {{"kind", 1}, {"target", 4}, {"name", 1}, {"in_flight", 4}, {"paused", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_24[] = {NULL};
static const MoField decl_fields_25[] = {{"name", 1}, {"kind", 14}, {"links", 4}, {"setuid", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_25[] = {NULL};
static const MoField decl_fields_26[] = {{"exit", 15}, {"stdout", 16}, {"stderr", 18}, {"truncated", 5}, {"took", 19}, {NULL, 0}};
static const MoRefineFn decl_refines_26[] = {NULL};
static const MoField decl_fields_27[] = {{"resident_bytes", 4}, {"region_bytes", 4}, {"region_resident_bytes", 4}, {"packed_bytes", 4}, {"event_bytes", 4}, {"largest", 20}, {NULL, 0}};
static const MoRefineFn decl_refines_27[] = {NULL};
static const MoField decl_fields_28[] = {{NULL, 0}};
static const MoRefineFn decl_refines_28[] = {NULL};
static const MoField decl_fields_29[] = {{"query", 1}, {"dir", 1}, {"mode", 22}, {"include_tools", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_29[] = {NULL};
static const MoField decl_fields_30[] = {{NULL, 0}};
static const MoRefineFn decl_refines_30[] = {NULL};
static const MoField decl_fields_31[] = {{"kind", 23}, {"label", 1}, {"text", 1}, {"path", 1}, {"line", 4}, {"local_index", 4}, {"api_index", 24}, {NULL, 0}};
static const MoRefineFn decl_refines_31[] = {NULL};
static const MoField decl_fields_32[] = {{"key", 1}, {"session_key", 1}, {"session_label", 1}, {"role", 1}, {"id", 1}, {"path", 1}, {"first_line", 4}, {"conversation_at", 25}, {"blocks", 26}, {NULL, 0}};
static const MoRefineFn decl_refines_32[] = {NULL};
static const MoField decl_fields_33[] = {{"payload", 28}, {"line", 4}, {NULL, 0}};
static const MoRefineFn decl_refines_33[] = {NULL};
static const MoField decl_fields_34[] = {{"path", 1}, {"line", 4}, {"detail", 1}, {NULL, 0}};
static const MoRefineFn decl_refines_34[] = {NULL};
static const MoField decl_fields_35[] = {{"messages", 29}, {"issues", 31}, {"unknown_kinds", 33}, {"skipped_links", 4}, {"files_read", 4}, {"admitted_bytes", 4}, {"records", 4}, {"retained_blocks", 4}, {"incomplete", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_35[] = {NULL};
static const MoField decl_fields_36[] = {{"files", 34}, {"issues", 35}, {"entries", 4}, {"skipped_links", 4}, {"incomplete", 5}, {"stopped", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_36[] = {NULL};
static const MoField decl_fields_37[] = {{"entry", 30}, {"blocks", 36}, {NULL, 0}};
static const MoRefineFn decl_refines_37[] = {NULL};
static const MoField decl_fields_38[] = {{"key", 1}, {"label", 1}, {"latest", 37}, {"hits", 38}, {NULL, 0}};
static const MoRefineFn decl_refines_38[] = {NULL};
static const MoField decl_fields_39[] = {{"text", 1}, {"diagnostics", 1}, {"matches", 4}, {"incomplete", 5}, {NULL, 0}};
static const MoRefineFn decl_refines_39[] = {NULL};
static const MoField variant_fields_0[] = {{"path", 1}, {NULL, 0}};
static const MoField variant_fields_1[] = {{NULL, 0}};
static const MoField variant_fields_2[] = {{NULL, 0}};
static const MoField variant_fields_3[] = {{NULL, 0}};
static const MoField variant_fields_4[] = {{NULL, 0}};
static const MoField variant_fields_5[] = {{NULL, 0}};
static const MoField variant_fields_6[] = {{"fields", 40}, {NULL, 0}};
static const MoField variant_fields_7[] = {{"items", 41}, {NULL, 0}};
static const MoField variant_fields_8[] = {{"text", 1}, {NULL, 0}};
static const MoField variant_fields_9[] = {{"value", 42}, {NULL, 0}};
static const MoField variant_fields_10[] = {{"value", 5}, {NULL, 0}};
static const MoField variant_fields_11[] = {{NULL, 0}};
static const MoField variant_fields_12[] = {{"at", 4}, {NULL, 0}};
static const MoField variant_fields_13[] = {{NULL, 0}};
static const MoField variant_fields_14[] = {{NULL, 0}};
static const MoField variant_fields_15[] = {{NULL, 0}};
static const MoField variant_fields_16[] = {{NULL, 0}};
static const MoField variant_fields_17[] = {{NULL, 0}};
static const MoField variant_fields_18[] = {{NULL, 0}};
static const MoField variant_fields_19[] = {{NULL, 0}};
static const MoField variant_fields_20[] = {{NULL, 0}};
static const MoField variant_fields_21[] = {{NULL, 0}};
static const MoField variant_fields_22[] = {{NULL, 0}};
static const MoField variant_fields_23[] = {{NULL, 0}};
static const MoField variant_fields_24[] = {{NULL, 0}};
static const MoField variant_fields_25[] = {{NULL, 0}};
static const MoField variant_fields_26[] = {{"why", 1}, {NULL, 0}};
static const MoField variant_fields_27[] = {{NULL, 0}};
static const MoField variant_fields_28[] = {{NULL, 0}};
static const MoField variant_fields_29[] = {{NULL, 0}};
static const MoField variant_fields_30[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"taking", 1}, {"took_us", 4}, {"waited_us", 4}, {"longest", 1}, {NULL, 0}};
static const MoField variant_fields_31[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"scheduler", 4}, {NULL, 0}};
static const MoField variant_fields_32[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_33[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"restarts", 4}, {NULL, 0}};
static const MoField variant_fields_34[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"seed", 4}, {"clause", 1}, {"taking", 1}, {"snapshot", 1}, {NULL, 0}};
static const MoField variant_fields_35[] = {{"at", 2}, {"sender", 43}, {"sender_name", 1}, {"target", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_36[] = {{"at", 2}, {"pid", 44}, {"name", 1}, {"call", 1}, {NULL, 0}};
static const MoField variant_fields_37[] = {{"at", 2}, {"source", 1}, {"target", 4}, {"name", 1}, {"in_flight", 4}, {NULL, 0}};
static const MoField variant_fields_38[] = {{"at", 2}, {"source", 1}, {"target", 4}, {"name", 1}, {"in_flight", 4}, {NULL, 0}};
static const MoField variant_fields_39[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {"taking", 1}, {NULL, 0}};
static const MoField variant_fields_40[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_41[] = {{"at", 2}, {"pid", 4}, {"name", 1}, {NULL, 0}};
static const MoField variant_fields_42[] = {{"at", 2}, {"sender", 45}, {"sender_name", 1}, {"target", 4}, {"name", 1}, {"taking", 1}, {"why", 1}, {NULL, 0}};
static const MoField variant_fields_43[] = {{NULL, 0}};
static const MoField variant_fields_44[] = {{NULL, 0}};
static const MoField variant_fields_45[] = {{NULL, 0}};
static const MoField variant_fields_46[] = {{NULL, 0}};
static const MoField variant_fields_47[] = {{NULL, 0}};
static const MoField variant_fields_48[] = {{NULL, 0}};
static const MoField variant_fields_49[] = {{NULL, 0}};
static const MoField variant_fields_50[] = {{NULL, 0}};
static const MoField variant_fields_51[] = {{"text", 1}, {NULL, 0}};
static const MoField variant_fields_52[] = {{NULL, 0}};
static const MoField variant_fields_53[] = {{"code", 17}, {NULL, 0}};
static const MoField variant_fields_54[] = {{"signal", 17}, {NULL, 0}};
static const MoField variant_fields_55[] = {{NULL, 0}};
static const MoField variant_fields_56[] = {{NULL, 0}};
static const MoField variant_fields_57[] = {{NULL, 0}};
static const MoField variant_fields_58[] = {{"why", 1}, {NULL, 0}};
static const MoField variant_fields_59[] = {{NULL, 0}};
static const MoField variant_fields_60[] = {{NULL, 0}};
static const MoField variant_fields_61[] = {{NULL, 0}};
static const MoField variant_fields_62[] = {{NULL, 0}};
const MoDecl mo_decls[] = {
    {"ChargeId", 2, 0, decl_fields_0, 0, 0, 0, decl_refines_0, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Money", 2, 0, decl_fields_1, 0, 0, 0, decl_refines_1, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"CardNumber", 2, 0, decl_fields_2, 0, 0, 0, decl_refines_2, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"FsError", 8, 0, decl_fields_3, 0, 3, 0, decl_refines_3, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"AskError", 8, 0, decl_fields_4, 3, 2, 0, decl_refines_4, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"LedgerError", 8, 0, decl_fields_5, 5, 1, 0, decl_refines_5, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Json", 8, 0, decl_fields_6, 6, 6, 0, decl_refines_6, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"JsonError", 8, 0, decl_fields_7, 12, 1, 0, decl_refines_7, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"NetError", 8, 0, decl_fields_8, 13, 5, 0, decl_refines_8, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"HttpError", 8, 0, decl_fields_9, 18, 7, 0, decl_refines_9, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RuntimeError", 8, 0, decl_fields_10, 25, 5, 0, decl_refines_10, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Event", 8, 0, decl_fields_11, 30, 13, 0, decl_refines_11, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"EntryKind", 8, 0, decl_fields_12, 43, 3, 0, decl_refines_12, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"TlsError", 8, 0, decl_fields_13, 46, 5, 0, decl_refines_13, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Arg", 8, 0, decl_fields_14, 51, 2, 0, decl_refines_14, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Exit", 8, 0, decl_fields_15, 53, 2, 0, decl_refines_15, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ExecError", 8, 0, decl_fields_16, 55, 4, 0, decl_refines_16, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Charge", 0, 4, decl_fields_17, 0, 0, 0, decl_refines_17, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundRequest", 0, 2, decl_fields_18, 0, 0, 0, decl_refines_18, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundCompleted", 0, 1, decl_fields_19, 0, 0, 0, decl_refines_19, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"RefundFailed", 0, 2, decl_fields_20, 0, 0, 0, decl_refines_20, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Request", 0, 5, decl_fields_21, 0, 0, 0, decl_refines_21, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Response", 0, 3, decl_fields_22, 0, 0, 0, decl_refines_22, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"ProcessInfo", 0, 10, decl_fields_23, 0, 0, 0, decl_refines_23, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"SourceInfo", 0, 5, decl_fields_24, 0, 0, 0, decl_refines_24, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Entry", 0, 4, decl_fields_25, 0, 0, 0, decl_refines_25, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Done", 0, 5, decl_fields_26, 0, 0, 0, decl_refines_26, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"MemoryInfo", 0, 6, decl_fields_27, 0, 0, 0, decl_refines_27, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Mode", 1, 0, decl_fields_28, 59, 2, 0, decl_refines_28, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Options", 0, 4, decl_fields_29, 0, 0, 0, decl_refines_29, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"BlockKind", 1, 0, decl_fields_30, 61, 2, 0, decl_refines_30, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Block", 0, 7, decl_fields_31, 0, 0, 0, decl_refines_31, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Message", 0, 9, decl_fields_32, 0, 0, 0, decl_refines_32, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Seen", 0, 2, decl_fields_33, 0, 0, 0, decl_refines_33, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Issue", 0, 3, decl_fields_34, 0, 0, 0, decl_refines_34, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Scan", 0, 9, decl_fields_35, 0, 0, 0, decl_refines_35, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Discovery", 0, 6, decl_fields_36, 0, 0, 0, decl_refines_36, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Hit", 0, 2, decl_fields_37, 0, 0, 0, decl_refines_37, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Session", 0, 4, decl_fields_38, 0, 0, 0, decl_refines_38, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {"Report", 0, 4, decl_fields_39, 0, 0, 0, decl_refines_39, false, (__int128)0ull, (__int128)0ull, 4294967295},
    {NULL, 0, 0, NULL, 0, 0, 0, NULL, false, 0, 0, 0}
};
const MoVariantDef mo_variants[] = {
    {4, 1, variant_fields_0},
    {5, 0, variant_fields_1},
    {21, 0, variant_fields_2},
    {5, 0, variant_fields_3},
    {13, 0, variant_fields_4},
    {5, 0, variant_fields_5},
    {7, 1, variant_fields_6},
    {8, 1, variant_fields_7},
    {9, 1, variant_fields_8},
    {10, 1, variant_fields_9},
    {11, 1, variant_fields_10},
    {12, 0, variant_fields_11},
    {6, 1, variant_fields_12},
    {5, 0, variant_fields_13},
    {14, 0, variant_fields_14},
    {15, 0, variant_fields_15},
    {16, 0, variant_fields_16},
    {17, 0, variant_fields_17},
    {5, 0, variant_fields_18},
    {14, 0, variant_fields_19},
    {15, 0, variant_fields_20},
    {17, 0, variant_fields_21},
    {18, 0, variant_fields_22},
    {19, 0, variant_fields_23},
    {20, 0, variant_fields_24},
    {26, 0, variant_fields_25},
    {27, 1, variant_fields_26},
    {28, 0, variant_fields_27},
    {29, 0, variant_fields_28},
    {5, 0, variant_fields_29},
    {30, 7, variant_fields_30},
    {31, 4, variant_fields_31},
    {32, 3, variant_fields_32},
    {33, 4, variant_fields_33},
    {34, 7, variant_fields_34},
    {35, 5, variant_fields_35},
    {36, 4, variant_fields_36},
    {37, 5, variant_fields_37},
    {38, 5, variant_fields_38},
    {39, 4, variant_fields_39},
    {40, 3, variant_fields_40},
    {41, 3, variant_fields_41},
    {44, 7, variant_fields_42},
    {42, 0, variant_fields_43},
    {43, 0, variant_fields_44},
    {48, 0, variant_fields_45},
    {45, 0, variant_fields_46},
    {46, 0, variant_fields_47},
    {5, 0, variant_fields_48},
    {15, 0, variant_fields_49},
    {47, 0, variant_fields_50},
    {49, 1, variant_fields_51},
    {50, 0, variant_fields_52},
    {51, 1, variant_fields_53},
    {52, 1, variant_fields_54},
    {4, 0, variant_fields_55},
    {14, 0, variant_fields_56},
    {5, 0, variant_fields_57},
    {53, 1, variant_fields_58},
    {54, 0, variant_fields_59},
    {55, 0, variant_fields_60},
    {56, 0, variant_fields_61},
    {57, 0, variant_fields_62},
    {0, 0, NULL}
};
const uint32_t mo_nvariants = 63;
const MoType mo_types[] = {
    {17, "ChargeId", UINT32_MAX, false, 0, 1, NULL},
    {4, "String", UINT32_MAX, false, 0, 0, NULL},
    {5, "Time", UINT32_MAX, false, 0, 0, NULL},
    {17, "Money", UINT32_MAX, false, 1, 4, NULL},
    {7, "UInt64", UINT32_MAX, false, 7, 0, NULL},
    {3, "Bool", UINT32_MAX, false, 0, 0, NULL},
    {24, "a type not yet known", UINT32_MAX, false, 0, 0, NULL},
    {16, "RefundRequest", UINT32_MAX, false, 18, 0, NULL},
    {24, "a type not yet known", UINT32_MAX, false, 0, 0, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {7, "UInt16", UINT32_MAX, false, 5, 0, NULL},
    {12, "Map(String, String)", UINT32_MAX, false, 1, 1, NULL},
    {10, "Option(String)", UINT32_MAX, false, 1, 0, NULL},
    {16, "EntryKind", UINT32_MAX, false, 12, 0, NULL},
    {16, "Exit", UINT32_MAX, false, 15, 0, NULL},
    {9, "List(UInt8)", UINT32_MAX, false, 17, 0, NULL},
    {7, "UInt8", UINT32_MAX, false, 4, 0, NULL},
    {9, "List(UInt8)", UINT32_MAX, false, 17, 0, NULL},
    {6, "Duration", UINT32_MAX, false, 0, 0, NULL},
    {9, "List(ProcessInfo)", UINT32_MAX, false, 21, 0, NULL},
    {16, "ProcessInfo", UINT32_MAX, false, 23, 0, NULL},
    {16, "Mode", UINT32_MAX, false, 28, 0, NULL},
    {16, "BlockKind", UINT32_MAX, false, 30, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {10, "Option(Time)", UINT32_MAX, false, 2, 0, NULL},
    {9, "List(Block)", UINT32_MAX, false, 27, 0, NULL},
    {16, "Block", UINT32_MAX, false, 31, 0, NULL},
    {16, "Json", UINT32_MAX, false, 6, 0, NULL},
    {12, "Map(String, Message)", UINT32_MAX, false, 1, 30, NULL},
    {16, "Message", UINT32_MAX, false, 32, 0, NULL},
    {9, "List(Issue)", UINT32_MAX, false, 32, 0, NULL},
    {16, "Issue", UINT32_MAX, false, 34, 0, NULL},
    {12, "Map(String, UInt64)", UINT32_MAX, false, 1, 4, NULL},
    {9, "List(String)", UINT32_MAX, false, 1, 0, NULL},
    {9, "List(Issue)", UINT32_MAX, false, 32, 0, NULL},
    {9, "List(Block)", UINT32_MAX, false, 27, 0, NULL},
    {10, "Option(Time)", UINT32_MAX, false, 2, 0, NULL},
    {9, "List(Hit)", UINT32_MAX, false, 39, 0, NULL},
    {16, "Hit", UINT32_MAX, false, 37, 0, NULL},
    {12, "Map(String, Json)", UINT32_MAX, false, 1, 28, NULL},
    {9, "List(Json)", UINT32_MAX, false, 28, 0, NULL},
    {8, "Float64", UINT32_MAX, false, 64, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {10, "Option(UInt64)", UINT32_MAX, false, 4, 0, NULL},
    {0, NULL, UINT32_MAX, false, 0, 0, NULL}
};
const uint32_t mo_nrecorded = 0;
const char *const mo_names[] = {"Some", "None", "Ok", "Error", "Missing", "Timeout", "Syntax", "Object", "Array", "String", "Number", "Bool", "Null", "Down", "Refused", "Closed", "LineTooLong", "Busy", "Malformed", "TooLarge", "Unsupported", "NotText", "Accepted", "Line", "Chunk", "Idle", "NoProcess", "Unparsed", "ReadOnly", "MailboxFull", "Updated", "Started", "Ended", "Restarted", "Crashed", "Overflowed", "TimedOut", "SourcePaused", "SourceResumed", "Sent", "Paused", "Resumed", "File", "Folder", "Dropped", "BadPem", "Handshake", "Untrusted", "Link", "Fixed", "Hole", "Exited", "Signalled", "Failed", "Phrase", "AllWords", "Conversation", "Tool", NULL};
const uint32_t mo_nnames = 58;
const MoClause mo_clauses[] = {
    {5, false, "assert scan.messages.size == 0 and scan.issues.size == 0 and scan.unknown_kinds.size == 0", "empty production state starts every counter and stop flag clear", "/tmp/mo-lead-moscope-full/examples/programs/moscope/model.mo:111:3"},
    {5, false, "assert scan.skipped_links == 0 and scan.files_read == 0 and scan.admitted_bytes == 0", "empty production state starts every counter and stop flag clear", "/tmp/mo-lead-moscope-full/examples/programs/moscope/model.mo:112:3"},
    {5, false, "assert scan.records == 0 and scan.retained_blocks == 0 and !scan.incomplete", "empty production state starts every counter and stop flag clear", "/tmp/mo-lead-moscope-full/examples/programs/moscope/model.mo:113:3"},
    {5, false, "assert found.files.size == 0 and found.issues.size == 0 and found.entries == 0", "empty production state starts every counter and stop flag clear", "/tmp/mo-lead-moscope-full/examples/programs/moscope/model.mo:115:3"},
    {5, false, "assert found.skipped_links == 0 and !found.incomplete and !found.stopped", "empty production state starts every counter and stop flag clear", "/tmp/mo-lead-moscope-full/examples/programs/moscope/model.mo:116:3"},
    {0, false, NULL, NULL, NULL}
};
const MoTest mo_tests[] = {
    {MO_TEST, "empty production state starts every counter and stop flag clear", test0},
    {0, NULL, NULL}
};
const uint32_t mo_ntests = 1;
const MoNever mo_nevers[] = {
    {NULL, 0, 0, NULL}
};
const uint32_t mo_nnevers = 0;
const MoProcess mo_processes[] = {
    {NULL, 0, 0, NULL, NULL, 0, NULL, false}
};
const uint32_t mo_nprocesses = 0;
const MoSupervisor mo_supervisors[] = {
    {NULL, 0, NULL}
};
const uint32_t mo_nsupervisors = 0;
const uint32_t mo_charge_decl = 17;
const uint32_t mo_request_decl = 21;
const uint32_t mo_response_decl = 22;
const uint32_t mo_process_info_decl = 23;
const uint32_t mo_source_info_decl = 24;
const uint32_t mo_memory_info_decl = 27;
const uint32_t mo_entry_decl = 25;
const uint32_t mo_done_decl = 26;
const bool mo_surface_built = false;
const uint32_t mo_surface_process = UINT32_MAX;
const bool mo_contracts_built = true;

MO_U static MoValue f0(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("empty_scan");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_r_Map_new(NULL, MO_KIND_NONE);
    MoValue t3 MO_U = mo_record(35, 9, (const MoValue[]){t0, t1, t2, mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_bool(false)});
    R = t3;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
MO_U static MoValue f1(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("empty_discovery");
    if (mo_contracts) {
    }
    MoValue t0 MO_U = mo_list_of(0, NULL);
    MoValue t1 MO_U = mo_list_of(0, NULL);
    MoValue t2 MO_U = mo_record(36, 6, (const MoValue[]){t0, t1, mo_i64(INT64_C(0)), mo_i64(INT64_C(0)), mo_bool(false), mo_bool(false)});
    R = t2;
    if (mo_contracts) {
    }
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_depth--;
    return R;
}
#define SAVE_test0() do { V_[0] = L0; V_[1] = L1; V_[2] = R; } while (0)
#define LOAD_test0() do { L0 = V_[0]; L1 = V_[1]; R = V_[2]; } while (0)
MO_U static MoValue test0(void) {
    size_t F_ MO_U = mo_mark();
    MoValue R MO_U = MO_NONE_V;
    if (++mo_depth > MO_DEPTH_LIMIT) mo_too_deep("empty production state starts every counter and stop flag clear");
    MoValue L0 MO_U = MO_NONE_V;
    MoValue L1 MO_U = MO_NONE_V;
    MoValue V_[3];
    size_t *const M_[] = {&F_};
    MoFrame FR_ = {mo_frames, mo_depth, false, false, F_, 0, V_, 3, M_, 1};
    if (!FR_.pinned && FR_.next && FR_.next->walking && FR_.next->depth + 1 == mo_depth) {
        FR_.base = FR_.next->base;
        FR_.kept = FR_.next->kept;
    }
    mo_frames = &FR_;
    if (mo_walk_due(&FR_)) { SAVE_test0(); mo_walk(&FR_); LOAD_test0(); }
    SAVE_test0();
    uint64_t w0 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t1 MO_U = f0();
    FR_.walking = false; if (mo_walks != w0) LOAD_test0();
    L0 = t1;
    MoValue t2 MO_U = L0;
    MoValue t3 MO_U = t2.as.xs[0];
    MoValue t4 MO_U = mo_r_Map_size((const MoValue[]){t3}, MO_KIND_NONE);
    MoValue t5 MO_U = mo_bool(t4.as.u == mo_i64(INT64_C(0)).as.u);
    MoValue t6 MO_U = mo_bool(false);
    if (t5.as.b) {
        MoValue t7 MO_U = L0.as.xs[1];
        MoValue t8 MO_U = mo_r_List_size((const MoValue[]){t7}, MO_KIND_NONE);
        MoValue t9 MO_U = mo_bool(t8.as.u == mo_i64(INT64_C(0)).as.u);
        t6 = t9;
    }
    MoValue t10 MO_U = mo_bool(false);
    if (t6.as.b) {
        MoValue t11 MO_U = L0;
        MoValue t12 MO_U = t11.as.xs[2];
        MoValue t13 MO_U = mo_r_Map_size((const MoValue[]){t12}, MO_KIND_NONE);
        MoValue t14 MO_U = mo_bool(t13.as.u == mo_i64(INT64_C(0)).as.u);
        t10 = t14;
    }
    if (!t10.as.b) mo_crash(0);
    MoValue t15 MO_U = L0.as.xs[3];
    MoValue t16 MO_U = mo_bool(t15.as.u == mo_i64(INT64_C(0)).as.u);
    MoValue t17 MO_U = mo_bool(false);
    if (t16.as.b) {
        MoValue t18 MO_U = L0.as.xs[4];
        MoValue t19 MO_U = mo_bool(t18.as.u == mo_i64(INT64_C(0)).as.u);
        t17 = t19;
    }
    MoValue t20 MO_U = mo_bool(false);
    if (t17.as.b) {
        MoValue t21 MO_U = L0.as.xs[5];
        MoValue t22 MO_U = mo_bool(t21.as.u == mo_i64(INT64_C(0)).as.u);
        t20 = t22;
    }
    if (!t20.as.b) mo_crash(1);
    MoValue t23 MO_U = L0.as.xs[6];
    MoValue t24 MO_U = mo_bool(t23.as.u == mo_i64(INT64_C(0)).as.u);
    MoValue t25 MO_U = mo_bool(false);
    if (t24.as.b) {
        MoValue t26 MO_U = L0.as.xs[7];
        MoValue t27 MO_U = mo_bool(t26.as.u == mo_i64(INT64_C(0)).as.u);
        t25 = t27;
    }
    MoValue t28 MO_U = mo_bool(false);
    if (t25.as.b) {
        MoValue t29 MO_U = L0.as.xs[8];
        MoValue t30 MO_U = mo_bool(!t29.as.b);
        t28 = t30;
    }
    if (!t28.as.b) mo_crash(2);
    if (mo_walk_due(&FR_)) { SAVE_test0(); mo_walk(&FR_); LOAD_test0(); }
    SAVE_test0();
    uint64_t w31 MO_U = mo_walks;
    FR_.walking = true;
    MoValue t32 MO_U = f1();
    FR_.walking = false; if (mo_walks != w31) LOAD_test0();
    L1 = t32;
    MoValue t33 MO_U = L1.as.xs[0];
    MoValue t34 MO_U = mo_r_List_size((const MoValue[]){t33}, MO_KIND_NONE);
    MoValue t35 MO_U = mo_bool(t34.as.u == mo_i64(INT64_C(0)).as.u);
    MoValue t36 MO_U = mo_bool(false);
    if (t35.as.b) {
        MoValue t37 MO_U = L1.as.xs[1];
        MoValue t38 MO_U = mo_r_List_size((const MoValue[]){t37}, MO_KIND_NONE);
        MoValue t39 MO_U = mo_bool(t38.as.u == mo_i64(INT64_C(0)).as.u);
        t36 = t39;
    }
    MoValue t40 MO_U = mo_bool(false);
    if (t36.as.b) {
        MoValue t41 MO_U = L1.as.xs[2];
        MoValue t42 MO_U = mo_bool(t41.as.u == mo_i64(INT64_C(0)).as.u);
        t40 = t42;
    }
    if (!t40.as.b) mo_crash(3);
    MoValue t43 MO_U = L1.as.xs[3];
    MoValue t44 MO_U = mo_bool(t43.as.u == mo_i64(INT64_C(0)).as.u);
    MoValue t45 MO_U = mo_bool(false);
    if (t44.as.b) {
        MoValue t46 MO_U = L1.as.xs[4];
        MoValue t47 MO_U = mo_bool(!t46.as.b);
        t45 = t47;
    }
    MoValue t48 MO_U = mo_bool(false);
    if (t45.as.b) {
        MoValue t49 MO_U = L1.as.xs[5];
        MoValue t50 MO_U = mo_bool(!t49.as.b);
        t48 = t50;
    }
    if (!t48.as.b) mo_crash(4);
    if (mo_frame_due(F_)) {
        MoValue r_[] = {R};
        mo_compact(F_, r_, 1);
        R = r_[0];
    }
    mo_frames = FR_.next;
    mo_depth--;
    return R;
}
#undef SAVE_test0
#undef LOAD_test0

int main(void) {
    return mo_run_tests();
}
